<?php
/**
 * Template Name: About Us
 */
get_header(); ?>

<!-- BREADCRUMB -->
<div class="breadcrumb">
  <div class="wrap">
    <div class="breadcrumb-inner">
      <ol class="bc-list">
        <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <li class="bc-sep">/</li>
        <li>About Us</li>
      </ol>
    </div>
  </div>
</div>

<!-- ABOUT HERO -->
<section style="padding:12px 0 64px;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 480px;gap:64px;align-items:center">
      <div>
        <div class="section-tag">✦ About Qrenzy</div>
        <h1 style="font-size:clamp(32px,4.5vw,52px);font-weight:900;color:#0a0a0a;letter-spacing:-0.03em;line-height:1.1;margin:16px 0 20px">
          Kerala's Most Trusted<br><span style="color:#E31E24">Digital Marketing Agency</span>
        </h1>
        <p style="font-size:17px;color:#555;line-height:1.8;margin-bottom:24px;max-width:520px">
          Founded in Thrissur, Kerala in 2020 — backed by 15+ years of digital marketing expertise. We serve businesses across India, Oman, UAE, Bahrain and clients worldwide.
        </p>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:32px">
          <span class="geo-badge">🇮🇳 India</span>
          <span class="geo-badge">🇴🇲 Oman</span>
          <span class="geo-badge">🇦🇪 UAE</span>
          <span class="geo-badge">🇧🇭 Bahrain</span>
          <span class="geo-badge">🌐 Worldwide</span>
        </div>
        <div style="display:flex;gap:12px;flex-wrap:wrap">
          <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-primary">🚀 Work With Us</a>
          <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-wa" rel="noopener" target="_blank">💬 WhatsApp</a>
        </div>
      </div>
      <div style="background:#f8f8f6;border-radius:24px;padding:36px;border:1px solid #e8e8e4">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
          <?php
          $stats = [
            ['200+','Happy Clients','India, Gulf & Beyond'],
            ['15+','Years Experience','Since 2012'],
            ['5K+','Keywords Ranked','India & Gulf'],
            ['4.8x','Average ROAS','Google & Meta'],
          ];
          foreach($stats as $s): ?>
          <div style="background:#fff;border-radius:16px;padding:20px;border:1px solid #e8e8e4;text-align:center">
            <div style="font-size:32px;font-weight:900;color:#E31E24;letter-spacing:-0.03em;line-height:1"><?php echo $s[0]; ?></div>
            <div style="font-size:13px;font-weight:700;color:#0a0a0a;margin:5px 0 3px"><?php echo $s[1]; ?></div>
            <div style="font-size:10px;font-weight:700;color:#E31E24;letter-spacing:0.1em;text-transform:uppercase"><?php echo $s[2]; ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- OUR STORY -->
<section style="padding:20px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center">
      <div>
        <div class="section-tag">✦ Our Story</div>
        <h2 class="section-title" style="margin:16px 0 20px">From Thrissur to<br>the World</h2>
        <p style="font-size:15px;color:#555;line-height:1.8;margin-bottom:16px">
          Qrenzy Digital Solutions was founded in 2020 in Thrissur, Kerala — but the story started much earlier. Our founder Sajeesh Vaderiyattil Sahadevan began his digital marketing journey in 2012, working across Kerala, Oman and UAE, managing IT and marketing operations for businesses of all sizes.
        </p>
        <p style="font-size:15px;color:#555;line-height:1.8;margin-bottom:16px">
          After 15+ years of hands-on experience — from managing IT infrastructure for 20+ retail outlets in Oman and UAE to running full digital marketing campaigns for premium brands — Qrenzy was born with one mission: bring enterprise-level digital marketing to growing businesses.
        </p>
        <p style="font-size:15px;color:#555;line-height:1.8;margin-bottom:28px">
          Today we serve 200+ clients across India, Oman, UAE, Bahrain and worldwide — combining deep local market knowledge with AI-powered strategies to deliver real, measurable results.
        </p>
        <div style="background:#fff;border-radius:16px;padding:20px 24px;border-left:4px solid #E31E24;border:1px solid #e8e8e4">
          <p style="font-size:15px;font-style:italic;color:#333;line-height:1.7;margin:0">
            "We don't just run campaigns — we become your digital growth partner. Every strategy we build is backed by 15 years of real-world experience across India and the Gulf."
          </p>
          <div style="display:flex;align-items:center;gap:12px;margin-top:16px">
            <div style="width:44px;height:44px;border-radius:50%;background:#E31E24;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;color:#fff;flex-shrink:0">SV</div>
            <div>
              <div style="font-size:14px;font-weight:700;color:#0a0a0a">Sajeesh Vaderiyattil Sahadevan</div>
              <div style="font-size:12px;color:#888">Founder & Digital Strategist, Qrenzy Digital Solutions</div>
            </div>
          </div>
        </div>
      </div>
      <div>
        <!-- Timeline -->
        <div style="position:relative;padding-left:32px">
          <div style="position:absolute;left:10px;top:0;bottom:0;width:2px;background:#e8e8e4"></div>
          <?php
          $timeline = [
            ['2012','Started Digital Journey','Began digital marketing career across Kerala, Oman & UAE. Managed IT operations for 20+ retail outlets.','#E31E24'],
            ['2016','Gulf Market Expertise','Expanded to managing full digital marketing campaigns for premium brands in Oman and UAE.','#1565C0'],
            ['2019','Photography & Video','Added professional photography and video production to the skillset — serving clients across Gulf markets.','#2E7D32'],
            ['2020','Founded Qrenzy','Launched Qrenzy Digital Solutions in Thrissur, Kerala — combining 15 years of expertise under one roof.','#E65100'],
            ['2023','AI-Powered Growth','Integrated AI tools and automation into all services — delivering faster, smarter results for clients.','#6B21A8'],
            ['2026','200+ Clients','Serving 200+ businesses across India, Oman, UAE, Bahrain and worldwide. 5K+ keywords ranked.','#E31E24'],
          ];
          foreach($timeline as $t): ?>
          <div style="position:relative;margin-bottom:28px">
            <div style="position:absolute;left:-28px;top:4px;width:16px;height:16px;border-radius:50%;background:<?php echo $t[3]; ?>;border:3px solid #fff;box-shadow:0 0 0 2px <?php echo $t[3]; ?>"></div>
            <div style="font-size:11px;font-weight:800;color:<?php echo $t[3]; ?>;letter-spacing:0.1em;text-transform:uppercase;margin-bottom:4px"><?php echo $t[0]; ?></div>
            <div style="font-size:15px;font-weight:700;color:#0a0a0a;margin-bottom:4px"><?php echo $t[1]; ?></div>
            <div style="font-size:13px;color:#666;line-height:1.6"><?php echo $t[2]; ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- FOUNDER -->
<section style="padding:32px 0;background:#fff">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ Meet the Founder</div>
      <h2 class="section-title">The Person Behind Qrenzy</h2>
    </div>
    <div style="max-width:800px;margin:0 auto;background:#f8f8f6;border-radius:24px;padding:40px;border:1px solid #e8e8e4;display:flex;gap:32px;align-items:flex-start">
      <div style="flex-shrink:0;text-align:center">
        <div style="width:120px;height:120px;border-radius:50%;background:linear-gradient(135deg,#E31E24,#C01018);display:flex;align-items:center;justify-content:center;font-size:36px;font-weight:900;color:#fff;margin:0 auto 12px">SV</div>
        <div style="font-size:13px;font-weight:700;color:#0a0a0a">Sajeesh Vaderiyattil Sahadevan</div>
        <div style="font-size:11px;color:#888;margin-top:2px">Thrissur, Kerala</div>
        <div style="display:flex;gap:6px;justify-content:center;margin-top:10px">
          <a href="https://linkedin.com/in/sajeeshvs" style="width:30px;height:30px;border-radius:50%;background:#0A66C2;display:flex;align-items:center;justify-content:center;color:#fff;font-size:11px;font-weight:700" rel="noopener" target="_blank">in</a>
          <a href="https://api.whatsapp.com/send?phone=919905700600" style="width:30px;height:30px;border-radius:50%;background:#25D366;display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px" rel="noopener" target="_blank">💬</a>
        </div>
      </div>
      <div>
        <h3 style="font-size:20px;font-weight:800;color:#0a0a0a;margin-bottom:4px">Sajeesh Vaderiyattil Sahadevan</h3>
        <div style="font-size:13px;color:#E31E24;font-weight:600;margin-bottom:16px">Founder & Digital Strategist — 15+ Years Experience</div>
        <p style="font-size:14px;color:#555;line-height:1.8;margin-bottom:12px">
          With 15+ years of hands-on experience across Kerala, Oman and UAE, Sajeesh is a full-stack digital marketer specialising in SEO, social media marketing, web development and AI marketing automation.
        </p>
        <p style="font-size:14px;color:#555;line-height:1.8;margin-bottom:16px">
          His background spans CNC operations at Sobha Developers, IT infrastructure management for 20+ retail outlets across Gulf countries, photography and video production, and running full digital marketing campaigns for premium brands including Al Fanar Group — Oman's exclusive Grohe dealer.
        </p>
        <div style="display:flex;flex-wrap:wrap;gap:8px">
          <?php
          $skills = ['SEO','Social Media','Google Ads','Web Design','Photography','Malayalam Content','AI Tools','Gulf Markets'];
          foreach($skills as $sk): ?>
          <span style="font-size:11px;font-weight:600;padding:5px 12px;border-radius:100px;background:#fff;border:1px solid #e8e8e4;color:#333"><?php echo $sk; ?></span>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- VALUES -->
<section style="padding:32px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ Our Values</div>
      <h2 class="section-title">What We Stand For</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px">
      <?php
      $values = [
        ['🎯','Results First','We measure success by your business growth — not vanity metrics. Every strategy is built to drive real ROI.'],
        ['🤝','True Partnership','We don\'t just execute tasks. We become your long-term digital growth partner invested in your success.'],
        ['🔍','Radical Transparency','No jargon, no hiding. You get clear reports, honest communication and full visibility into everything we do.'],
        ['🤖','Always Innovating','We stay ahead of every algorithm change, AI development and platform update so your business never falls behind.'],
      ];
      foreach($values as $v): ?>
      <div style="background:#fff;border-radius:20px;padding:28px 22px;border:1px solid #e8e8e4;text-align:center">
        <div style="font-size:36px;margin-bottom:14px"><?php echo $v[0]; ?></div>
        <div style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:8px"><?php echo $v[1]; ?></div>
        <p style="font-size:13px;color:#666;line-height:1.65;margin:0"><?php echo $v[2]; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- MARKETS WE SERVE -->
<section style="padding:32px 0;background:#0a0a0a">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div style="display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;padding:5px 14px;border-radius:100px;background:rgba(227,30,36,0.15);color:#E31E24;border:1px solid rgba(227,30,36,0.3);margin-bottom:14px">✦ Our Markets</div>
      <h2 style="font-size:clamp(26px,3.5vw,40px);font-weight:900;color:#fff;letter-spacing:-0.025em">Deep Local Knowledge.<br>Global Reach.</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px">
      <?php
      $markets = [
        ['🇮🇳','India — Primary Market','Thrissur, Kochi, Calicut, Bangalore and cities across Kerala and India. Deep understanding of Indian digital consumer behaviour, Google India algorithms and local SEO.','Kerala SEO, India Digital Marketing'],
        ['🇴🇲','Oman — Gulf Market','Muscat, Sohar, Salalah. Currently managing digital marketing for Al Fanar Group — Oman\'s exclusive Grohe dealer. Strong relationships in the Oman business community.','Oman SEO, Muscat Digital Marketing'],
        ['🇦🇪','UAE — Gulf Market','Dubai, Abu Dhabi, Sharjah. Extensive experience running campaigns for UAE businesses. Understanding of Arabic market dynamics and local consumer preferences.','UAE Digital Marketing, Dubai SEO'],
      ];
      foreach($markets as $m): ?>
      <div style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:28px">
        <div style="font-size:36px;margin-bottom:14px"><?php echo $m[0]; ?></div>
        <h3 style="font-size:16px;font-weight:800;color:#fff;margin-bottom:10px"><?php echo $m[1]; ?></h3>
        <p style="font-size:13px;color:rgba(255,255,255,0.55);line-height:1.7;margin-bottom:14px"><?php echo $m[2]; ?></p>
        <div style="font-size:10px;font-weight:700;color:#E31E24;letter-spacing:0.08em;text-transform:uppercase"><?php echo $m[3]; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section style="padding:32px 0;background:#fff">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ Client Reviews</div>
      <h2 class="section-title">Trusted by 200+ Businesses</h2>
    </div>
    <div class="testimonials-grid">
      <?php
      $testimonials = [
        ['AR','#E31E24','"Qrenzy completely transformed our online presence. Leads increased by 70% in just three months. Their SEO strategy was spot on for the Oman market."','Ahmed Al Rashidi','CEO, Al Fanar Group, Oman'],
        ['RM','#1565C0','"We went from zero visibility to Page 1 for our main keywords in Kerala. The team understands local business needs in Thrissur perfectly."','Rajesh Menon','Business Owner, Thrissur, Kerala'],
        ['PN','#2E7D32','"Their social media strategy grew our Instagram from 800 to 12,000 followers in 4 months. Absolutely incredible ROI for a small business."','Priya Nair','Digital Creator, Kochi'],
      ];
      foreach($testimonials as $t): ?>
      <div class="testimonial-card">
        <div class="test-stars">★★★★★</div>
        <p class="test-text"><?php echo $t[2]; ?></p>
        <div class="test-author">
          <div class="test-av" style="background:<?php echo $t[1]; ?>"><?php echo $t[0]; ?></div>
          <div><div class="test-name"><?php echo $t[3]; ?></div><div class="test-role"><?php echo $t[4]; ?></div></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-band">
  <div class="wrap">
    <div class="cta-inner">
      <h2>Ready to Work With Us?</h2>
      <p>Book a free 30-minute strategy call. No fluff — just a clear growth roadmap for your business in India, Oman, UAE or anywhere worldwide.</p>
      <div class="cta-btns">
        <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-white">🚀 Get Free Strategy Call</a>
        <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-outline-white" rel="noopener" target="_blank">💬 WhatsApp Us</a>
      </div>
    </div>
  </div>
</section>

<!-- RESPONSIVE -->
<style>
@media (max-width: 900px) {
  .about-hero-grid, .story-grid { grid-template-columns: 1fr !important; }
}
@media (max-width: 600px) {
  [style*="grid-template-columns:repeat(4"] { grid-template-columns: 1fr 1fr !important; }
  [style*="grid-template-columns:repeat(3"] { grid-template-columns: 1fr !important; }
  [style*="grid-template-columns:1fr 480px"] { grid-template-columns: 1fr !important; }
  [style*="grid-template-columns:1fr 1fr"] { grid-template-columns: 1fr !important; }
  [style*="display:flex;gap:32px"] { flex-direction: column !important; }
}
</style>

<?php get_footer(); ?>

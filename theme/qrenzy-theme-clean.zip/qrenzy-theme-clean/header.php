<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php ob_start(); wp_head(); $head=ob_get_clean(); echo str_replace('<!-- wp:social-link','<!-- ',$head); ?>
<meta name="google-adsense-account" content="ca-pub-8842701702358793">
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init','1277336791255087');
fbq('track','PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=1277336791255087&ev=PageView&noscript=1"/></noscript>
<!-- End Meta Pixel Code -->
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="progress-bar"></div>

<nav id="site-nav" aria-label="Main navigation">
  <div class="nav-inner">
    <div class="nav-logo">
      <?php if (has_custom_logo()): the_custom_logo();
      else: ?><a href="<?php echo home_url(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/logo.png" alt="<?php bloginfo('name'); ?> - Home"></a><?php endif; ?>
    </div>

    <ul class="nav-links" role="list">
      <li <?php if(is_front_page()) echo 'class="current-menu-item"'; ?>>
        <a href="<?php echo home_url('/'); ?>">Home</a>
      </li>
      <li class="has-dropdown <?php $sp=['search-engine-optimization','local-seo','web-designing','social-media-marketing','pay-per-click','ai-marketing-automation','photography-videography','graphic-designing','custom-software','services']; if(is_page($sp)) echo 'current-menu-item'; ?>">
        <a href="<?php echo home_url('/services/'); ?>">Services <span class="drop-arrow" aria-hidden="true">▾</span></a>
        <ul class="dropdown" role="list">
          <li><a href="<?php echo home_url('/search-engine-optimization/'); ?>">🔍 Search Engine Optimization</a></li>
          <li><a href="<?php echo home_url('/local-seo/'); ?>">📍 Local SEO &amp; Google Business</a></li>
          <li><a href="<?php echo home_url('/web-designing/'); ?>">🌐 Web Design &amp; Development</a></li>
          <li><a href="<?php echo home_url('/social-media-marketing/'); ?>">📱 Social Media Marketing</a></li>
          <li><a href="<?php echo home_url('/pay-per-click/'); ?>">🎯 Performance Marketing</a></li>
          <li><a href="<?php echo home_url('/ai-marketing-automation/'); ?>">🤖 AI Marketing Automation</a></li>
          <li><a href="<?php echo home_url('/photography-videography/'); ?>">📸 Photography &amp; Videography</a></li>
          <li><a href="<?php echo home_url('/graphic-designing/'); ?>">🎨 Graphic Design</a></li>
          <li><a href="<?php echo home_url('/custom-software/'); ?>">💻 Software Solutions</a></li>
        </ul>
      </li>
      <li <?php if(is_page('about')) echo 'class="current-menu-item"'; ?>>
        <a href="<?php echo home_url('/about/'); ?>">About Us</a>
      </li>
      <li>
        <a href="<?php echo home_url('/why-us/'); ?>">Why Us</a>
      </li>
      <li <?php if(is_page('portfolio')) echo 'class="current-menu-item"'; ?>>
        <a href="<?php echo home_url('/portfolio/'); ?>">Portfolio</a>
      </li>
      <li>
        <a href="https://demo.qrenzy.com/websites-for/">Live Demos</a>
      </li>
      <li <?php if(is_home() || is_singular('post') || is_category()) echo 'class="current-menu-item"'; ?>>
        <a href="<?php echo get_permalink(get_option('page_for_posts')); ?>">Blog</a>
      </li>
      <li <?php if(is_page('contact')) echo 'class="current-menu-item"'; ?>>
        <a href="<?php echo home_url('/contact/'); ?>">Contact</a>
      </li>
    </ul>

    <div class="nav-btns">
      <a href="https://api.whatsapp.com/send?phone=919905700600" class="nav-plain-link" rel="noopener" target="_blank" aria-label="Chat with us on WhatsApp">💬 WhatsApp</a>
      <span class="nav-sep" aria-hidden="true">|</span>
      <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="nav-plain-link nav-plain-red" aria-label="Get your free SEO audit">Free Audit →</a>
    </div>

    <button class="hamburger" id="ham" onclick="toggleMenu()" aria-label="Open navigation menu" aria-expanded="false" aria-controls="mobile-menu">
      <span aria-hidden="true"></span><span aria-hidden="true"></span><span aria-hidden="true"></span>
    </button>
  </div>
</nav>

<div id="mobile-menu" role="dialog" aria-label="Mobile navigation menu" aria-modal="false" hidden>
  <a href="<?php echo home_url('/'); ?>" onclick="closeMenu()">Home</a>
  <div class="mob-svc-toggle" id="mob-svc-btn">
    <a href="<?php echo home_url('/services/'); ?>" onclick="closeMenu();" style="font-weight:700;flex:1">Services</a>
    <button onclick="toggleMobServices(document.getElementById('mob-svc-btn'))" class="mob-arrow-btn" aria-label="Toggle services submenu" aria-expanded="false"><span class="mob-arrow" aria-hidden="true">&#9660;</span></button>
  </div>
  <div class="mob-services" id="mob-services-list" role="list">
    <a href="<?php echo home_url('/search-engine-optimization/'); ?>" onclick="closeMenu()">🔍 Search Engine Optimization</a>
    <a href="<?php echo home_url('/local-seo/'); ?>" onclick="closeMenu()">📍 Local SEO & Google Business</a>
    <a href="<?php echo home_url('/web-designing/'); ?>" onclick="closeMenu()">🌐 Web Design & Development</a>
    <a href="<?php echo home_url('/social-media-marketing/'); ?>" onclick="closeMenu()">📱 Social Media Marketing</a>
    <a href="<?php echo home_url('/pay-per-click/'); ?>" onclick="closeMenu()">🎯 Performance Marketing</a>
    <a href="<?php echo home_url('/ai-marketing-automation/'); ?>" onclick="closeMenu()">🤖 AI Marketing Automation</a>
    <a href="<?php echo home_url('/photography-videography/'); ?>" onclick="closeMenu()">📸 Photography &amp; Videography</a>
    <a href="<?php echo home_url('/graphic-designing/'); ?>" onclick="closeMenu()">🎨 Graphic Design</a>
    <a href="<?php echo home_url('/custom-software/'); ?>" onclick="closeMenu()">💻 Software Solutions</a>
  </div>
  <a href="<?php echo home_url('/about/'); ?>" onclick="closeMenu()">About Us</a>
  <a href="<?php echo home_url('/why-us/'); ?>" onclick="closeMenu()">Why Us</a>
  <a href="<?php echo home_url('/portfolio/'); ?>" onclick="closeMenu()">Portfolio</a>
  <a href="https://demo.qrenzy.com/websites-for/" onclick="closeMenu()">Live Demos</a>
  <a href="<?php echo get_permalink(get_option('page_for_posts')); ?>" onclick="closeMenu()">Blog</a>
  <a href="<?php echo home_url('/contact/'); ?>" onclick="closeMenu()">Contact</a>
  <div class="mob-btns">
    <a href="https://api.whatsapp.com/send?phone=919905700600" style="background:#25D366;color:#fff;" rel="noopener" target="_blank" aria-label="Chat with us on WhatsApp">💬 WhatsApp</a>
    <a href="<?php echo home_url('/free-seo-audit/'); ?>" style="background:#E31E24;color:#fff;" onclick="closeMenu()" aria-label="Get your free SEO audit">Free Audit →</a>
  </div>
</div>

<style>
/* ── DROPDOWN ─────────────────────────────────────────── */
.nav-links li.has-dropdown { position:relative; }
.drop-arrow { font-size:10px; opacity:0.5; margin-left:2px; }
.dropdown {
  display:none; position:absolute; top:calc(100% + 4px); left:50%;
  transform:translateX(-50%); background:#fff; border:1px solid #e8e8e4;
  border-radius:16px; padding:10px; min-width:265px;
  box-shadow:0 20px 60px rgba(0,0,0,0.12); z-index:999;
  list-style:none; margin:0;
}
/* invisible bridge so cursor can travel from nav link to dropdown */
.nav-links li.has-dropdown::after {
  content:''; position:absolute; top:100%; left:0; right:0; height:12px;
}
.dropdown::before {
  content:''; position:absolute; top:-6px; left:50%; transform:translateX(-50%);
  width:12px; height:12px; background:#fff; border:1px solid #e8e8e4;
  border-bottom:none; border-right:none; transform:translateX(-50%) rotate(45deg);
}
.dropdown li { margin:0; padding:0; }
.dropdown li a {
  display:block; padding:10px 14px; font-size:13px; font-weight:600;
  color:#333; border-radius:10px; white-space:nowrap; transition:background 0.15s;
}
.dropdown li a:hover { background:#f8f8f6; color:#E31E24; }
.nav-links li.has-dropdown:hover .dropdown { display:block; }

/* ── NAV PLAIN LINKS ──────────────────────────────────── */
.nav-plain-link { font-size:13px; font-weight:600; color:#555; text-decoration:none; transition:color 0.2s; white-space:nowrap; }
.nav-plain-link:hover { color:#0a0a0a; }
.nav-plain-red { color:#E31E24 !important; font-weight:700; }
.nav-plain-red:hover { color:#C01018 !important; }
.nav-sep { color:#ddd; font-size:14px; user-select:none; margin:0 2px; }

/* ── MOBILE SERVICES ──────────────────────────────────── */
.mob-services { display:none; flex-direction:column; padding-left:16px; border-left:2px solid #f0f0f0; margin:4px 0 8px; }
.mob-services.open { display:flex; }
.mob-services a { font-size:13px !important; color:#666 !important; padding:7px 0 !important; }
.mob-svc-toggle { display:flex; align-items:center; justify-content:space-between; width:100%; }
.mob-svc-toggle a { flex:1; font-weight:700; color:#0a0a0a; padding:14px 0; font-size:15px; }
.mob-arrow { display:inline-block; transition:transform 0.25s ease; font-size:16px; color:#333; }
.mob-arrow-btn { background:none; border:none; padding:10px 14px; cursor:pointer; line-height:1; display:flex; align-items:center; justify-content:center; min-width:44px; min-height:44px; }
.mob-svc-toggle.open .mob-arrow { transform:rotate(180deg); }
</style>

<main id="main-content">
<a class="skip-link screen-reader-text" href="#main-content">Skip to main content</a>

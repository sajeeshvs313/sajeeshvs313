<?php
/**
 * Template Name: Location Landing Page
 */
get_header();

$slug = get_post_field('post_name', get_the_ID());

// ── LOCATION DATA ─────────────────────────────────────────────────────
$locations = [

  // INDIA — Cities
  'digital-marketing-agency-thrissur' => [
    'city'       => 'Thrissur',
    'state'      => 'Kerala',
    'country'    => 'India',
    'flag'       => '🇮🇳',
    'lat'        => 10.5276,
    'lng'        => 76.2144,
    'zoom'       => 13,
    'headline'   => "Digital Marketing Agency in Thrissur",
    'subline'    => 'Qrenzy is Thrissur\'s trusted digital marketing agency — helping local businesses rank on Google, grow on social media and generate consistent leads since 2020.',
    'hook'       => 'Your customers are searching for a digital marketing agency in Thrissur right now. Are they finding you — or your competitor?',
    'market_desc'=> "As a leading digital marketing agency in Thrissur, Qrenzy has helped 200+ local businesses grow online since 2020. Thrissur's business landscape spans gold jewellery and textiles to healthcare, education, real estate and manufacturing. We understand this market deeply and build digital marketing strategies that deliver measurable results — more Google visibility, more calls and more customers for your Thrissur business.",
    'industries' => ['Jewellery & Retail','Healthcare & Clinics','Education & Coaching','Real Estate','Restaurants & Hotels','Manufacturing'],
    'stat1'      => ['200+', 'Thrissur Clients'],
    'stat2'      => ['#1', 'Thrissur Agency'],
    'stat3'      => ['5 Years', 'Serving Thrissur'],
    'testimonial'=> ['Qrenzy is the best digital marketing agency in Thrissur. They transformed our Google presence — we now get 3× more enquiries than before.', 'Rajan Mathew', 'Business Owner, Thrissur'],
    'cta_city'   => 'Thrissur',
    'area_served'=> 'Thrissur, Kerala, India',
    'long_content' => [
      'why_heading' => 'Why Thrissur Businesses Need a Local Digital Marketing Agency',
      'why_body'    => "Thrissur is Kerala's cultural and commercial heartland — a city where gold jewellery shops stand beside modern hospitals, engineering colleges and fast-growing real estate developers. The digital marketing needs of a Thrissur business are fundamentally different from those of a Mumbai startup or a Delhi enterprise. Your customers speak Malayalam, search in local context and make purchasing decisions based on community trust and local reputation.\n\nA generic digital marketing agency based in another city will not understand why Thrissur's gold jewellery segment peaks during Vishu and Onam, or why healthcare marketing here requires a different tone than it would in Bangalore. Qrenzy was founded in Thrissur in 2020. We live and work in this market. We understand which localities your customers come from, what search terms they actually use on Google, and how to build a digital presence that resonates with a Thrissur audience.\n\nOver the past five years, we have helped 200+ Thrissur businesses grow their online presence — from local clinics and coaching centres to jewellery retailers and real estate developers. Our SEO strategies are built around the keywords Thrissur customers actually search for. Our social media campaigns reflect local culture and seasonal buying patterns. Our Google Ads campaigns target Thrissur PIN codes with precision, ensuring your budget reaches exactly the customers most likely to walk through your door or call your number.\n\nThe result is digital marketing that does not just generate traffic — it generates customers from Thrissur and the surrounding region who are ready to buy.",
      'how_heading' => 'How We Help Thrissur Businesses Rank and Grow Online',
      'how_body'    => "Our digital marketing services for Thrissur businesses are built around one goal: generating measurable leads and sales from your target market. Here is how we approach it.\n\nWe start every Thrissur engagement with a comprehensive digital audit — reviewing your website's technical health, current Google rankings, Google Business Profile completeness and the competitive landscape for your industry in Thrissur. This gives us a precise baseline and identifies the fastest-win opportunities for your business.\n\nFor local SEO in Thrissur, we focus on the keywords your customers actually use — 'digital marketing agency in Thrissur', 'SEO services Thrissur', 'best clinics in Thrissur' — and build a systematic strategy to rank for them. This includes on-page optimization of your website, building local citations on JustDial, Sulekha and other Indian directories, earning backlinks from Kerala-based websites, and optimizing your Google Business Profile to appear in the Thrissur Local Pack.\n\nFor social media marketing in Thrissur, we create content that speaks to your local audience — in the right language, with culturally relevant references and timing aligned to local events, festivals and seasons. For Google Ads in Thrissur, we build tightly targeted campaigns using location-specific keywords, ensuring your ads appear when Thrissur customers are actively searching for your service.\n\nEvery strategy is tracked with monthly reporting showing exactly which keywords moved, how many leads were generated and what your return on investment looks like.",
      'process_heading' => 'Our Digital Marketing Process for Thrissur Clients',
      'process_steps'   => [
        ['Week 1', 'Free Audit & Discovery', 'We conduct a full digital audit of your website, Google Business Profile and competitor landscape in the Thrissur market. You receive a clear report showing exactly where you stand and what opportunities exist.'],
        ['Week 2', 'Strategy & Roadmap', 'We build a custom 90-day digital marketing roadmap for your Thrissur business — covering SEO targets, content plan, social media calendar and ad strategy tailored to your budget.'],
        ['Week 3–4', 'Implementation', 'Our team begins executing — technical SEO fixes, GBP optimization, content creation, social media setup and campaign launch. Everything is tracked from day one.'],
        ['Month 2–3', 'Growth & Optimization', 'We monitor rankings, leads and campaign performance weekly. Strategies are refined based on data, and you receive a monthly report showing measurable progress.'],
      ],
      'faq' => [
        ['How long does SEO take for a Thrissur business?', 'Most Thrissur businesses see measurable improvements in Google Maps visibility within 4–8 weeks of starting SEO. For organic website rankings, significant movement typically happens within 3–6 months. Local SEO in Thrissur tends to show results faster than national SEO because the competition is primarily local businesses rather than large national brands.'],
        ['What digital marketing services work best for Thrissur businesses?', 'For most Thrissur businesses, the highest-ROI combination is Google Business Profile optimization paired with local SEO. This gets you into the Google Maps Local Pack — the top 3 results that capture the majority of clicks for local searches. Social media marketing on Facebook and Instagram is also highly effective for Thrissur audiences, particularly for retail, F&B and service businesses.'],
        ['How much does digital marketing cost in Thrissur?', 'Qrenzy offers digital marketing packages for Thrissur businesses starting from ₹8,000 per month for foundational SEO and GBP management. Full-service digital marketing including SEO, social media and Google Ads typically ranges from ₹15,000 to ₹40,000 per month depending on the scope and competition level in your industry.'],
        ['Can you help my Thrissur business rank on Google Maps?', 'Yes — Google Maps ranking (the Local Pack) is one of our core specialties. We have helped dozens of Thrissur businesses move from invisible to top 3 on Google Maps through a combination of GBP optimization, citation building, review generation and local SEO. Results typically appear within 4–8 weeks.'],
        ['Do you work with small businesses in Thrissur?', 'Absolutely. The majority of our Thrissur clients are small and medium businesses — clinics, coaching centres, jewellery shops, restaurants, real estate agents and service providers. We build strategies that are appropriate for your budget and deliver measurable ROI regardless of company size.'],
      ],
    ],
  ],

  'digital-marketing-agency-kerala' => [
    'city'       => 'Kerala',
    'state'      => 'Kerala',
    'country'    => 'India',
    'flag'       => '🇮🇳',
    'lat'        => 10.8505,
    'lng'        => 76.2711,
    'zoom'       => 8,
    'headline'   => "Digital Marketing Agency in Kerala — Qrenzy",
    'subline'    => 'Kerala\'s trusted digital marketing agency — AI-powered SEO, social media marketing and performance ads for businesses across all 14 districts.',
    'hook'       => '83% of Kerala consumers research online before buying. Is your business showing up?',
    'market_desc'=> 'Kerala has one of India\'s highest internet penetration rates — meaning digital marketing here delivers exceptional returns. We work with businesses across Thrissur, Kochi, Calicut, Trivandrum and everywhere in between.',
    'industries' => ['Retail & E-commerce','Tourism & Hospitality','Healthcare','Education','Real Estate','NRI Services'],
    'stat1'      => ['500+', 'Kerala Businesses'],
    'stat2'      => ['18+', 'Years Experience'],
    'stat3'      => ['14', 'Districts Covered'],
    'testimonial'=> ['Best digital marketing agency in Kerala. Results-driven, transparent and always available.', 'Priya Nair', 'Entrepreneur, Kochi'],
    'cta_city'   => 'Kerala',
    'area_served'=> 'Kerala, India',
    'long_content' => [
      'why_heading' => 'Why Kerala Businesses Need Specialist Digital Marketing',
      'why_body'    => "Kerala has one of India's highest internet penetration rates — over 75% of the population is online, and smartphone usage is among the highest in the country. This means the opportunity for digital marketing in Kerala is enormous. But it also means competition for online visibility is fierce and growing every year.\n\nKerala's business landscape is uniquely diverse. You have the NRI-connected economy of Thrissur and Malappuram, the startup and IT ecosystem of Kochi's Infopark and Technopark, the tourism and hospitality industry concentrated along the backwaters and hill stations, the agricultural and export sector, and a rapidly growing healthcare and education industry spanning all 14 districts. Each of these segments has different digital marketing requirements, different audience behaviours and different keyword landscapes.\n\nQrenzy was founded in Thrissur, Kerala and has been serving businesses across all 14 Kerala districts since 2020. We understand how a Kochi IT startup's digital marketing needs differ from a Calicut restaurant's or a Trivandrum healthcare clinic's. We know which platforms Kerala audiences engage with most, how seasonal patterns like Onam and Vishu affect buying behaviour, and how to build bilingual content strategies that work for both English-speaking and Malayalam-speaking audiences.\n\nOur Kerala digital marketing strategies are not generic templates applied to a local market — they are custom-built campaigns designed for the specific competitive environment and audience behaviour of each Kerala city and industry.",
      'how_heading' => 'Digital Marketing Services Built for the Kerala Market',
      'how_body'    => "Qrenzy provides end-to-end digital marketing services for businesses across Kerala — from Kasaragod in the north to Thiruvananthapuram in the south. Our services are designed to work together as a system, not as isolated tactics.\n\nOur SEO services for Kerala businesses focus on ranking for the search queries Kerala customers actually use — location-specific keywords across all major cities, Malayalam-transliterated searches and high-intent service queries. We build technically sound websites, create content that earns local backlinks, and optimize Google Business Profiles across multiple locations.\n\nOur social media marketing for Kerala targets the platforms where Kerala audiences actually spend time — Facebook remains dominant for older demographics and NRI communities, Instagram drives discovery for retail and hospitality, and YouTube is a powerful channel for tutorials and brand storytelling in Malayalam and English. We create content calendars tuned to Kerala's festival calendar and cultural events.\n\nOur performance marketing for Kerala clients uses precisely geo-targeted Google Ads and Meta Ads campaigns, ensuring every rupee of ad spend reaches the most relevant audience in your specific Kerala market. Whether you are targeting Kochi's IT professionals, Thrissur's business community or Calicut's Gulf-connected families, we build campaigns that speak to each audience specifically.",
      'process_heading' => 'How We Onboard Kerala Clients',
      'process_steps'   => [
        ['Week 1', 'Kerala Market Audit', 'Full audit of your current digital presence across all platforms — website, GBP, social media and search rankings. We map your competitive landscape in the specific Kerala cities you target.'],
        ['Week 2', 'Kerala-Specific Strategy', 'Custom digital marketing roadmap built for your Kerala market — keyword targets, content approach, platform strategy and budget allocation across channels.'],
        ['Week 3–4', 'Launch & Setup', 'Technical SEO implementation, GBP optimization, social media setup and campaign launch. All work tracked and reported from day one.'],
        ['Ongoing', 'Monthly Reporting', 'Detailed monthly reports showing keyword rankings, traffic growth, lead volume and campaign performance across your Kerala target markets.'],
      ],
      'faq' => [
        ['What is the best digital marketing strategy for Kerala businesses?', 'For most Kerala businesses, the highest-ROI strategy combines Google Business Profile optimization, local SEO and Facebook/Instagram marketing. GBP optimization gets you into Google Maps results immediately. Local SEO builds sustainable organic traffic over 3–6 months. Social media drives brand awareness and engagement with Kerala\'s highly active online audience.'],
        ['How does Qrenzy handle businesses with multiple Kerala locations?', 'We manage multi-location digital marketing across Kerala efficiently — separate Google Business Profiles optimized for each location, location-specific landing pages on your website, and geo-targeted ad campaigns for each city. We have experience managing 4-location GBP profiles for clients across Thrissur, Kochi, Calicut and Trivandrum simultaneously.'],
        ['Does Qrenzy create Malayalam content?', 'Yes. We create bilingual content in English and Malayalam for clients who want to reach Malayalam-speaking audiences directly. This is particularly effective for social media marketing and local SEO targeting Tier 2 Kerala cities where Malayalam-language searches are common.'],
        ['How competitive is digital marketing in Kerala?', 'Competition varies significantly by city and industry. Kochi and Trivandrum are highly competitive for most service categories. Thrissur and Calicut are moderately competitive. Tier 2 and Tier 3 Kerala cities offer excellent ranking opportunities for businesses willing to invest in local SEO. We assess competition specifically for your market before recommending a strategy.'],
        ['What results can Kerala businesses expect from SEO?', 'Typical results for Kerala businesses investing in SEO: 40–80% increase in organic website traffic within 6 months, movement from page 2–3 to page 1 for target keywords within 3–4 months, and 2–3x increase in Google Business Profile impressions within 8 weeks. Results vary based on competition level and current website health.'],
      ],
    ],
  ],

  'digital-marketing-agency-kochi' => [
    'city'       => 'Kochi',
    'state'      => 'Kerala',
    'country'    => 'India',
    'flag'       => '🇮🇳',
    'lat'        => 9.9312,
    'lng'        => 76.2673,
    'zoom'       => 12,
    'headline'   => 'Digital Marketing Agency in Kochi',
    'subline'    => 'Growing Kochi businesses with data-driven SEO, Meta Ads and social media marketing.',
    'hook'       => "Kochi is Kerala's commercial capital. Your digital presence needs to match the city's ambition.",
    'market_desc'=> "Kochi's startup ecosystem, IT parks and tourism industry make it one of South India's most competitive digital markets. We bring proven strategies from Infopark to Marine Drive to help your brand dominate online.",
    'industries' => ['IT & Startups','Tourism & Hospitality','Shipping & Logistics','Retail & Fashion','Healthcare','Real Estate'],
    'stat1'      => ['150+', 'Kochi Clients'],
    'stat2'      => ['4.9★', 'Google Rating'],
    'stat3'      => ['48hr', 'Onboarding'],
    'testimonial'=> ['Our website traffic doubled in 60 days. Qrenzy knows what works in the Kochi market.', 'Anish Kumar', 'Director, Kochi Startup'],
    'cta_city'   => 'Kochi',
    'area_served'=> 'Kochi, Kerala, India',
    'long_content' => [
      'why_heading' => 'Why Kochi Businesses Need Specialist Digital Marketing',
      'why_body'    => "Kochi is Kerala's commercial capital and one of South India's most dynamic business cities. Home to Infopark, SmartCity and KOCHI-MUZIRIS Biennale, the city attracts IT companies, startups, international businesses and a highly educated, digitally sophisticated consumer base. Marketing to Kochi's audience requires a different approach than marketing to most other Kerala cities.\n\nKochi consumers are among the most research-intensive in Kerala. Before making any significant purchase — whether a service, product or professional engagement — they search extensively online, read reviews, compare options and check social proof. This means your digital presence in Kochi must be thorough, credible and visible across multiple platforms simultaneously.\n\nThe competitive landscape in Kochi is fierce. For most service categories, you are competing not just against other Kochi businesses but against national brands with large digital marketing budgets. Ranking on Google for 'digital marketing agency in Kochi' or 'best restaurants in Kochi' requires a systematic, well-resourced SEO strategy — not just a basic website.\n\nQrenzy has been serving Kochi businesses since 2020. We understand the city's diverse markets — the IT and startup ecosystem of Infopark, the tourism and hospitality cluster of Fort Kochi, the commercial activity of MG Road and the residential demand in Edapally and Kakkanad. We build digital marketing strategies that are precisely calibrated for the specific Kochi neighbourhood and industry you operate in.",
      'how_heading' => 'Digital Marketing Services for Kochi Businesses',
      'how_body'    => "Kochi businesses require a multi-channel digital marketing approach to compete effectively in this highly competitive market. Our Kochi digital marketing services are built around the channels and strategies that deliver the highest ROI for the city's specific audience.\n\nFor SEO in Kochi, we focus on neighbourhood-level keyword targeting — 'web design agency in Infopark', 'restaurants in Fort Kochi', 'real estate agents in Kakkanad' — as well as city-wide competitive keywords. We build technically excellent websites, create content that earns links from Kochi-based media and business directories, and optimize Google Business Profiles for maximum Local Pack visibility.\n\nFor social media marketing in Kochi, we recognize that the city's audience skews younger and more digitally engaged than most other Kerala cities. Instagram and LinkedIn are particularly powerful channels for Kochi businesses — Instagram for B2C brands targeting the city's young professional and tourist demographics, LinkedIn for B2B companies targeting Infopark and SmartCity's corporate community.\n\nFor Google Ads in Kochi, we build precise location-targeted campaigns that reach users searching from specific Kochi PIN codes. This is especially valuable for businesses that draw customers from particular neighborhoods — a clinic in Edapally or a restaurant in Fort Kochi can target users within a precise radius, maximizing ad efficiency.",
      'process_heading' => 'Our Process for Kochi Digital Marketing Clients',
      'process_steps'   => [
        ['Week 1', 'Kochi Market Analysis', 'Deep-dive into your competitive landscape in Kochi — who ranks, what they do well, where the gaps are and what it will take to outrank them in your specific Kochi market.'],
        ['Week 2', 'Strategy Development', 'Custom digital marketing strategy for your Kochi business — channel mix, keyword targets, content approach, budget allocation and 90-day milestones.'],
        ['Week 3–4', 'Full Implementation', 'Technical SEO fixes, GBP optimization, social profile setup, content creation and campaign launch — all executed simultaneously for maximum early impact.'],
        ['Ongoing', 'Growth & Reporting', 'Weekly rank tracking, monthly performance reports and continuous optimization based on data. You always know exactly what is working and what your investment is delivering.'],
      ],
      'faq' => [
        ['How competitive is SEO in Kochi compared to other Kerala cities?', 'Kochi is the most competitive digital marketing market in Kerala. Most service categories have well-established competitors with strong domain authority and significant review counts. This means SEO in Kochi typically takes 4–6 months to show significant results and requires a more comprehensive strategy than smaller Kerala cities. The payoff, however, is proportionally higher — Kochi has Kerala\'s largest online audience.'],
        ['Which industries in Kochi benefit most from digital marketing?', 'IT services, real estate, tourism and hospitality, healthcare, legal services, education and retail all show strong ROI from digital marketing in Kochi. The city\'s high internet penetration and research-intensive consumer behaviour mean that businesses with strong online presence consistently outperform those without, regardless of industry.'],
        ['Does Qrenzy work with Kochi startups?', 'Yes — we work with several Infopark and SmartCity-based startups. Startup digital marketing in Kochi typically focuses on building brand authority quickly, generating leads efficiently and establishing a content marketing foundation that compounds over time. We offer startup-friendly pricing with month-to-month flexibility.'],
        ['Can Qrenzy help Kochi businesses rank for tourism-related keywords?', 'Absolutely. Fort Kochi and the broader Kochi tourism market are highly competitive but offer significant opportunities for well-optimized businesses. We have helped hotels, restaurants, tour operators and experience providers rank for high-intent tourism keywords through a combination of SEO, Google Business Profile optimization and targeted content marketing.'],
        ['How much does digital marketing cost for Kochi businesses?', 'Kochi digital marketing packages start from ₹10,000 per month for foundational SEO and GBP management. Full-service digital marketing for Kochi businesses — covering SEO, social media and Google Ads — typically ranges from ₹20,000 to ₹60,000 per month depending on industry competition and scope.'],
      ],
    ],
  ],

  'digital-marketing-agency-calicut' => [
    'city'       => 'Calicut',
    'state'      => 'Kerala',
    'country'    => 'India',
    'flag'       => '🇮🇳',
    'lat'        => 11.2588,
    'lng'        => 75.7804,
    'zoom'       => 12,
    'headline'   => 'Digital Marketing Agency in Calicut',
    'subline'    => 'Calicut businesses deserve marketing that converts. We deliver measurable growth.',
    'hook'       => 'Calicut is growing fast. Your competitors are already investing in digital. Are you?',
    'market_desc'=> "Calicut (Kozhikode) is emerging as a major hub for food tech, education, healthcare and Gulf-connected businesses. We understand the Malabar market and build campaigns that resonate with local audiences.",
    'industries' => ['Food & Restaurants','Education','Healthcare','Textiles & Fashion','Gulf NRI Services','Real Estate'],
    'stat1'      => ['100+', 'Calicut Clients'],
    'stat2'      => ['90 Days', 'Avg. ROI Timeline'],
    'stat3'      => ['Page 1', 'Google Rankings'],
    'testimonial'=> ['Qrenzy understood our local market. Our restaurant now appears in the top 3 for every Calicut food search.', 'Mohammed Salim', 'Restaurant Owner, Calicut'],
    'cta_city'   => 'Calicut',
    'area_served'=> 'Calicut (Kozhikode), Kerala, India',
    'long_content' => [
      'why_heading' => 'Why Calicut Businesses Are Investing in Digital Marketing Now',
      'why_body'    => "Calicut — officially Kozhikode — is one of Kerala's fastest-growing digital markets. The city has historically been a major trading and commercial hub, driven by its Gulf NRI connections, its dominance in education, healthcare and food technology, and its thriving textile and retail sectors. Today, Calicut businesses are discovering what their Kochi counterparts learned earlier: digital marketing is no longer optional — it is the primary channel through which new customers discover, evaluate and choose businesses.\n\nCalicut's digital landscape has some unique characteristics. The city has a large Gulf-connected population — businesses here frequently need to market to both local Calicut audiences and NRI customers in the UAE, Oman, Bahrain and Qatar simultaneously. This bilingual, multi-geography marketing requirement is something Qrenzy is uniquely positioned to handle, given our presence in both Kerala and the Gulf region.\n\nCalicut's food technology scene — with companies like Noon and several other food startups — has put the city on the national startup map. Healthcare in Calicut is a major sector, with several large private hospitals competing aggressively for patients from Malabar and the Gulf. Education is another dominant vertical, with coaching centres and colleges competing heavily for students through digital channels.\n\nQrenzy's Calicut digital marketing strategies are built around the Malabar market's specific audience behaviour, competitive landscape and cultural context. We understand the Gulf connection, the Malayalam-English bilingual audience and the specific search patterns of Calicut consumers.",
      'how_heading' => 'How We Help Calicut Businesses Grow Online',
      'how_body'    => "Our digital marketing services for Calicut businesses are designed to address the city's specific opportunities and challenges. Whether you are targeting local Calicut customers, the broader Malabar region or Gulf NRI audiences, we build strategies that reach your exact target market effectively.\n\nFor local SEO in Calicut, we target the search queries Calicut customers use — 'digital marketing agency in Calicut', 'best hospitals in Kozhikode', 'coaching centres in Calicut' — and build a systematic ranking strategy around them. This includes optimizing your website for Calicut-specific keywords, building citations on Indian directories, earning local backlinks and optimizing your Google Business Profile for the Calicut Local Pack.\n\nFor Gulf NRI marketing from Calicut, we build campaigns that target Calicut-origin audiences in the UAE, Oman, Bahrain and Kuwait — particularly effective for real estate, investment services and premium consumer products that appeal to the NRI segment.\n\nFor social media marketing in Calicut, Facebook remains a dominant platform given the city's demographics. We create content calendars tuned to Malabar's cultural and religious calendar, ensuring your brand is visible and relevant during the moments that matter most to your audience.",
      'process_heading' => 'Our Calicut Digital Marketing Process',
      'process_steps'   => [
        ['Week 1', 'Malabar Market Audit', 'Full audit of your digital presence with specific focus on the Calicut competitive landscape — who ranks, what they do and where your fastest ranking opportunities exist.'],
        ['Week 2', 'Gulf + Local Strategy', 'If relevant, we build a dual-market strategy covering both local Calicut audiences and Gulf NRI targeting. Otherwise, we focus your strategy on maximum local impact.'],
        ['Week 3–4', 'Launch', 'Full implementation — SEO fixes, GBP optimization, social setup, content creation and campaign launch. Tracking and reporting configured from day one.'],
        ['Ongoing', 'Monthly Performance Review', 'Monthly reports covering keyword rankings in Calicut, traffic growth, lead volume, GBP performance and campaign ROI. Strategy adjusted based on what the data shows.'],
      ],
      'faq' => [
        ['What makes digital marketing in Calicut different from other Kerala cities?', 'Calicut\'s Gulf NRI connection is the biggest differentiator. Many Calicut businesses need to market simultaneously to local customers and Gulf-based NRI audiences who make purchase decisions for real estate, services and products in Calicut. This dual-market approach requires specific expertise that Qrenzy provides given our presence in both Kerala and the Gulf region.'],
        ['Which social media platforms work best for Calicut businesses?', 'Facebook is the dominant platform for Calicut businesses targeting local audiences, particularly for retail, healthcare and education. Instagram is growing fast among younger Calicut demographics. WhatsApp Business is essential for direct customer communication in the Malabar market. YouTube is effective for educational content and brand storytelling for the Gulf NRI audience.'],
        ['Can Qrenzy help Calicut businesses target Gulf NRI customers?', 'Yes — this is one of our core capabilities. We run targeted Meta and Google Ads campaigns reaching Calicut-origin audiences in the UAE, Oman, Bahrain and Kuwait. This is particularly effective for real estate developers, gold jewellery retailers, educational institutions and investment services targeting the NRI segment.'],
        ['How long does SEO take for a Calicut business?', 'Calicut has moderate SEO competition for most categories — less competitive than Kochi but more competitive than smaller Malabar cities. Most Calicut businesses see measurable ranking improvements within 8–12 weeks and significant organic traffic growth within 4–5 months. Google Maps visibility typically improves faster, within 4–8 weeks.'],
        ['Does Qrenzy create content in Malayalam for Calicut businesses?', 'Yes. We create bilingual content in English and Malayalam for Calicut clients who want to reach Malabar audiences in their preferred language. Malayalam content is particularly effective for Facebook marketing in Calicut, where local-language posts consistently outperform English posts in reach and engagement.'],
      ],
    ],
  ],

  // GULF — Countries
  'digital-marketing-agency-oman' => [
    'city'       => 'Oman',
    'state'      => '',
    'country'    => 'Oman',
    'flag'       => '🇴🇲',
    'lat'        => 23.5859,
    'lng'        => 58.4059,
    'zoom'       => 7,
    'headline'   => 'Digital Marketing Agency in Oman',
    'subline'    => 'Helping Oman businesses grow online with SEO, Google Ads and social media marketing.',
    'hook'       => "Oman's Vision 2040 is driving digital transformation. Is your business ready to lead?",
    'market_desc'=> "Oman's rapidly diversifying economy — from tourism and logistics to retail and real estate — demands sophisticated digital marketing. We've been serving Oman-based clients since 2022 with campaigns tailored to the Omani market and Arabic-speaking audiences.",
    'industries' => ['Tourism & Hospitality','Real Estate','Retail & Trading','Logistics & Shipping','Healthcare','F&B & Restaurants'],
    'stat1'      => ['50+', 'Oman Clients'],
    'stat2'      => ['English', '+ Arabic Campaigns'],
    'stat3'      => ['OMR', 'ROI Tracked'],
    'testimonial'=> ['Qrenzy helped us reach both Omani nationals and expats effectively. Our leads increased 4× in 3 months.', 'Ahmed Al Balushi', 'Business Owner, Muscat'],
    'cta_city'   => 'Oman',
    'area_served'=> 'Oman',
    'long_content' => [
      'why_heading' => 'Why Oman Businesses Need Specialist Digital Marketing in 2024',
      'why_body'    => "Oman's Vision 2040 is driving one of the most significant economic transformations in the Gulf — diversifying the economy away from oil dependence and toward tourism, logistics, manufacturing and services. This transformation is creating enormous digital marketing opportunities for businesses that position themselves correctly in Oman's evolving market.\n\nOman's digital landscape has matured significantly over the past five years. Internet penetration exceeds 95%, smartphone usage is near universal, and Omani consumers now research products and services online before making purchasing decisions — just as their counterparts in more mature digital markets do. The businesses that build strong digital presence in Oman now will have a significant competitive advantage as the market continues to mature.\n\nMarketing in Oman requires bilingual capability — English for the large expatriate community and international businesses, Arabic for Omani nationals who increasingly prefer to engage with brands in their native language. It also requires cultural sensitivity and an understanding of Oman's specific business customs, Islamic calendar and consumer behaviour patterns.\n\nQrenzy has been serving Oman-based clients since 2022, including Al Fanar Group — Oman's exclusive Grohe dealer with showrooms in Muscat, Sohar and Nizwa. We have built deep knowledge of the Omani market, the competitive landscape across major business categories, and the digital channels and strategies that deliver the best ROI for businesses targeting both Omani nationals and Oman's large expatriate community.",
      'how_heading' => 'Our Digital Marketing Services for Oman Businesses',
      'how_body'    => "Qrenzy offers comprehensive digital marketing services for businesses operating in Oman — from SEO and Google Ads to social media marketing and AI automation. All services are delivered with bilingual (English and Arabic) capability and deep understanding of the Omani market.\n\nFor SEO in Oman, we optimize websites to rank for the search queries Omani customers use — both English and Arabic language searches across Google Oman. We build technically sound websites optimized for Core Web Vitals, create high-quality content targeting Oman-specific keywords, and build authoritative backlinks from relevant Oman and Gulf-region websites. Our Google Business Profile optimization for Oman clients covers all four GBP best practices — completeness, reviews, posts and Q&A — with bilingual descriptions.\n\nFor social media marketing in Oman, Instagram and Snapchat are the dominant platforms for reaching Omani nationals, particularly among the youth demographic. LinkedIn is effective for B2B marketing to Oman's business community. Facebook remains relevant for reaching Oman's large Indian and other South Asian expatriate community. We build platform-specific content strategies that speak to each audience in the right language and cultural context.\n\nFor Google Ads in Oman, we build bilingual campaigns targeting users searching in both English and Arabic, with precise geographic targeting across Muscat, Sohar, Salalah and other major Omani cities.",
      'process_heading' => 'How We Work with Oman Clients',
      'process_steps'   => [
        ['Week 1', 'Oman Market Audit', 'Comprehensive audit of your digital presence in Oman — website technical health, current search rankings in both English and Arabic, GBP completeness and competitive analysis.'],
        ['Week 2', 'Bilingual Strategy', 'Custom digital marketing strategy for the Omani market — English and Arabic keyword targets, content plan, platform strategy and budget recommendations.'],
        ['Week 3–4', 'Implementation', 'Full execution — SEO optimization, bilingual GBP setup, social media content creation and ad campaign launch. All tracking configured from day one.'],
        ['Ongoing', 'Gulf Market Reporting', 'Monthly performance reports in English covering keyword rankings, traffic, lead volume and campaign ROI across your Oman digital marketing channels.'],
      ],
      'faq' => [
        ['Does Qrenzy create Arabic content for Oman businesses?', 'Yes. We create bilingual content in English and Arabic for Oman clients. Arabic content is essential for reaching Omani national customers who prefer to engage with brands in Arabic. We create Arabic social media posts, Arabic website content and bilingual Google Business Profile descriptions that speak to both Arabic and English-speaking audiences in Oman.'],
        ['Which digital marketing channels work best in Oman?', 'For B2C businesses in Oman, Instagram and Snapchat are the most effective social platforms for reaching Omani nationals. Google Search Ads deliver excellent ROI for high-intent service categories. WhatsApp Business is essential for customer communication in Oman. For B2B businesses, LinkedIn and Google Ads targeting professional keywords deliver the best results.'],
        ['How does SEO work differently in Oman compared to India?', 'SEO in Oman is generally less competitive than major Indian cities, which means ranking opportunities exist for well-optimized websites even with modest domain authority. However, you need to optimize for both English and Arabic searches, and local citations need to be built on Gulf-specific directories. Google Business Profile optimization is particularly impactful in Oman given the high proportion of local searches.'],
        ['Can Qrenzy manage Google Business Profiles for multiple Oman locations?', 'Yes — we have direct experience managing multi-location GBP accounts in Oman. We optimize each location profile individually with location-specific descriptions, photos, service listings and review management strategies. We currently manage GBP profiles for showrooms across multiple Omani cities for one of our Oman clients.'],
        ['What industries does Qrenzy serve in Oman?', 'We serve a wide range of Oman industries including retail and trading, hospitality and tourism, real estate and construction, healthcare, logistics, professional services and F&B. Our experience with Al Fanar Group — Oman\'s exclusive Grohe dealer — gives us deep expertise in premium product retail and multi-location business marketing in Oman.'],
      ],
    ],
  ],

  'digital-marketing-agency-uae' => [
    'city'       => 'UAE',
    'state'      => '',
    'country'    => 'UAE',
    'flag'       => '🇦🇪',
    'lat'        => 24.4539,
    'lng'        => 54.3773,
    'zoom'       => 7,
    'headline'   => 'Digital Marketing Agency in UAE',
    'subline'    => 'Data-driven SEO, Meta Ads and social media campaigns built for businesses across Dubai, Abu Dhabi and Sharjah.',
    'hook'       => "In the UAE, 99% of the population is online. If you're not visible digitally, you don't exist.",
    'market_desc'=> "The UAE is one of the world's most competitive digital markets — with high ad costs, high purchasing power and extremely discerning consumers. We build campaigns that cut through the noise with precision targeting and compelling creative.",
    'industries' => ['Real Estate','E-commerce','Retail & Luxury','F&B & Hospitality','Healthcare','Professional Services'],
    'stat1'      => ['AED', 'ROI Tracked'],
    'stat2'      => ['Dubai', '+ Abu Dhabi'],
    'stat3'      => ['4.8×', 'Avg. ROAS'],
    'testimonial'=> ['Professional, data-driven and always ahead of trends. Our Dubai brand grew 300% in 6 months.', 'Sarah Mitchell', 'Marketing Head, Dubai'],
    'cta_city'   => 'UAE',
    'area_served'=> 'UAE — Dubai, Abu Dhabi, Sharjah',
    'long_content' => [
      'why_heading' => 'Why UAE Businesses Need Expert Digital Marketing',
      'why_body'    => "The UAE is one of the world's most competitive digital marketing environments — and one of the most rewarding. With 99% internet penetration, extremely high smartphone usage and a consumer base that spans Emirati nationals, a large South Asian expatriate community, Western professionals and international tourists, the UAE offers unparalleled reach for businesses that market effectively online.\n\nThe challenge is that competition in the UAE is intense. Every major global brand has a UAE presence. Local businesses compete not just against each other but against international players with substantial marketing budgets. Standing out in this environment requires a sophisticated digital marketing strategy — not just a basic website and occasional social posts.\n\nUAE consumers are among the most brand-conscious and research-intensive in the world. Before making a significant purchase, they read reviews, compare options across multiple platforms and look for social proof. Your Google presence, Instagram feed, review profile and website quality all contribute to whether a UAE consumer chooses you or your competitor.\n\nQrenzy brings a unique advantage to UAE digital marketing: we combine deep Gulf market knowledge with the technical SEO expertise and content marketing capabilities of a full-service digital agency. Our team has been serving UAE-connected clients since 2020, building bilingual (English and Arabic) campaigns that reach the full spectrum of the UAE's diverse population.",
      'how_heading' => 'Digital Marketing Services for UAE Businesses',
      'how_body'    => "Our UAE digital marketing services are built for the specific competitive environment of the Emirates — high-quality, data-driven and designed to deliver measurable ROI in one of the world's most demanding markets.\n\nFor SEO in the UAE, we optimize websites to rank for high-intent search queries across both English and Arabic. We build technically excellent websites meeting Google's Core Web Vitals standards, create authoritative content targeting UAE-specific keywords, and build high-quality backlinks from UAE and Gulf-region websites. Local SEO in the UAE includes Google Business Profile optimization with bilingual descriptions, precise category selection and systematic review generation.\n\nFor social media marketing in the UAE, Instagram is the dominant platform for brand marketing to both Emirati and expatriate audiences. TikTok has grown rapidly and is particularly effective for reaching younger UAE demographics. LinkedIn is essential for B2B marketing to the UAE's large corporate community. We create platform-specific content strategies with the production quality UAE audiences expect.\n\nFor performance marketing in the UAE, we build Google Ads and Meta Ads campaigns that deliver precise audience targeting across Emirates, demographic groups and languages. High CPC keywords in the UAE demand well-structured campaigns with strong quality scores — our paid media team has managed AED millions in UAE ad spend.",
      'process_heading' => 'Our UAE Client Onboarding Process',
      'process_steps'   => [
        ['Week 1', 'UAE Market Audit', 'Comprehensive competitive analysis for your UAE market segment — who ranks, what they spend, where the gaps are and what strategy will deliver the fastest results.'],
        ['Week 2', 'UAE Strategy Build', 'Custom digital marketing strategy for the UAE — English and Arabic keyword targets, platform mix, content quality standards and budget recommendations appropriate for the UAE market.'],
        ['Week 3–4', 'Full Launch', 'Complete implementation — website optimization, bilingual GBP setup, social media content creation and ad campaign launch with conversion tracking configured from day one.'],
        ['Ongoing', 'UAE Performance Management', 'Weekly monitoring, monthly reports and continuous optimization. UAE digital marketing requires ongoing attention — algorithms, competition and audience behaviour all shift regularly.'],
      ],
      'faq' => [
        ['How competitive is digital marketing in the UAE?', 'The UAE is highly competitive across almost all business categories. Dubai in particular has intense competition for most service and product keywords. This means SEO in the UAE typically takes 4–8 months to show significant organic results and requires higher-quality content and backlink profiles than less competitive markets. Paid advertising delivers faster results but requires careful optimization to maintain profitable ROI given high UAE CPCs.'],
        ['Does Qrenzy create Arabic content for UAE businesses?', 'Yes. Arabic content is essential for reaching Emirati national customers and Arabic-speaking expatriates in the UAE. We create bilingual content strategies covering both English (for the large expatriate community and international audiences) and Arabic (for Emirati nationals and Arabic-speaking residents). Our Arabic content is created by native Arabic speakers with marketing expertise.'],
        ['Which social media platforms work best for UAE businesses?', 'Instagram is the most important platform for most UAE B2C businesses — it is where UAE consumers discover brands, make purchase decisions and engage with businesses. LinkedIn is essential for B2B companies targeting the UAE corporate sector. TikTok is rapidly growing for reaching younger UAE demographics. Snapchat remains strong for reaching Emirati nationals specifically.'],
        ['Can Qrenzy manage paid advertising in the UAE?', 'Yes. We manage Google Ads and Meta Ads campaigns for UAE businesses with budgets from AED 3,000 to AED 100,000+ per month. UAE paid advertising requires specific expertise — CPCs are high, competition is intense and audiences are sophisticated. Our UAE campaign management focuses on precise targeting, strong creative and continuous optimization to maintain profitable ROAS.'],
        ['What makes Qrenzy different from other UAE digital marketing agencies?', 'Most UAE digital marketing agencies focus exclusively on the UAE market. Qrenzy brings a broader perspective — we operate across India and the Gulf simultaneously, which gives us unique insight into the India-UAE business corridor and the Indian expatriate community in the UAE. This is particularly valuable for businesses targeting both markets or working with the large Kerala/Indian business community in the UAE.'],
      ],
    ],
  ],

  'digital-marketing-agency-bahrain' => [
    'city'       => 'Bahrain',
    'state'      => '',
    'country'    => 'Bahrain',
    'flag'       => '🇧🇭',
    'lat'        => 26.0667,
    'lng'        => 50.5577,
    'zoom'       => 10,
    'headline'   => 'Digital Marketing Agency in Bahrain',
    'subline'    => 'Growing Bahrain businesses with targeted SEO, paid ads and social media campaigns.',
    'hook'       => "Bahrain's fintech and retail boom is creating massive digital opportunities. Are you capturing them?",
    'market_desc'=> "Bahrain's open economy and thriving fintech, hospitality and retail sectors offer exciting digital marketing opportunities. We craft campaigns that work for both B2B and B2C clients in this unique Gulf market.",
    'industries' => ['Fintech & Banking','Retail & F&B','Real Estate','Healthcare','Tourism','Professional Services'],
    'stat1'      => ['BHD', 'ROI Tracked'],
    'stat2'      => ['Arabic', '+ English'],
    'stat3'      => ['Gulf', 'Market Experts'],
    'testimonial'=> ['Qrenzy gave us a clear digital strategy for Bahrain. Our online bookings increased significantly.', 'Fatima Al Khalifa', 'Hotel Manager, Manama'],
    'cta_city'   => 'Bahrain',
    'area_served'=> 'Bahrain',
    'long_content' => [
      'why_heading' => 'Why Bahrain Businesses Need Strategic Digital Marketing',
      'why_body'    => "Bahrain is the Gulf's most open and business-friendly economy — a compact but commercially sophisticated market with a strong fintech sector, a thriving F&B and hospitality industry, and a business community that connects deeply with the broader Gulf region. The Kingdom's small geographic size belies its significant commercial importance as a regional hub for banking, financial services and increasingly, technology.\n\nDigital marketing in Bahrain has unique characteristics. The consumer base is relatively small compared to the UAE or Saudi Arabia, which means digital marketing budgets can be more efficient — but it also means word of mouth and reputation travel quickly. A strong Google reviews profile and active social media presence matter enormously in Bahrain's connected business community.\n\nBahrain's consumer mix spans Bahraini nationals, a large South Asian expatriate community (particularly from Kerala and other Indian states), Arab expatriates and a significant Western professional community. Effective digital marketing in Bahrain needs to speak to this diverse audience appropriately — bilingual English and Arabic content for reaching across nationality lines, culturally relevant social content and strategic use of the platforms most popular with each demographic.\n\nQrenzy has been serving Gulf clients since 2020 and brings specific Gulf market expertise — bilingual content capability, understanding of Islamic calendar seasonality and deep familiarity with the digital platforms and consumer behaviour patterns of Gulf markets including Bahrain.",
      'how_heading' => 'Digital Marketing Services for Bahrain Businesses',
      'how_body'    => "Our Bahrain digital marketing services cover the full spectrum of digital channels — SEO, social media marketing, Google Ads, content marketing and AI marketing automation — all delivered with bilingual (English and Arabic) capability and Gulf market expertise.\n\nFor SEO in Bahrain, we optimize your website to rank for high-intent search queries from Bahraini consumers. Given Bahrain's relatively small online audience, ranking well for even moderately competitive keywords can deliver significant business impact. We build technically sound websites, create high-quality content targeting Bahrain-specific keywords and build authoritative backlinks from relevant Gulf-region websites.\n\nFor social media marketing in Bahrain, Instagram and Snapchat are the primary platforms for reaching Bahraini nationals. LinkedIn is valuable for B2B marketing to Bahrain's financial services and corporate community. Facebook remains effective for reaching Bahrain's Indian and Asian expatriate community. We build platform-specific content strategies calibrated to each audience segment.\n\nFor Google Ads in Bahrain, we build bilingual campaigns targeting users searching in both English and Arabic. Bahrain's smaller market size means CPCs are generally lower than in the UAE, which can deliver excellent ROI for well-managed paid search campaigns in the right categories.",
      'process_heading' => 'Our Process for Bahrain Digital Marketing Clients',
      'process_steps'   => [
        ['Week 1', 'Bahrain Market Audit', 'Full digital presence audit with competitive analysis specific to your Bahrain market segment. We identify ranking opportunities and the fastest-win improvements for your business.'],
        ['Week 2', 'Gulf-Calibrated Strategy', 'Custom strategy built for Bahrain — platform mix, bilingual content approach, keyword targets and budget recommendations appropriate for the Bahraini market.'],
        ['Week 3–4', 'Launch & Implementation', 'Full execution — website optimization, GBP setup, social media launch and ad campaign configuration. All tracking and reporting configured from day one.'],
        ['Ongoing', 'Bahrain Performance Reports', 'Monthly performance reports covering search rankings, traffic growth, social media engagement and campaign ROI across all your Bahrain digital marketing channels.'],
      ],
      'faq' => [
        ['Which digital marketing channels work best in Bahrain?', 'For B2C businesses, Instagram and Snapchat are most effective for reaching Bahraini nationals. Google Search Ads deliver strong ROI for service businesses. WhatsApp Business is essential for customer communication. For B2B businesses, LinkedIn and Google Ads targeting commercial keywords deliver the best Bahrain results.'],
        ['Does Qrenzy create Arabic content for Bahrain businesses?', 'Yes. Arabic content is important for reaching Bahraini national customers and Arabic-speaking expatriates. We create bilingual content in English and Arabic, including social media posts, website content and Google Business Profile descriptions optimized for both languages.'],
        ['How long does SEO take for a Bahrain business?', 'Bahrain is less digitally competitive than the UAE for most categories, which means SEO results typically come faster. Most Bahrain businesses see measurable ranking improvements within 8–10 weeks and significant organic traffic growth within 3–4 months. Google Maps visibility often improves within 4–6 weeks.'],
        ['Can Qrenzy help Bahrain businesses target the Indian expatriate community?', 'Yes — this is something we are uniquely positioned to do given our Kerala base and Gulf expertise. Bahrain has a large Keralite and Indian expatriate community, and we create targeted social media campaigns that reach this audience specifically in their preferred language and cultural context.'],
        ['What industries in Bahrain benefit most from digital marketing?', 'Financial services, hospitality and F&B, real estate, retail, healthcare and professional services all show strong ROI from digital marketing in Bahrain. The fintech sector in particular has become highly competitive digitally, with many players investing heavily in SEO and content marketing to reach Bahrain\'s business community.'],
      ],
    ],
  ],


  'digital-marketing-agency-trivandrum' => [
    'city'       => 'Trivandrum',
    'state'      => 'Kerala',
    'country'    => 'India',
    'flag'       => '🇮🇳',
    'lat'        => 8.5241,
    'lng'        => 76.9366,
    'zoom'       => 12,
    'headline'   => 'Digital Marketing Agency in Trivandrum',
    'subline'    => 'Helping Trivandrum businesses rank on Google, grow on social media and scale with AI-powered marketing.',
    'hook'       => "Trivandrum is Kerala's capital — and the competition for digital visibility is fierce. Where do you rank?",
    'market_desc'=> "Trivandrum (Thiruvananthapuram) is home to Technopark, government institutions, tourism hubs and a booming startup ecosystem. We craft digital strategies tailored for the capital city's diverse and tech-savvy audience.",
    'industries' => ['IT & Software','Tourism & Hospitality','Government & Education','Healthcare','Retail & E-commerce','Real Estate'],
    'stat1'      => ['Page 1', 'Google Rankings'],
    'stat2'      => ['90 Days', 'Avg. Results'],
    'stat3'      => ['18+', 'Years Experience'],
    'testimonial'=> ["Qrenzy helped us stand out in Trivandrum's competitive IT space. Our leads doubled in 4 months.", 'Sreejith Nair', 'Director, Technopark Startup'],
    'cta_city'   => 'Trivandrum',
    'area_served'=> 'Trivandrum (Thiruvananthapuram), Kerala, India',
    'long_content' => [
      'why_heading' => 'Why Trivandrum Businesses Need Strong Digital Marketing',
      'why_body'    => "Trivandrum — Kerala's capital and home to Technopark, one of India's largest IT parks — is a city in rapid digital transformation. The presence of Technopark and its 70,000+ IT professionals has created a highly digitally literate consumer base that expects businesses to have a polished, credible online presence. If your website looks dated or your Google Business Profile is incomplete, you are losing customers to competitors before they ever contact you.\n\nTrivandrum's economy spans government and public sector institutions, a growing private IT sector centred around Technopark, a substantial tourism and hospitality industry drawing visitors to Kovalam, Varkala and the surrounding beaches and backwaters, and a well-established healthcare and education sector. Each of these verticals has distinct digital marketing requirements and audience behaviours.\n\nThe competitive landscape in Trivandrum has intensified significantly over the past three years. As more Trivandrum businesses invest in digital marketing, the bar for what it takes to rank on Google and stand out on social media has risen. Simply having a website is no longer enough — you need technically excellent SEO, compelling content and an active social media presence to compete effectively.\n\nQrenzy brings both the technical expertise to compete in Trivandrum's sophisticated digital market and the Kerala market knowledge to ensure your campaigns speak authentically to Trivandrum's local audience. From Technopark startups to Kovalam hotels to Trivandrum's thriving medical tourism sector, we have built digital strategies for the full range of Trivandrum's business landscape.",
      'how_heading' => 'Digital Marketing Services for Trivandrum Businesses',
      'how_body'    => "Our Trivandrum digital marketing services are built around the city's specific competitive environment and audience profile. Whether you are targeting Trivandrum's IT professionals, its tourism visitors or its local residential consumer base, we build strategies precisely calibrated to your audience.\n\nFor SEO in Trivandrum, we focus on the search queries Trivandrum customers actually use — from 'digital marketing agency in Trivandrum' to 'hotels near Kovalam' to 'best clinics in Thiruvananthapuram'. We optimize websites for technical excellence, create content that earns links from Trivandrum and Kerala-based sources, and build Google Business Profile completeness that puts you in the Local Pack for your most valuable search queries.\n\nFor social media marketing in Trivandrum, the city's large IT professional community is highly active on LinkedIn and Instagram. Technopark and SmartCity companies benefit specifically from LinkedIn marketing for B2B lead generation. Tourism businesses benefit from Instagram and Google Business Profile photos that showcase Trivandrum's visual appeal to potential visitors.\n\nFor Google Ads in Trivandrum, we build location-targeted campaigns covering the city's key areas — Technopark, Pattom, Kowdiar, Kovalam, Varkala and beyond. Precision geo-targeting ensures your ad budget reaches the most relevant audience for your business.",
      'process_heading' => 'Our Trivandrum Digital Marketing Process',
      'process_steps'   => [
        ['Week 1', 'Trivandrum Market Analysis', 'Full audit of your current digital presence and competitive landscape in Trivandrum. We identify where your fastest ranking opportunities are and what your competitors are doing that you are not.'],
        ['Week 2', 'Custom Strategy', 'Digital marketing roadmap built specifically for your Trivandrum business — keyword targets, content plan, platform strategy and 90-day milestones aligned to your business goals.'],
        ['Week 3–4', 'Full Implementation', 'Technical SEO, GBP optimization, social media setup and ad campaign launch — all executed simultaneously for maximum early impact. Tracking configured from day one.'],
        ['Ongoing', 'Growth Management', 'Weekly rank monitoring, monthly detailed reports and continuous strategy optimization based on performance data from your Trivandrum market.'],
      ],
      'faq' => [
        ['How competitive is digital marketing in Trivandrum?', 'Trivandrum is the second most competitive digital marketing market in Kerala after Kochi, driven largely by the IT sector\'s digital sophistication. Most major service categories have established competitors with strong online presence. SEO in Trivandrum typically takes 3–5 months for significant results. Technopark-related B2B keywords are particularly competitive given the number of IT companies targeting the same audience.'],
        ['Does Qrenzy work with Technopark companies in Trivandrum?', 'Yes. We work with IT services companies, software development firms and technology startups based in Technopark and SmartCity. B2B digital marketing for Trivandrum IT companies typically focuses on LinkedIn marketing, technical content marketing, and SEO targeting specific technology keywords relevant to their service offerings.'],
        ['Can Qrenzy help Trivandrum tourism businesses rank on Google?', 'Absolutely. Tourism is one of the highest-opportunity categories in Trivandrum digital marketing. Hotels, resorts, homestays and tour operators in Kovalam, Varkala and Trivandrum city benefit significantly from well-optimized Google Business Profiles, SEO targeting tourist search queries, and Instagram content marketing showcasing the destination\'s visual appeal.'],
        ['What social media platforms work best in Trivandrum?', 'LinkedIn is essential for Trivandrum B2B businesses targeting the IT sector. Instagram is highly effective for tourism, hospitality and retail businesses. Facebook remains relevant for reaching older Trivandrum demographics and the broader Kerala audience. WhatsApp Business is important for direct customer communication across all categories.'],
        ['How much does digital marketing cost for Trivandrum businesses?', 'Trivandrum digital marketing packages start from ₹9,000 per month for foundational SEO and GBP management. Full-service packages covering SEO, social media and Google Ads typically range from ₹18,000 to ₹50,000 per month depending on industry and scope. We offer specific packages for Technopark startups with startup-friendly pricing.'],
      ],
    ],
  ],

  'digital-marketing-agency-qatar' => [
    'city'       => 'Qatar',
    'state'      => '',
    'country'    => 'Qatar',
    'flag'       => '🇶🇦',
    'lat'        => 25.2854,
    'lng'        => 51.5310,
    'zoom'       => 10,
    'headline'   => 'Digital Marketing Agency in Qatar',
    'subline'    => 'Helping Qatar businesses grow online with targeted SEO, Google Ads and social media marketing.',
    'hook'       => "Qatar's post-World Cup boom is creating massive digital opportunities. Is your business positioned to capture them?",
    'market_desc'=> "Qatar's rapidly growing economy — fuelled by tourism, construction, retail and financial services — demands sharp digital marketing. We build bilingual (English + Arabic) campaigns built for Qatari nationals, expats and international audiences.",
    'industries' => ['Tourism & Hospitality','Real Estate & Construction','Retail & Luxury','F&B & Restaurants','Financial Services','Healthcare'],
    'stat1'      => ['QAR', 'ROI Tracked'],
    'stat2'      => ['Arabic', '+ English'],
    'stat3'      => ['Gulf', 'Market Experts'],
    'testimonial'=> ["Qrenzy understood Qatar's market nuances. Our F&B brand saw a 3x increase in footfall from digital campaigns.", 'Hamad Al Thani', 'Restaurant Chain Owner, Doha'],
    'cta_city'   => 'Qatar',
    'area_served'=> 'Qatar — Doha & beyond',
    'long_content' => [
      'why_heading' => 'Why Qatar Businesses Need Specialist Digital Marketing',
      'why_body'    => "Qatar's post-World Cup transformation has accelerated digital adoption across every sector of its economy. The country invested billions in infrastructure, hospitality, retail and entertainment for the World Cup — and many of those investments are now permanent fixtures of Qatar's business landscape, creating ongoing digital marketing opportunities in tourism, hospitality, retail and services.\n\nQatar's digital marketing landscape has specific characteristics that require specialist knowledge. The country has a relatively small but extremely high-income consumer base — Qatari nationals with substantial purchasing power, a large corporate expatriate community and a growing international tourism segment. Marketing effectively to these three distinct groups simultaneously requires a sophisticated, multi-audience approach.\n\nQatar's social media environment is dominated by Instagram and Snapchat for consumer audiences, with LinkedIn increasingly important for the country's growing B2B and corporate services sector. Arabic content is essential for reaching Qatari nationals, while English content is needed for the large Western and South Asian expatriate communities.\n\nQrenzy brings both Gulf market expertise and full-service digital marketing capabilities to Qatar-based businesses. Our experience serving clients across Oman, UAE and the broader Gulf region means we understand the cultural, linguistic and business context that effective Qatar digital marketing requires. We build bilingual campaigns that speak to Qatar's diverse audience in the right language, on the right platforms, with the right cultural context.",
      'how_heading' => 'Digital Marketing Services for Qatar Businesses',
      'how_body'    => "Our Qatar digital marketing services span the full range of digital channels — all delivered with the bilingual (English and Arabic) capability and Gulf market expertise that Qatar's unique market requires.\n\nFor SEO in Qatar, we optimize your website to rank for the search queries Qatar's consumers and businesses use — both English and Arabic searches across Google Qatar. Qatar's search market is less competitive than the UAE for many categories, creating genuine ranking opportunities for well-optimized websites in a shorter timeframe. We build technically excellent websites, create Qatar-relevant content and build authority through Gulf-region backlinks.\n\nFor social media marketing in Qatar, Instagram is the dominant platform for reaching consumers across both Qatari and expatriate demographics. Snapchat has strong penetration among Qatari nationals, particularly the youth demographic. LinkedIn is valuable for reaching Qatar's large corporate and professional community. We create platform-specific content strategies with the production quality Qatar's sophisticated consumer base expects.\n\nFor performance marketing in Qatar, we build Google Ads and Meta Ads campaigns targeting Qatar audiences with bilingual ad creative and precise geographic targeting. Qatar's smaller market size compared to the UAE often means lower CPCs and excellent ROI potential for well-managed paid campaigns in the right categories.",
      'process_heading' => 'How We Work with Qatar Clients',
      'process_steps'   => [
        ['Week 1', 'Qatar Market Audit', 'Full digital presence audit and competitive analysis specific to your Qatar market. We map who ranks, what they do, and where your fastest digital marketing opportunities exist.'],
        ['Week 2', 'Bilingual Qatar Strategy', 'Custom digital marketing strategy for Qatar — English and Arabic keyword targets, platform mix, content quality standards and budget recommendations for the Qatari market.'],
        ['Week 3–4', 'Launch', 'Full implementation — website optimization, bilingual GBP setup, social media content creation and ad campaign launch with full tracking configured from day one.'],
        ['Ongoing', 'Qatar Performance Management', 'Monthly reports covering search rankings in both English and Arabic, traffic growth, lead volume and campaign ROI across your Qatar digital marketing channels.'],
      ],
      'faq' => [
        ['How does SEO in Qatar differ from other Gulf markets?', 'Qatar is generally less digitally competitive than the UAE for most categories, which means ranking opportunities are more accessible for businesses willing to invest in quality SEO. However, bilingual optimization for both English and Arabic is important, and the relatively small population means search volumes are lower than the UAE even for high-traffic keywords. Well-executed local SEO in Qatar can deliver significant business impact with a more modest investment than comparable UAE campaigns.'],
        ['Which social media platforms are most effective in Qatar?', 'Instagram is the primary platform for B2C marketing in Qatar, effective across both Qatari and expatriate audiences. Snapchat has strong penetration among Qatari nationals under 35. LinkedIn is important for B2B marketing and reaching Qatar\'s professional community. TikTok is growing rapidly among younger demographics. WhatsApp is the primary messaging and customer service channel across all demographics.'],
        ['Does Qrenzy create Arabic content for Qatar businesses?', 'Yes. Arabic content is essential for reaching Qatari national customers effectively. We create bilingual content in English and Arabic including social media posts, website copy and Google Business Profile descriptions. All Arabic content is reviewed for cultural appropriateness and natural language quality.'],
        ['Can Qrenzy help F&B businesses in Qatar grow their digital presence?', 'Yes — F&B is one of the strongest digital marketing categories in Qatar. Restaurants and cafes in Doha benefit significantly from well-optimized Google Business Profiles, strong Instagram presence and targeted Google Ads. Qatar\'s dining-out culture and tourist visitors create consistent demand for F&B discovery online, making digital marketing particularly valuable for this sector.'],
        ['What is the typical ROI timeline for digital marketing in Qatar?', 'SEO in Qatar typically shows measurable results within 8–12 weeks for Google Maps and 3–5 months for organic search rankings. Paid advertising delivers immediate visibility from day one, with ROI optimization typically stabilizing within 4–6 weeks as campaign data accumulates. Social media brand building typically shows engagement growth within 4–6 weeks of consistent, quality content.'],
      ],
    ],
  ],

  'digital-marketing-agency-dubai' => [
    'city'       => 'Dubai',
    'state'      => 'UAE',
    'country'    => 'UAE',
    'flag'       => '🇦🇪',
    'lat'        => 25.2048,
    'lng'        => 55.2708,
    'zoom'       => 11,
    'headline'   => 'Digital Marketing Agency in Dubai',
    'subline'    => 'Premium SEO, performance marketing and social media for Dubai businesses.',
    'hook'       => 'Dubai never stops. Neither should your digital marketing.',
    'market_desc'=> "Dubai is a global city with a local heartbeat — from Deira's trading community to DIFC's financial elite to JBR's tourism crowd. We build hyper-targeted campaigns that speak to Dubai's diverse, high-intent audiences.",
    'industries' => ['Real Estate','Tourism & Hospitality','Retail & Luxury','F&B','Healthcare & Wellness','E-commerce'],
    'stat1'      => ['4.8×', 'Dubai Avg. ROAS'],
    'stat2'      => ['Top 3', 'Google Rankings'],
    'stat3'      => ['24hr', 'Campaign Launch'],
    'testimonial'=> ['In Dubai, speed and precision matter. Qrenzy delivered both — our campaign went live in 24 hours.', 'Khalid Rahman', 'CEO, Dubai Retail Brand'],
    'cta_city'   => 'Dubai',
    'area_served'=> 'Dubai, UAE',
    'long_content' => [
      'why_heading' => 'Why Dubai Businesses Need Expert Digital Marketing',
      'why_body'    => "Dubai is the Gulf's most competitive digital marketing market — and its most rewarding. The city's extraordinary consumer spending power, its position as a global business hub and its massive international tourist footfall create extraordinary opportunities for businesses that market effectively online. But the competition is intense at every level — local, regional and global brands all compete for Dubai's consumers simultaneously.\n\nDubai's consumer base is uniquely diverse. Emirati nationals, Arab expatriates, South Asian professionals, Western executives and international tourists all use Dubai's businesses — and each group requires a different marketing approach. Content that resonates with Emirati nationals may not appeal to the South Asian expatriate community. Campaigns that perform well in English may underperform with Arabic-speaking audiences. Dubai digital marketing requires genuine multicultural sophistication.\n\nThe digital channels Dubai consumers use are also evolving rapidly. Instagram remains dominant for brand discovery among most demographics. TikTok has surged dramatically among younger Dubai audiences. Google Search captures high-intent commercial queries from consumers ready to spend. LinkedIn is essential for reaching Dubai's large professional and corporate community. Managing multiple channels simultaneously, with consistent quality and relevant targeting, requires a properly resourced digital marketing team.\n\nQrenzy brings both the strategic sophistication and the technical execution capability that Dubai digital marketing demands. We have been serving Dubai-connected clients since 2020, building campaigns that speak to the city's diverse audience with the production quality and strategic intelligence Dubai consumers expect.",
      'how_heading' => 'Our Digital Marketing Services for Dubai Businesses',
      'how_body'    => "Our Dubai digital marketing services are built for the city's demanding competitive environment. Every service we deliver meets the quality standard Dubai consumers and search algorithms expect.\n\nFor SEO in Dubai, we build technically excellent websites optimized for Core Web Vitals, create high-quality content targeting Dubai-specific keywords in both English and Arabic, and build authoritative backlinks from relevant UAE and international websites. Dubai SEO requires both technical perfection and genuine content depth — thin or templated content will not compete in Dubai's sophisticated search environment.\n\nFor social media marketing in Dubai, we create content that matches the production quality Dubai audiences have come to expect from brands they follow. Low-quality visuals and generic captions do not perform in Dubai's Instagram-saturated environment. We produce photography-quality graphics, video content and strategic copy that builds genuine audience engagement and brand authority.\n\nFor Google Ads and Meta Ads in Dubai, we build precision-targeted campaigns that deliver measurable ROAS in a high-CPC environment. Dubai paid advertising requires continuous optimization — we monitor campaigns weekly and adjust targeting, creative and bidding strategies based on performance data to maintain profitable returns in a competitive auction environment.",
      'process_heading' => 'How We Work with Dubai Clients',
      'process_steps'   => [
        ['Week 1', 'Dubai Competitive Analysis', 'Deep competitive analysis for your Dubai market — who ranks, what they spend, what content they create and what strategy will realistically deliver results in your specific Dubai niche.'],
        ['Week 2', 'Dubai Strategy Development', 'Custom digital marketing strategy built for Dubai\'s competitive environment — quality standards, channel mix, keyword targets, content approach and budget appropriate for the Dubai market.'],
        ['Week 3–4', 'Premium Implementation', 'Full execution at Dubai quality standards — website optimization, bilingual GBP setup, premium social content creation and ad campaign launch with full tracking configured.'],
        ['Ongoing', 'Dubai Performance Management', 'Weekly monitoring, monthly performance reports and continuous optimization. Dubai digital marketing requires ongoing active management to maintain competitive position.'],
      ],
      'faq' => [
        ['How competitive is SEO in Dubai?', 'Dubai is the most competitive SEO market in the Gulf and among the most competitive in the MENA region overall. Most commercial categories have well-established competitors with significant domain authority and large content libraries. Achieving first-page rankings in Dubai typically takes 6–12 months of consistent, high-quality SEO investment. However, the payoff is proportional — Dubai\'s consumer spending power means even a modest improvement in organic visibility can deliver significant business value.'],
        ['What social media strategy works for Dubai businesses?', 'The most effective Dubai social media strategy combines Instagram for brand building and discovery, LinkedIn for B2B lead generation, Google Business Profile posts for local visibility, and targeted paid amplification to extend reach. Content quality is critical in Dubai — invest in professional photography and video production. Post consistently — minimum 4-5 times per week on Instagram for meaningful growth in Dubai\'s competitive feed environment.'],
        ['Does Qrenzy create Arabic content for Dubai businesses?', 'Yes. Bilingual English and Arabic content is important for Dubai businesses targeting the Emirati and Arab expatriate community. We create Arabic social media content, website copy and Google Business Profile descriptions that speak naturally to Arabic-speaking Dubai audiences. All Arabic content is created by native Arabic speakers with digital marketing expertise.'],
        ['What budget is needed for effective digital marketing in Dubai?', 'Effective digital marketing in Dubai requires a meaningful investment given the market\'s competitiveness. For SEO, a minimum of AED 2,000–3,500 per month for 12+ months is needed to compete meaningfully in most categories. For Google Ads in Dubai, minimum budgets of AED 3,000–5,000 per month are needed to generate sufficient data and visibility. Social media management starts from AED 2,500 per month for quality execution.'],
        ['Can Qrenzy help Dubai businesses reach Indian expatriate customers?', 'Yes — this is one of our unique strengths. Dubai has one of the world\'s largest Indian expatriate communities, including a very large Kerala and South Indian community. We build campaigns specifically targeting Dubai\'s Indian expatriate audience in their preferred languages and cultural context, which is particularly valuable for Indian restaurants, gold jewellery retailers, real estate developers and service businesses targeting this community.'],
      ],
    ],
  ],

  // ── MALABAR ──────────────────────────────────────────────────────────
  'malabar' => [
    'city'       => 'Malabar',
    'state'      => 'Kerala',
    'country'    => 'India',
    'flag'       => '🇮🇳',
    'lat'        => 11.2588,
    'lng'        => 75.7804,
    'zoom'       => 9,
    'headline'   => 'Digital Marketing Agency in Malabar',
    'subline'    => 'Qrenzy serves businesses across the Malabar region — Kozhikode, Malappuram, Kannur, Kasaragod, Wayanad and Palakkad — with AI-powered SEO, social media marketing and performance ads.',
    'hook'       => 'Malabar businesses are going digital fast. Is your business keeping up — or falling behind your competitors?',
    'market_desc'=> "The Malabar region of Kerala — spanning Kozhikode (Calicut), Malappuram, Kannur, Kasaragod, Wayanad and Palakkad — is one of India's most dynamic and fast-growing commercial regions. With a massive NRI population connected to the Gulf, a thriving textile and trading economy, rapidly expanding healthcare and education sectors and one of Kerala's highest smartphone penetration rates, Malabar businesses have enormous digital marketing potential that most agencies are only beginning to recognise.\n\nQrenzy Digital Solutions serves businesses across the entire Malabar region. We understand the unique cultural and commercial characteristics of this market — the Gulf NRI influence on purchasing decisions, the dominant role of community trust and word-of-mouth, the importance of Malayalam-language content and the local business seasonality tied to festivals, harvests and Gulf remittance cycles. Our digital marketing strategies for Malabar businesses are built around these realities, not copied from generic templates designed for metro markets.",
    'industries' => ['Textiles & Fashion','Healthcare & Clinics','Education & Coaching','Real Estate','Restaurants & F&B','Gulf NRI Services','Gold & Jewellery','Tourism & Hospitality'],
    'stat1'      => ['200+', 'Kerala Clients'],
    'stat2'      => ['Top 5', 'Malabar Ranking'],
    'stat3'      => ['6 Districts', 'Covered'],
    'testimonial'=> ['Qrenzy understands the Malabar market better than any other agency we have worked with. Our Google rankings improved dramatically within 3 months.', 'Faisal Rahman', 'Business Owner, Kozhikode'],
    'cta_city'   => 'Malabar',
    'area_served'=> 'Malabar, Kerala, India',
    'long_content' => [
      'why_heading' => 'Why Malabar Businesses Need a Specialist Digital Marketing Agency',
      'why_body'    => "The Malabar region is not a single market — it is six distinct districts, each with its own commercial character, consumer behaviour and digital landscape. Kozhikode is a major trading and textile hub with strong Gulf connections. Malappuram has one of the highest NRI populations in Kerala, with Gulf remittances driving significant consumer spending. Kannur is known for its weaving industry, political culture and growing service economy. Kasaragod is a border district with a unique multilingual consumer base. Wayanad is a tourism and agriculture hub with growing hospitality and real estate sectors. Palakkad is an industrial and agricultural centre with a distinct commercial culture.\n\nA successful digital marketing strategy for a Malabar business must account for these nuances. It must understand that Gulf NRI connections mean your potential customers may be researching your business from Oman, UAE or Qatar before making decisions back home. It must account for the dominant role of Malayalam-language social media content in driving local engagement. It must leverage the community trust networks — WhatsApp groups, local Facebook communities and Malayalam YouTube channels — that influence Malabar purchasing decisions more than any paid advertisement.\n\nQrenzy brings deep knowledge of the Malabar market to every client engagement. We have served businesses across Kozhikode, Malappuram, Kannur and the wider Malabar region — understanding what works here and what does not. Our strategies are built for Malabar, not adapted from campaigns designed for Bangalore or Mumbai.",
      'how_heading' => 'How We Help Malabar Businesses Grow Online',
      'how_body'    => "Our digital marketing approach for Malabar businesses covers the full spectrum from local SEO and Google Business Profile optimization to social media marketing, performance advertising and AI-powered marketing automation.\n\nFor local SEO in Malabar, we optimize your business for the specific search terms your customers use — 'digital marketing agency in Kozhikode', 'best hospital in Malappuram', 'real estate agent in Kannur' and hundreds of similar high-intent local queries. We build your Google Business Profile to rank in the Local Pack for your target areas, generate consistent Google reviews from satisfied customers and build local citations across Indian business directories.\n\nFor social media marketing in Malabar, we create Malayalam and English content that resonates with local audiences — leveraging the high engagement rates of Malabar's active social media communities. For performance advertising, we run precisely targeted Google Ads and Meta Ads campaigns reaching Malabar customers by district, city and even PIN code.\n\nWe also offer specialist NRI-targeting campaigns for businesses that serve the Gulf diaspora — reaching Malabar NRIs in Oman, UAE, Qatar, Bahrain and Kuwait who are making purchasing decisions for their families back home.",
      'process_heading' => 'Our Digital Marketing Process for Malabar Clients',
      'process_steps'   => [
        ['Week 1', 'Free Audit & Discovery', 'We audit your website, Google Business Profile and competitive landscape across your target Malabar districts. You receive a clear report identifying the fastest-win opportunities.'],
        ['Week 2', 'Strategy & Roadmap', 'We build a custom 90-day digital marketing roadmap covering SEO targets, content plan and ad strategy — tailored to your specific Malabar district and industry.'],
        ['Week 3–4', 'Implementation', 'We execute — technical SEO, GBP optimization, Malayalam and English content creation, social media setup and campaign launch. Everything tracked from day one.'],
        ['Month 2–3', 'Growth & Optimization', 'We monitor rankings, leads and campaign performance weekly. You receive monthly reports showing measurable progress across your Malabar target areas.'],
      ],
      'faq' => [
        ['Which districts does Qrenzy serve in Malabar?', 'Qrenzy serves businesses across all six Malabar districts — Kozhikode (Calicut), Malappuram, Kannur, Kasaragod, Wayanad and Palakkad. We provide digital marketing strategies tailored to the specific commercial and cultural characteristics of each district.'],
        ['Can Qrenzy help my Malabar business reach Gulf NRI customers?', 'Yes — NRI targeting is one of our specialties. Malabar has one of the highest Gulf NRI populations in India, and many businesses in real estate, gold, healthcare and education depend significantly on NRI customers. We build campaigns specifically targeting Malabar NRIs in Oman, UAE, Qatar, Bahrain and Kuwait who are making decisions for their families back home.'],
        ['How much does digital marketing cost for a Malabar business?', 'Digital marketing packages for Malabar businesses start from ₹8,000 per month for foundational SEO and Google Business Profile management. Full-service digital marketing including SEO, social media and Google Ads typically ranges from ₹15,000 to ₹40,000 per month depending on scope and competition in your industry.'],
        ['Does Qrenzy create Malayalam content for Malabar businesses?', 'Yes — we create both Malayalam and English content for social media, blogs and advertising. Malayalam-language content consistently outperforms English content for local Malabar audiences, and we factor this into every social media and content strategy we build for Malabar clients.'],
        ['How long does SEO take for a Malabar business?', 'Most Malabar businesses see measurable improvements in Google Maps visibility within 4–8 weeks of starting local SEO. For organic website rankings targeting competitive keywords across Kozhikode, Malappuram or Kannur, significant movement typically happens within 3–6 months of consistent SEO execution.'],
      ],
    ],
  ],

];

// Fallback
if (!isset($locations[$slug])) {
    $loc = $locations['digital-marketing-agency-kerala'];
} else {
    $loc = $locations[$slug];
}

$is_gulf  = in_array($loc['country'], ['Oman','UAE','Bahrain']);
$wa_msg   = urlencode('Hi Sajeesh, I\'m looking for digital marketing services in ' . $loc['city'] . '. Can we connect?');

// Schema
$schema = json_encode([
  '@context'    => 'https://schema.org',
  '@type'       => ['LocalBusiness','ProfessionalService'],
  'name'        => 'Qrenzy Digital Solutions',
  'description' => $loc['headline'] . ' — ' . $loc['subline'],
  'url'         => get_permalink(),
  'telephone'   => '+919905700600',
  'email'       => 'info@qrenzy.com',
  'areaServed'  => ['@type'=>'Place','name'=>$loc['area_served']],
  'address'     => ['@type'=>'PostalAddress','addressLocality'=>'Thrissur','addressRegion'=>'Kerala','addressCountry'=>'IN'],
  'sameAs'      => ['https://www.facebook.com/qrenzydigitalsolutions','https://www.instagram.com/qrenzydigitalsolutions','https://clutch.co/profile/qrenzy-digital-solutions'],
], JSON_UNESCAPED_SLASHES);
?>
<script type="application/ld+json"><?php echo $schema; ?></script>


<style>
/* ── MAP HERO ─────────────────────────────────────────────────── */
.loc-hero {
  min-height: auto;
  display: grid;
  grid-template-columns: 1fr 1fr;
  align-items: center;
  position: relative;
  overflow: hidden;
  background: #fff;
  padding-top: 0;
}
.loc-hero-left {
  padding: 20px 32px 40px 5vw;
  position: relative;
  z-index: 2;
}
.loc-hero-right {
  position: relative;
  height: 100%;
  min-height: 420px;
  max-height: 520px;
  overflow: hidden;
  padding: 20px 28px 20px 0;
  display: flex;
  align-items: center;
}
/* Map container */
#loc-map {
  width: 100%;
  height: 100%;
  min-height: 380px;
  border-radius: 20px;
  overflow: hidden;
  position: relative;
}
/* Theme-match the map tiles */
#loc-map .leaflet-tile {
  filter: brightness(0.9) contrast(1.1) saturate(0.4) hue-rotate(330deg);
}
/* Map overlay gradient — fades left edge into white */

/* Floating animation on the entire map panel */
.loc-hero-right {
  animation: mapFloat 6s ease-in-out infinite;
}
@keyframes mapFloat {
  0%, 100% { transform: translateY(0px); }
  50%       { transform: translateY(-8px); }
}
/* Custom marker */
.loc-marker-pin {
  width: 20px; height: 20px;
  background: #E31E24;
  border: 3px solid #fff;
  border-radius: 50%;
  box-shadow: 0 0 0 4px rgba(227,30,36,0.25);
  animation: markerPulse 2s ease-in-out infinite;
}
@keyframes markerPulse {
  0%, 100% { box-shadow: 0 0 0 4px rgba(227,30,36,0.25); }
  50%       { box-shadow: 0 0 0 12px rgba(227,30,36,0.08); }
}
/* Floating info card on map */
.map-info-card {
  position: absolute;
  bottom: 32px;
  right: 24px;
  background: rgba(10,10,10,0.88);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(227,30,36,0.3);
  border-radius: 16px;
  padding: 16px 20px;
  z-index: 450;
  color: #fff;
  min-width: 180px;
  animation: cardFloat 5s ease-in-out infinite;
}
@keyframes cardFloat {
  0%, 100% { transform: translateY(0px) rotate(-0.5deg); }
  50%       { transform: translateY(-6px) rotate(0.5deg); }
}
.map-card-flag { font-size: 22px; margin-bottom: 6px; display: block; }
.map-card-city { font-size: 16px; font-weight: 800; color: #fff; letter-spacing: -0.02em; }
.map-card-sub  { font-size: 11px; color: rgba(255,255,255,0.5); margin-top: 2px; }
.map-card-dot  { display: inline-block; width: 7px; height: 7px; background: #22c55e; border-radius: 50%; margin-right: 5px; animation: blink 1.5s infinite; }
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.3} }

/* ── HERO CONTENT ─────────────────────────────────────────────── */
.loc-flag   { font-size: 28px; margin-bottom: 12px; display: block; animation: flagBounce 3s ease-in-out infinite; }
@keyframes flagBounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-4px)} }
.loc-tag    { display: inline-flex; align-items: center; gap: 8px; background: #fff0f0; color: #E31E24; font-size: 12px; font-weight: 700; padding: 6px 14px; border-radius: 100px; border: 1px solid #ffd5d5; margin-bottom: 12px; letter-spacing: 0.05em; text-transform: uppercase; }
.loc-h1     { font-size: clamp(28px,3.5vw,50px); font-weight: 900; line-height: 1.1; letter-spacing: -0.03em; color: #0a0a0a; margin-bottom: 16px; }
.loc-h1 em  { color: #E31E24; font-style: normal; }
.loc-hook   { font-size: 15px; color: #E31E24; font-weight: 700; margin-bottom: 14px; padding: 12px 16px; background: #fff5f5; border-left: 3px solid #E31E24; border-radius: 0 8px 8px 0; line-height: 1.5; }
.loc-sub    { font-size: 15px; color: #555; line-height: 1.75; margin-bottom: 28px; max-width: 480px; }
.loc-stats  { display: flex; gap: 24px; margin-bottom: 32px; padding: 20px 24px; background: #f8f8f6; border-radius: 16px; border: 1px solid #e8e8e4; }
.loc-stat   { text-align: center; flex: 1; }
.loc-stat-n { font-size: 22px; font-weight: 900; color: #E31E24; letter-spacing: -0.02em; }
.loc-stat-l { font-size: 11px; color: #888; font-weight: 600; margin-top: 2px; line-height: 1.3; }
.loc-btns   { display: flex; gap: 12px; flex-wrap: wrap; }
.loc-btn-primary { background: #E31E24; color: #fff; padding: 14px 28px; border-radius: 100px; font-size: 14px; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: background 0.2s, transform 0.2s; }
.loc-btn-primary:hover { background: #c01018; transform: translateY(-1px); }
.loc-btn-wa { background: #25D366; color: #fff; padding: 14px 24px; border-radius: 100px; font-size: 14px; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: background 0.2s; }
.loc-btn-wa:hover { background: #1dab52; }

/* ── SECTIONS ──────────────────────────────────────────────── */
.loc-market { padding: 72px 0; background: #f8f8f6; }
.loc-services-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 20px; margin-top: 32px; }
.loc-svc-card { background: #fff; border-radius: 20px; padding: 24px; border: 1px solid #e8e8e4; transition: box-shadow 0.2s, transform 0.2s; }
.loc-svc-card:hover { box-shadow: 0 12px 40px rgba(227,30,36,0.1); transform: translateY(-3px); }
.loc-industries { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 20px; }
.loc-ind-tag { background: #fff; border: 1px solid #e8e8e4; padding: 7px 14px; border-radius: 100px; font-size: 13px; color: #555; font-weight: 500; }
.loc-testimonial { padding: 64px 0; background: #0a0a0a; }
.loc-quote { font-size: clamp(18px,2.5vw,26px); font-weight: 700; color: #fff; line-height: 1.5; margin-bottom: 20px; max-width: 640px; }
.loc-quote::before { content: '"'; color: #E31E24; font-size: 48px; line-height: 0.5; display: block; margin-bottom: 12px; }

/* ── RESPONSIVE ─────────────────────────────────────────────── */
@media(max-width:900px){
  .loc-hero { grid-template-columns:1fr; min-height:auto; }
  .loc-hero-right { height: 55vw; min-height:260px; }
  .loc-hero-left { padding: 48px 20px 32px; }
  .loc-services-grid { grid-template-columns:1fr 1fr; }
}
@media(max-width:600px){
  .loc-services-grid { grid-template-columns:1fr; }
  .loc-stats { gap:14px; }
  .loc-stat-n { font-size:18px; }
}
</style>

<!-- BREADCRUMB -->
<div class="breadcrumb"><div class="wrap"><div class="breadcrumb-inner"><ol class="bc-list">
  <li><a href="<?php echo home_url(); ?>">Home</a></li>
  <li class="bc-sep">/</li>
  <li>Digital Marketing Agency in <?php echo $loc['city']; ?></li>
</ol></div></div></div>

<!-- ── HERO SECTION ──────────────────────────────────────────────────── -->
<section class="loc-hero">

  <!-- LEFT: Content -->
  <div class="loc-hero-left">
    <div class="loc-tag">✦ <?php echo $loc['area_served']; ?></div>
    <?php
    // Hidden SEO image for keyword alt text signal
    $og_img = get_template_directory_uri().'/images/og-default.jpg';
    if(has_post_thumbnail()) $og_img = get_the_post_thumbnail_url(null,'qrenzy-featured');
    ?>
    <img src="<?php echo esc_url($og_img); ?>"
         alt="<?php echo esc_attr('Digital Marketing Agency in '.$loc['city'].' — Qrenzy Digital Solutions'); ?>"
         style="display:none" width="1" height="1" loading="lazy">
    <h1 class="loc-h1"><?php
      // Bold the city name in red
      echo str_replace($loc['city'], '<em>'.$loc['city'].'</em>', esc_html($loc['headline']));
    ?></h1>
    <div class="loc-hook"><?php echo esc_html($loc['hook']); ?></div>
    <p class="loc-sub"><?php echo esc_html($loc['subline']); ?></p>
    <div class="loc-stats">
      <?php foreach([$loc['stat1'],$loc['stat2'],$loc['stat3']] as $s): ?>
      <div class="loc-stat">
        <div class="loc-stat-n"><?php echo $s[0]; ?></div>
        <div class="loc-stat-l"><?php echo $s[1]; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="loc-btns">
      <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="loc-btn-primary">🔍 Get Free SEO Audit →</a>
      <a href="https://api.whatsapp.com/send?phone=919905700600&text=<?php echo $wa_msg; ?>" class="loc-btn-wa" rel="noopener" target="_blank">💬 WhatsApp Us</a>
    </div>
  </div>

  <!-- RIGHT: Map -->
  <div class="loc-hero-right">
    <div id="loc-map">
      <!-- Skeleton shown while map loads -->
      <div id="loc-map-skeleton" style="position:absolute;inset:0;background:linear-gradient(135deg,#f0f0ed 0%,#e8e8e4 50%,#f0f0ed 100%);border-radius:20px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:8px">
        <div style="width:32px;height:32px;border:3px solid #E31E24;border-top-color:transparent;border-radius:50%;animation:spin 0.8s linear infinite"></div>
        <span style="font-size:11px;color:#999;font-weight:600">Loading map...</span>
      </div>
      <style>@keyframes spin{to{transform:rotate(360deg)}}</style>
    </div>
    <!-- Floating info card -->
    <div class="map-info-card">
      <span class="map-card-flag"><?php echo $loc['flag']; ?></span>
      <div class="map-card-city"><?php echo $loc['city']; ?><?php if($loc['state'] && $loc['state'] !== $loc['city']): ?>, <?php echo $loc['state']; endif; ?></div>
      <div class="map-card-sub"><span class="map-card-dot"></span>Qrenzy Active Here</div>
    </div>
  </div>

</section>

<!-- ── MARKET SECTION ────────────────────────────────────────────────── -->
<section class="loc-market">
  <div class="wrap">
    <div class="section-tag">📍 Local Expertise</div>
    <h2 style="font-size:clamp(24px,3.5vw,40px);font-weight:900;color:#0a0a0a;margin:12px 0 16px;letter-spacing:-0.02em">
      <?php echo $loc['city']; ?>'s Trusted Digital Marketing Agency — We Know Your Market
    </h2>
    <p style="font-size:15px;color:#555;line-height:1.8;max-width:680px;margin-bottom:28px"><?php echo esc_html($loc['market_desc']); ?></p>

    <h4 style="font-size:13px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:12px">Industries We Serve in <?php echo $loc['city']; ?></h4>
    <div class="loc-industries">
      <?php foreach($loc['industries'] as $ind): ?>
      <span class="loc-ind-tag">✓ <?php echo $ind; ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── SERVICES SECTION ──────────────────────────────────────────────── -->
<section style="padding:72px 0;background:#fff">
  <div class="wrap">
    <div class="section-tag">What We Do</div>
    <h2 style="font-size:clamp(24px,3.5vw,40px);font-weight:900;color:#0a0a0a;margin:12px 0 8px;letter-spacing:-0.02em">
      Full-Service Digital Marketing<br>for <?php echo $loc['city']; ?> Businesses
    </h2>
    <p style="font-size:15px;color:#666;margin-bottom:0">Every service. One agency. Zero guesswork.</p>
    <?php
    $services = [
      ['🔍','Search Engine Optimization','Rank on Page 1 for '.$loc['city'].' searches. Technical SEO, content & link building.','/search-engine-optimization/','#E31E24'],
      ['🌐','Web Design & Development','Fast, SEO-ready WordPress websites that convert visitors into leads.','/web-designing/','#1565C0'],
      ['📱','Social Media Marketing','Instagram, Facebook & LinkedIn campaigns built for the '.$loc['city'].' audience.','/social-media-marketing/','#7C3AED'],
      ['🎯','Performance Marketing','Google & Meta Ads with precise targeting for '.$loc['city'].' demographics.','/pay-per-click/','#D97706'],
      ['🤖','AI Marketing Automation','WhatsApp bots, email flows & CRM automation for '.$loc['city'].' businesses.','/ai-marketing-automation/','#0891B2'],
      ['🎨','Graphic Design','Brand identity, social creatives & print design for '.$loc['city'].' brands.','/graphic-designing/','#059669'],
    ];
    ?>
    <div class="loc-services-grid">
      <?php foreach($services as $sv): ?>
      <a href="<?php echo home_url($sv[4]); ?>" class="loc-svc-card" style="text-decoration:none">
        <div style="font-size:28px;margin-bottom:12px"><?php echo $sv[0]; ?></div>
        <h3 style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:8px"><?php echo $sv[1]; ?></h3>
        <p style="font-size:13px;color:#666;line-height:1.6;margin:0"><?php echo $sv[2]; ?></p>
        <div style="margin-top:14px;font-size:12px;font-weight:700;color:<?php echo $sv[3]; ?>">Learn more →</div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── TESTIMONIAL ───────────────────────────────────────────────────── -->
<section class="loc-testimonial">
  <div class="wrap">
    <div style="max-width:700px;margin:0 auto;text-align:center">
      <div class="loc-quote"><?php echo esc_html($loc['testimonial'][0]); ?></div>
      <div style="font-size:14px;font-weight:700;color:#fff"><?php echo esc_html($loc['testimonial'][1]); ?></div>
      <div style="font-size:12px;color:rgba(255,255,255,0.45);margin-top:4px"><?php echo esc_html($loc['testimonial'][2]); ?></div>
    </div>
  </div>
</section>

<!-- ── WHY LOCAL AGENCY ──────────────────────────────────────────────── -->
<?php if(!empty($loc['long_content'])): $lc = $loc['long_content']; ?>

<!-- ── WHY LOCAL AGENCY — 2 col layout ──────────────────────────────── -->
<section style="padding:72px 0;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 400px;gap:56px;align-items:start">

      <!-- LEFT: body text -->
      <div>
        <div class="section-tag">💡 Local Expertise</div>
        <h2 style="font-size:clamp(22px,3vw,34px);font-weight:900;color:#0a0a0a;margin:12px 0 24px;letter-spacing:-0.02em;line-height:1.15"><?php echo esc_html($lc['why_heading']); ?></h2>
        <?php foreach(explode("\n\n", $lc['why_body']) as $para): if(trim($para)): ?>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:18px"><?php echo esc_html(trim($para)); ?></p>
        <?php endif; endforeach; ?>
      </div>

      <!-- RIGHT: sticky info card -->
      <div style="position:sticky;top:100px">
        <div style="background:#f8f8f6;border:1px solid #e8e8e4;border-radius:20px;padding:32px">
          <div style="font-size:13px;font-weight:700;color:#E31E24;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:20px">Why Qrenzy in <?php echo esc_html($loc['city']); ?></div>
          <?php
          $why_points = [
            ['🏠', 'Local Market Knowledge', 'We understand '.$loc['city'].'\'s audience, competitors and seasonal buying patterns.'],
            ['📍', 'Location-Specific SEO', 'Every strategy is built around the keywords '.$loc['city'].' customers actually search.'],
            ['📊', 'Measurable Results', 'Monthly reports showing exactly what your investment delivers — no vague metrics.'],
            ['🤝', 'Dedicated Account Manager', 'One point of contact. Always available via WhatsApp, call or email.'],
            ['✅', 'No Lock-in Contracts', 'Month-to-month flexibility. We earn your business every month.'],
          ];
          foreach($why_points as $wp): ?>
          <div style="display:flex;gap:12px;margin-bottom:16px;align-items:flex-start">
            <span style="font-size:18px;flex-shrink:0;margin-top:2px"><?php echo $wp[0]; ?></span>
            <div>
              <div style="font-size:13px;font-weight:700;color:#0a0a0a;margin-bottom:2px"><?php echo $wp[1]; ?></div>
              <div style="font-size:12px;color:#777;line-height:1.5"><?php echo esc_html($wp[2]); ?></div>
            </div>
          </div>
          <?php endforeach; ?>
          <a href="<?php echo home_url('/free-seo-audit/'); ?>" style="display:block;background:#E31E24;color:#fff;text-align:center;padding:14px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none;margin-top:20px">Get Free SEO Audit →</a>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ── HOW WE HELP — 2 col layout ───────────────────────────────────── -->
<section style="padding:72px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:400px 1fr;gap:56px;align-items:start">

      <!-- LEFT: stats card -->
      <div style="position:sticky;top:100px">
        <div style="background:#0a0a0a;border-radius:20px;padding:32px;color:#fff">
          <div style="font-size:13px;font-weight:700;color:#E31E24;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:24px"><?php echo esc_html($loc['city']); ?> Results</div>
          <?php
          $results = [
            [$loc['stat1'][0], $loc['stat1'][1]],
            [$loc['stat2'][0], $loc['stat2'][1]],
            [$loc['stat3'][0], $loc['stat3'][1]],
            ['90 Days', 'Avg. to First Results'],
            ['4.9★', 'Client Satisfaction'],
          ];
          foreach($results as $r): ?>
          <div style="border-bottom:1px solid rgba(255,255,255,0.08);padding:14px 0;display:flex;justify-content:space-between;align-items:center">
            <span style="font-size:13px;color:rgba(255,255,255,0.55)"><?php echo esc_html($r[1]); ?></span>
            <span style="font-size:18px;font-weight:900;color:#fff;letter-spacing:-0.02em"><?php echo esc_html($r[0]); ?></span>
          </div>
          <?php endforeach; ?>
          <div style="margin-top:24px;padding:16px;background:rgba(227,30,36,0.12);border:1px solid rgba(227,30,36,0.25);border-radius:12px">
            <div style="font-size:12px;color:rgba(255,255,255,0.6);margin-bottom:4px">Serving <?php echo esc_html($loc['city']); ?> since</div>
            <div style="font-size:22px;font-weight:900;color:#E31E24">2020</div>
          </div>
        </div>
      </div>

      <!-- RIGHT: body text -->
      <div>
        <div class="section-tag">📈 Our Approach</div>
        <h2 style="font-size:clamp(22px,3vw,34px);font-weight:900;color:#0a0a0a;margin:12px 0 24px;letter-spacing:-0.02em;line-height:1.15"><?php echo esc_html($lc['how_heading']); ?></h2>
        <?php foreach(explode("\n\n", $lc['how_body']) as $para): if(trim($para)): ?>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:18px"><?php echo esc_html(trim($para)); ?></p>
        <?php endif; endforeach; ?>
      </div>

    </div>
  </div>
</section>

<!-- ── OUR PROCESS ────────────────────────────────────────────────────── -->
<section style="padding:72px 0;background:#0a0a0a">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 12px;background:rgba(227,30,36,0.15);border-color:rgba(227,30,36,0.3);color:#E31E24">⚙️ How We Work</div>
      <h2 style="font-size:clamp(22px,3vw,36px);font-weight:900;color:#fff;margin:0;letter-spacing:-0.02em"><?php echo esc_html($lc['process_heading']); ?></h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:20px">
      <?php foreach($lc['process_steps'] as $i => $step): ?>
      <div style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:16px;padding:28px;position:relative">
        <div style="font-size:28px;font-weight:900;color:rgba(227,30,36,0.2);position:absolute;top:16px;right:20px;line-height:1"><?php echo $i+1; ?></div>
        <div style="font-size:11px;font-weight:800;color:#E31E24;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:10px"><?php echo esc_html($step[0]); ?></div>
        <h3 style="font-size:15px;font-weight:800;color:#fff;margin-bottom:10px"><?php echo esc_html($step[1]); ?></h3>
        <p style="font-size:13px;color:rgba(255,255,255,0.55);line-height:1.7;margin:0"><?php echo esc_html($step[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── FAQ — 2 col layout ────────────────────────────────────────────── -->
<section style="padding:72px 0;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:300px 1fr;gap:56px;align-items:start">

      <!-- LEFT: heading + CTA -->
      <div style="position:sticky;top:100px">
        <div class="section-tag">❓ FAQs</div>
        <h2 style="font-size:clamp(22px,2.5vw,32px);font-weight:900;color:#0a0a0a;margin:12px 0 16px;letter-spacing:-0.02em;line-height:1.2">
          Common Questions About Digital Marketing in <?php echo esc_html($loc['city']); ?>
        </h2>
        <p style="font-size:14px;color:#777;line-height:1.7;margin-bottom:24px">Everything you need to know before starting your <?php echo esc_html($loc['city']); ?> digital marketing journey.</p>
        <a href="<?php echo home_url('/contact/'); ?>" style="display:inline-flex;align-items:center;gap:8px;background:#0a0a0a;color:#fff;padding:12px 22px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none">Ask a Question →</a>
      </div>

      <!-- RIGHT: accordion -->
      <div>
        <?php foreach($lc['faq'] as $fi => $faq): ?>
        <details style="border:1px solid #e8e8e4;border-radius:12px;margin-bottom:10px;overflow:hidden" <?php if($fi===0) echo 'open'; ?>>
          <summary style="padding:18px 20px;font-size:15px;font-weight:700;color:#0a0a0a;cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center;gap:12px">
            <?php echo esc_html($faq[0]); ?>
            <span style="font-size:20px;color:#E31E24;flex-shrink:0;line-height:1">+</span>
          </summary>
          <div style="padding:0 20px 18px;font-size:14px;color:#555;line-height:1.8;border-top:1px solid #f0f0ed"><?php echo esc_html($faq[1]); ?></div>
        </details>
        <?php endforeach; ?>
      </div>

    </div>
  </div>
</section>

<!-- ── MOBILE RESPONSIVE OVERRIDES ──────────────────────────────────── -->
<style>
@media(max-width:860px){
  .loc-content-2col { grid-template-columns: 1fr !important; }
  .loc-sticky-card  { position:static !important; }
}
</style>
<script>
// Apply responsive class to 2-col grids
document.querySelectorAll('.wrap > div[style*="grid-template-columns:1fr 400px"], .wrap > div[style*="grid-template-columns:400px 1fr"], .wrap > div[style*="grid-template-columns:300px 1fr"]').forEach(function(el){
  el.classList.add('loc-content-2col');
  el.querySelectorAll('[style*="position:sticky"]').forEach(function(s){ s.classList.add('loc-sticky-card'); });
});
</script>

<?php endif; ?>

<!-- ── CTA ───────────────────────────────────────────────────────────── -->
<section class="cta-band">
  <div class="wrap"><div class="cta-inner">
    <h2>Ready to Grow Your<br><?php echo $loc['city']; ?> Business?</h2>
    <p>Free SEO audit included. No commitment. Results-focused from day one.</p>
    <div class="cta-btns">
      <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-white">🔍 Free SEO Audit</a>
      <a href="https://api.whatsapp.com/send?phone=919905700600&text=<?php echo $wa_msg; ?>" class="btn-outline-white" rel="noopener" target="_blank">💬 WhatsApp Now</a>
    </div>
  </div></div>
</section>

<!-- Lightweight Map — Leaflet loaded only after page is interactive -->
<script>
(function(){
  // Defer Leaflet until browser is idle — zero impact on page load
  function loadMap() {
    if (document.getElementById('loc-map').dataset.loaded) return;
    document.getElementById('loc-map').dataset.loaded = '1';

    var css = document.createElement('link');
    css.rel = 'stylesheet';
    css.href = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';
    document.head.appendChild(css);

    var script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';
    script.onload = function() {
      var map = L.map('loc-map', {
        center: [<?php echo $loc['lat']; ?>, <?php echo $loc['lng']; ?>],
        zoom: <?php echo $loc['zoom']; ?>,
        zoomControl: false,
        scrollWheelZoom: false,
        attributionControl: false,
        dragging: false,
      });

      // Hide skeleton when first tile loads
      map.once('load', function(){ var sk = document.getElementById('loc-map-skeleton'); if(sk) sk.style.display='none'; });
      L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        subdomains: 'abcd',
      }).addTo(map);

      var pulseIcon = L.divIcon({
        className: '',
        html: '<div class="loc-marker-pin"></div>',
        iconSize: [20, 20],
        iconAnchor: [10, 10],
      });
      L.marker([<?php echo $loc['lat']; ?>, <?php echo $loc['lng']; ?>], { icon: pulseIcon }).addTo(map);

      // Gentle pan animation
      var angle = 0;
      setInterval(function(){
        angle += 0.003;
        map.panTo([
          <?php echo $loc['lat']; ?> + Math.sin(angle) * 0.002,
          <?php echo $loc['lng']; ?> + Math.cos(angle) * 0.002
        ], { animate: true, duration: 2, easeLinearity: 0.1 });
      }, 3000);
    };
    document.body.appendChild(script);
  }

  // Load after window load + 300ms — hero content renders first, map loads after
  if (document.readyState === 'complete') {
    setTimeout(loadMap, 300);
  } else {
    window.addEventListener('load', function(){ setTimeout(loadMap, 300); });
  }

  // Also load if user scrolls to map area (IntersectionObserver)
  if ('IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function(entries){
      if (entries[0].isIntersecting) { loadMap(); obs.disconnect(); }
    }, { rootMargin: '200px' });
    obs.observe(document.getElementById('loc-map'));
  }
})();
</script>

<!-- OTHER LOCATIONS -->
<section style="padding:48px 0;background:#f8f8f6;border-top:1px solid #e8e8e4">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:24px">
      <div class="section-tag" style="display:table;margin:0 auto 10px">✦ Other Locations</div>
      <h2 style="font-size:22px;font-weight:800;color:#0a0a0a;letter-spacing:-0.02em">We Also Serve These Markets</h2>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:10px;justify-content:center;max-width:800px;margin:0 auto">
      <?php
      $all_locs = [
        ['Thrissur','digital-marketing-agency-thrissur','🇮🇳'],
        ['Kerala','digital-marketing-agency-kerala','🇮🇳'],
        ['Kochi','digital-marketing-agency-kochi','🇮🇳'],
        ['Calicut','digital-marketing-agency-calicut','🇮🇳'],
        ['Trivandrum','digital-marketing-agency-trivandrum','🇮🇳'],
        ['Oman','digital-marketing-agency-oman','🇴🇲'],
        ['UAE','digital-marketing-agency-uae','🇦🇪'],
        ['Dubai','digital-marketing-agency-dubai','🇦🇪'],
        ['Qatar','digital-marketing-agency-qatar','🇶🇦'],
        ['Bahrain','digital-marketing-agency-bahrain','🇧🇭'],
      ];
      foreach($all_locs as $al):
        if($al[1] === $slug) continue; // skip current page
      ?>
      <a href="<?php echo home_url('/'.$al[1].'/'); ?>" style="display:inline-flex;align-items:center;gap:8px;background:#fff;border:1px solid #e8e8e4;border-radius:100px;padding:10px 18px;text-decoration:none;color:#0a0a0a;font-size:13px;font-weight:600;transition:all 0.2s" onmouseover="this.style.borderColor='#E31E24';this.style.color='#E31E24'" onmouseout="this.style.borderColor='#e8e8e4';this.style.color='#0a0a0a'">
        <span><?php echo $al[2]; ?></span>
        Digital Marketing Agency in <?php echo $al[0]; ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php get_footer(); ?>

<?php get_header(); ?>
<main id="main-content" role="main">

<div class="breadcrumb"><div class="wrap"><div class="breadcrumb-inner"><?php qrenzy_breadcrumbs(); ?></div></div></div>

<section style="padding:48px 0 24px;background:#fafaf8;border-bottom:1px solid #f0f0ec">
  <div class="wrap">
    <div style="font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#E31E24;margin-bottom:8px">
      <?php if(is_category()) echo 'Category'; elseif(is_tag()) echo 'Tag'; else echo 'Archive'; ?>
    </div>
    <h1 style="font-size:clamp(28px,4vw,42px);font-weight:900;color:#0a0a0a;letter-spacing:-0.025em">
      <?php the_archive_title(); ?>
    </h1>
    <?php if(category_description()): ?>
    <p style="color:#555;font-size:16px;margin-top:10px;max-width:600px"><?php echo category_description(); ?></p>
    <?php endif; ?>
  </div>
</section>

<section style="padding:56px 0 80px">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:28px">
      <?php if(have_posts()): while(have_posts()): the_post();
        $cat = get_the_category(); $cat_name = $cat ? $cat[0]->name : 'Blog';
        $cat_color = qrenzy_cat_color($cat ? $cat[0]->slug : '');
      ?>
      <article style="background:#fff;border-radius:16px;border:1px solid #f0f0ec;overflow:hidden;transition:box-shadow 0.2s" onmouseover="this.style.boxShadow='0 8px 32px rgba(0,0,0,0.08)'" onmouseout="this.style.boxShadow='none'">
        <?php if(has_post_thumbnail()): ?>
        <a href="<?php the_permalink(); ?>" style="display:block;height:200px;overflow:hidden">
          <?php the_post_thumbnail('qrenzy-thumb', ['style'=>'width:100%;height:100%;object-fit:cover']); ?>
        </a>
        <?php endif; ?>
        <div style="padding:20px">
          <a href="<?php echo get_category_link($cat[0]->term_id); ?>" style="display:inline-block;font-size:10px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:<?php echo $cat_color; ?>;margin-bottom:8px"><?php echo esc_html($cat_name); ?></a>
          <h2 style="font-size:17px;font-weight:800;color:#0a0a0a;line-height:1.35;margin-bottom:10px"><a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none"><?php the_title(); ?></a></h2>
          <p style="color:#666;font-size:13px;line-height:1.6;margin-bottom:14px"><?php echo wp_trim_words(get_the_excerpt(), 18); ?></p>
          <div style="display:flex;align-items:center;justify-content:space-between;font-size:12px;color:#999">
            <span><?php echo get_the_date('M d, Y'); ?></span>
            <span><?php echo qrenzy_reading_time(); ?></span>
          </div>
        </div>
      </article>
      <?php endwhile; ?>
    </div>

    <?php if($GLOBALS['wp_query']->max_num_pages > 1): ?>
    <div style="display:flex;justify-content:center;gap:8px;margin-top:48px">
      <?php echo paginate_links(['prev_text'=>'← Prev','next_text'=>'Next →','before_page_number'=>'<span>','after_page_number'=>'</span>']); ?>
    </div>
    <?php endif; ?>

    <?php else: ?>
    <p style="text-align:center;color:#666;padding:80px 0">No posts found.</p>
    <?php endif; ?>
  </div>
</section>
</main>
<?php get_footer(); ?>

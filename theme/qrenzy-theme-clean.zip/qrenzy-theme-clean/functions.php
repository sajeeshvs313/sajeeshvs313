<?php
// ── SEO AUDIT ENGINE ─────────────────────────────────────────────────
require_once get_template_directory() . '/seo-audit-engine.php';

/**
 * Qrenzy Digital Solutions Theme Functions
 */

// ── THEME SETUP ───────────────────────────────────────────────────────
function qrenzy_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption']);
    add_theme_support('custom-logo', [
        'height' => 36, 'width' => 140, 'flex-height' => true, 'flex-width' => true,
    ]);
    add_image_size('qrenzy-featured', 1200, 628, true);
    add_image_size('qrenzy-thumb', 600, 400, true);
    add_image_size('qrenzy-related', 400, 280, true);
    register_nav_menus([
        'primary' => 'Primary Navigation',
        'footer-services' => 'Footer Services',
        'footer-company' => 'Footer Company',
    ]);
}
add_action('after_setup_theme', 'qrenzy_setup');


// ── DISABLE RANKMATH ARTICLE SCHEMA ON SERVICE PAGES ─────────────────
// Method 1: json_ld filter (works on some RM versions)
add_filter('rank_math/json_ld', 'qrenzy_disable_rm_schema', 999, 2);
function qrenzy_disable_rm_schema($data, $jsonld = null) {
    if (!is_singular('page')) return $data;
    $slug = get_post_field('post_name', get_the_ID());
    $service_slugs = [
        'search-engine-optimization','local-seo','web-designing','social-media-marketing',
        'pay-per-click','ai-marketing-automation','photography-videography',
        'graphic-designing','custom-software'
    ];
    if (!in_array($slug, $service_slugs)) return $data;
    foreach ($data as $key => $item) {
        $type = is_array($item) ? ($item['@type'] ?? '') : '';
        if (in_array($type, ['Article','WebPage','BlogPosting','ItemPage'])) {
            unset($data[$key]);
        }
    }
    return $data;
}

// Method 2: Remove RM schema output entirely on service pages, let our JSON-LD run
add_action('wp', 'qrenzy_maybe_disable_rm_rich_snippet');
function qrenzy_maybe_disable_rm_rich_snippet() {
    if (!is_singular('page')) return;
    $slug = get_post_field('post_name', get_the_ID());
    $service_slugs = [
        'search-engine-optimization','local-seo','web-designing','social-media-marketing',
        'pay-per-click','ai-marketing-automation','photography-videography',
        'graphic-designing','custom-software'
    ];
    if (!in_array($slug, $service_slugs)) return;
    // Remove all RankMath schema hooks on service pages
    add_filter('rank_math/snippet/rich_snippet_Article_entity', '__return_empty_array', 999);
    add_filter('rank_math/snippet/rich_snippet_WebPage_entity', '__return_empty_array', 999);
    // Disable RM schema output completely - our JSON-LD in page-service.php handles it
    remove_action('rank_math/head', ['RankMath\Paper\Paper', 'output_schema']);
}
// ── END RANKMATH SCHEMA OVERRIDE ───────────────────────────────────────


// ── LOGO SIZE INLINE CSS — bypasses cache ────────────────────────────
add_action('wp_head', 'qrenzy_logo_inline_css', 999);
function qrenzy_logo_inline_css() {
    echo '<style>
/* ── LOGO ── */
#site-nav .custom-logo-link img,
#site-nav .custom-logo,
#site-nav .nav-logo img,
.nav-logo img,
a.custom-logo-link img { 
    height: 44px !important; 
    width: auto !important; 
    max-width: 160px !important;
    max-height: 44px !important;
    object-fit: contain !important;
    display: block !important;
}
a.custom-logo-link { line-height: 0 !important; display: flex !important; align-items: center !important; }
footer .custom-logo-link img,
footer .custom-logo,
.footer-about img {
    height: 32px !important;
    width: auto !important;
    max-width: 140px !important;
    max-height: 32px !important;
    object-fit: contain !important;
    filter: brightness(0) invert(1) !important;
}
/* ── NAV ── */
#site-nav .nav-links { gap: 16px !important; }
#site-nav .nav-links a { font-size: 13px !important; white-space: nowrap !important; }
/* ── BREADCRUMB SPACING ── */
.breadcrumb { padding-top: 60px !important; margin: 0 !important; }
.breadcrumb-inner { padding: 6px 0 !important; }
/* ── HERO SECTIONS — all pages except homepage ── */
body:not(.home) section:first-of-type { padding-top: 12px !important; }
/* ── LOCATION PAGE MAP FIX ── */
.loc-hero { min-height: auto !important; padding-top: 0 !important; }
.loc-hero-right { height: 520px !important; max-height: 520px !important; }
.loc-hero-left { padding-top: 16px !important; padding-bottom: 40px !important; }
#loc-map { height: 100% !important; }
</style>';
}
// ── END LOGO INLINE CSS ───────────────────────────────────────────────

// ── PORTFOLIO CUSTOM POST TYPE ────────────────────────────────────────
function qrenzy_register_portfolio() {
    register_post_type('portfolio', [
        'labels' => [
            'name'               => 'Portfolio',
            'singular_name'      => 'Portfolio Item',
            'add_new'            => 'Add New Project',
            'add_new_item'       => 'Add New Portfolio Project',
            'edit_item'          => 'Edit Project',
            'view_item'          => 'View Project',
            'all_items'          => 'All Projects',
            'search_items'       => 'Search Projects',
        ],
        'public'            => true,
        'has_archive'       => false,
        'show_in_menu'      => true,
        'menu_icon'         => 'dashicons-portfolio',
        'menu_position'     => 5,
        'supports'          => ['title','editor','thumbnail','excerpt','custom-fields'],
        'rewrite'           => ['slug' => 'portfolio'],
        'show_in_rest'      => true,
    ]);

    // Portfolio Categories
    register_taxonomy('portfolio_cat', 'portfolio', [
        'labels'       => ['name' => 'Categories', 'singular_name' => 'Category', 'add_new_item' => 'Add Category'],
        'hierarchical' => true,
        'public'       => true,
        'rewrite'      => ['slug' => 'portfolio-category'],
        'show_in_rest' => true,
    ]);
}
add_action('init', 'qrenzy_register_portfolio');

// Portfolio Meta Box (Client, Result, Live URL, Service Type)
function qrenzy_portfolio_meta_box() {
    add_meta_box('qrenzy_portfolio_details', '📋 Project Details', 'qrenzy_portfolio_meta_html', 'portfolio', 'normal', 'high');
}
add_action('add_meta_boxes', 'qrenzy_portfolio_meta_box');

function qrenzy_portfolio_meta_html($post) {
    wp_nonce_field('qrenzy_portfolio_nonce', 'qrenzy_portfolio_nonce');
    $client    = get_post_meta($post->ID, '_portfolio_client',    true);
    $service   = get_post_meta($post->ID, '_portfolio_service',   true);
    $result    = get_post_meta($post->ID, '_portfolio_result',    true);
    $live_url  = get_post_meta($post->ID, '_portfolio_live_url',  true);
    $duration  = get_post_meta($post->ID, '_portfolio_duration',  true);
    $country   = get_post_meta($post->ID, '_portfolio_country',   true);
    $services  = ['Search Engine Optimization','Web Design & Development','Social Media Marketing','Performance Marketing','AI Marketing Automation','Photography & Videography','Graphic Design','Software Solutions'];
    $countries = ['India','Oman','UAE','Bahrain','Worldwide'];
    echo '<style>.qmb{display:grid;grid-template-columns:1fr 1fr;gap:14px;padding:8px 0}.qmb label{font-weight:600;font-size:12px;display:block;margin-bottom:4px;color:#555}.qmb input,.qmb select{width:100%;padding:7px 10px;border:1px solid #ddd;border-radius:6px;font-size:13px}.qmb-full{grid-column:1/-1}</style>';
    echo '<div class="qmb">';
    echo '<div><label>Client / Company Name</label><input type="text" name="portfolio_client" value="'.esc_attr($client).'" placeholder="e.g. Al Fanar Group"></div>';
    echo '<div><label>Country / Market</label><select name="portfolio_country"><option value="">Select Country</option>';
    foreach($countries as $cn) echo '<option value="'.$cn.'"'.($country===$cn?' selected':'').'>'.$cn.'</option>';
    echo '</select></div>';
    echo '<div><label>Service Type</label><select name="portfolio_service"><option value="">Select Service</option>';
    foreach($services as $sv) echo '<option value="'.$sv.'"'.($service===$sv?' selected':'').'>'.$sv.'</option>';
    echo '</select></div>';
    echo '<div><label>Project Duration</label><input type="text" name="portfolio_duration" value="'.esc_attr($duration).'" placeholder="e.g. 3 months"></div>';
    echo '<div class="qmb-full"><label>Key Result / Achievement</label><input type="text" name="portfolio_result" value="'.esc_attr($result).'" placeholder="e.g. 340% increase in organic traffic in 4 months"></div>';
    echo '<div class="qmb-full"><label>Live URL (optional)</label><input type="url" name="portfolio_live_url" value="'.esc_attr($live_url).'" placeholder="https://example.com"></div>';
    echo '</div>';
}

function qrenzy_portfolio_save_meta($post_id) {
    if (!isset($_POST['qrenzy_portfolio_nonce']) || !wp_verify_nonce($_POST['qrenzy_portfolio_nonce'], 'qrenzy_portfolio_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    $fields = ['portfolio_client','portfolio_service','portfolio_result','portfolio_live_url','portfolio_duration','portfolio_country'];
    foreach ($fields as $field) {
        if (isset($_POST[$field])) update_post_meta($post_id, '_'.$field, sanitize_text_field($_POST[$field]));
    }
}
add_action('save_post', 'qrenzy_portfolio_save_meta');
// ── END PORTFOLIO CPT ─────────────────────────────────────────────────


// ── ENQUEUE STYLES & SCRIPTS ──────────────────────────────────────────
function qrenzy_enqueue() {
    wp_enqueue_style('qrenzy-style', get_stylesheet_uri(), [], '2.0.0');
    wp_enqueue_script('qrenzy-main', get_template_directory_uri() . '/js/main.js', [], '2.0.0', true);
    add_filter('script_loader_tag', function($tag, $handle) { if (in_array($handle, ['qrenzy-main','qrenzy-post'])) return str_replace(' src', ' defer src', $tag); return $tag; }, 10, 2);
    if (is_singular()) {
        wp_enqueue_script('qrenzy-post', get_template_directory_uri() . '/js/post.js', [], '2.0.0', true);
    }
}
add_action('wp_enqueue_scripts', 'qrenzy_enqueue');

// ── EXCERPT LENGTH ────────────────────────────────────────────────────
function qrenzy_excerpt_length($length) { return 28; }
add_filter('excerpt_length', 'qrenzy_excerpt_length');
function qrenzy_excerpt_more($more) { return '...'; }
add_filter('excerpt_more', 'qrenzy_excerpt_more');
// ── IMAGE LAZY LOADING ────────────────────────────────────────────────
add_filter('wp_lazy_loading_enabled', '__return_true');

// ── PRECONNECT / DNS PREFETCH ─────────────────────────────────────────
add_action('wp_head', function() {
    echo '<link rel="preconnect" href="https://www.google-analytics.com">' . "\n";
    echo '<link rel="preconnect" href="https://www.googletagmanager.com">' . "\n";
    echo '<link rel="dns-prefetch" href="https://www.googleapis.com">' . "\n";
    echo '<link rel="dns-prefetch" href="https://fonts.gstatic.com">' . "\n";
}, 1);


// ── FEATURED IMAGE ALT TEXT FALLBACK ─────────────────────────────────
add_filter('post_thumbnail_html', function($html, $post_id) {
    if (strpos($html, 'alt=""') !== false || strpos($html, "alt=''") !== false) {
        $title = get_the_title($post_id);
        $html = str_replace('alt=""', 'alt="' . esc_attr($title) . '"', $html);
        $html = str_replace("alt=''", "alt='" . esc_attr($title) . "'", $html);
    }
    return $html;
}, 10, 2);


// ── WHATSAPP FLOATING BUTTON ──────────────────────────────────────────
add_action('wp_footer', function() {
    echo '<a href="https://api.whatsapp.com/send?phone=919905700600&text=Hi%20Qrenzy%2C%20I%20need%20help%20with%20my%20digital%20marketing" 
        class="wa-float" rel="noopener" target="_blank" title="Chat on WhatsApp" aria-label="Chat on WhatsApp">
        <svg viewBox="0 0 24 24" fill="currentColor" width="26" height="26"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
    </a>';
});

// ── COOKIE CONSENT BANNER ─────────────────────────────────────────────
add_action('wp_footer', function() {
    echo '
    <div id="cookie-banner" style="display:none;position:fixed;bottom:0;left:0;right:0;z-index:99999;background:#0a0a0a;color:#fff;padding:16px 24px;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;font-size:13px">
        <p style="margin:0;color:rgba(255,255,255,0.8);max-width:700px">🍪 We use cookies to improve your experience and analyse traffic. By continuing, you agree to our <a href="/privacy-policy/" style="color:#E31E24;text-decoration:underline">Privacy Policy</a>.</p>
        <div style="display:flex;gap:10px;flex-shrink:0">
            <button onclick="qrenzyCookieAccept()" style="background:#E31E24;color:#fff;border:none;border-radius:100px;padding:8px 20px;font-size:13px;font-weight:700;cursor:pointer">Accept</button>
            <button onclick="qrenzyCookieDismiss()" style="background:transparent;color:rgba(255,255,255,0.5);border:1px solid rgba(255,255,255,0.2);border-radius:100px;padding:8px 16px;font-size:13px;cursor:pointer">Dismiss</button>
        </div>
    </div>
    <script>
    (function(){
        var b = document.getElementById("cookie-banner");
        if (!localStorage.getItem("qrenzy_cookie_ok") && b) b.style.display = "flex";
    })();
    function qrenzyCookieAccept() { localStorage.setItem("qrenzy_cookie_ok","1"); document.getElementById("cookie-banner").style.display="none"; }
    function qrenzyCookieDismiss() { document.getElementById("cookie-banner").style.display="none"; }
    </script>';
});



// ── READING TIME ──────────────────────────────────────────────────────
function qrenzy_reading_time($post_id = null) {
    $content = get_post_field('post_content', $post_id ?: get_the_ID());
    $word_count = str_word_count(strip_tags($content));
    $minutes = max(1, ceil($word_count / 200));
    return $minutes . ' min read';
}

// ── CUSTOM POST META ──────────────────────────────────────────────────
function qrenzy_post_meta_box() {
    add_meta_box('qrenzy_post_meta', 'Qrenzy SEO & Post Settings', 'qrenzy_meta_callback', 'post', 'normal', 'high');
}
add_action('add_meta_boxes', 'qrenzy_post_meta_box');

function qrenzy_meta_callback($post) {
    wp_nonce_field('qrenzy_meta_nonce', 'qrenzy_nonce');
    $seo_title = get_post_meta($post->ID, '_qrenzy_seo_title', true);
    $seo_desc = get_post_meta($post->ID, '_qrenzy_seo_desc', true);
    $affiliate_disclosure = get_post_meta($post->ID, '_qrenzy_affiliate', true);
    $toc_enabled = get_post_meta($post->ID, '_qrenzy_toc', true);
    echo '<table style="width:100%;border-collapse:collapse">';
    echo '<tr><td style="padding:8px;font-weight:bold;width:160px">SEO Title</td><td style="padding:8px"><input type="text" name="qrenzy_seo_title" value="' . esc_attr($seo_title) . '" style="width:100%" placeholder="Custom SEO title (leave blank for post title)"></td></tr>';
    echo '<tr><td style="padding:8px;font-weight:bold">Meta Description</td><td style="padding:8px"><textarea name="qrenzy_seo_desc" style="width:100%;height:70px" placeholder="Meta description (150-160 chars recommended)">' . esc_textarea($seo_desc) . '</textarea></td></tr>';
    echo '<tr><td style="padding:8px;font-weight:bold">Affiliate Post</td><td style="padding:8px"><label><input type="checkbox" name="qrenzy_affiliate" value="1"' . checked($affiliate_disclosure, '1', false) . '> Show affiliate disclosure box</label></td></tr>';
    echo '<tr><td style="padding:8px;font-weight:bold">Table of Contents</td><td style="padding:8px"><label><input type="checkbox" name="qrenzy_toc" value="1"' . checked($toc_enabled, '1', false) . '> Auto-generate Table of Contents</label></td></tr>';
    echo '</table>';
}

function qrenzy_save_meta($post_id) {
    if (!isset($_POST['qrenzy_nonce']) || !wp_verify_nonce($_POST['qrenzy_nonce'], 'qrenzy_meta_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    update_post_meta($post_id, '_qrenzy_seo_title', sanitize_text_field($_POST['qrenzy_seo_title'] ?? ''));
    update_post_meta($post_id, '_qrenzy_seo_desc', sanitize_textarea_field($_POST['qrenzy_seo_desc'] ?? ''));
    update_post_meta($post_id, '_qrenzy_affiliate', isset($_POST['qrenzy_affiliate']) ? '1' : '');
    update_post_meta($post_id, '_qrenzy_toc', isset($_POST['qrenzy_toc']) ? '1' : '');
}
add_action('save_post', 'qrenzy_save_meta');

// ── SEO META TAGS ─────────────────────────────────────────────────────
// NOTE: meta description and canonical are handled by RankMath — we only add
// OG image/Twitter tags here which RankMath Free does not output.
function qrenzy_seo_meta() {
    global $post;
    // Skip entirely if RankMath or Yoast is active — they handle everything
    if (defined('RANK_MATH_VERSION')) return;
    if (defined('WPSEO_VERSION')) return;
    if (is_singular() && $post) {
        $seo_title = get_post_meta($post->ID, '_qrenzy_seo_title', true);
        $seo_desc = get_post_meta($post->ID, '_qrenzy_seo_desc', true);
        $title = $seo_title ?: get_the_title();
        $desc = $seo_desc ?: wp_trim_words(get_the_excerpt(), 25);
        $thumb = get_the_post_thumbnail_url($post->ID, 'qrenzy-featured');
        $default_og = get_template_directory_uri() . '/images/og-default.jpg';
        // meta description + canonical REMOVED — RankMath outputs these
        // Only output OG + Twitter tags (RankMath Free skips these)
        echo '<meta property="og:title" content="' . esc_attr($title) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr($desc) . '">' . "\n";
        echo '<meta property="og:url" content="' . get_permalink() . '">' . "\n";
        echo '<meta property="og:type" content="website">' . "\n";
        echo '<meta property="og:image" content="' . esc_url($thumb ?: $default_og) . '">' . "\n";
        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr($title) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr($desc) . '">' . "\n";
        echo '<meta name="twitter:image" content="' . esc_url($thumb ?: $default_og) . '">' . "\n";
        // canonical REMOVED — RankMath handles this
        // Article Schema
        $author_name = get_the_author_meta('display_name', $post->post_author);
        echo '<script type="application/ld+json">' . json_encode([
            '@context' => 'https://schema.org',
            '@type' => 'Article',
            'headline' => $title,
            'description' => $desc,
            'url' => get_permalink(),
            'datePublished' => get_the_date('c'),
            'dateModified' => get_the_modified_date('c'),
            'author' => ['@type' => 'Person', 'name' => $author_name, 'url' => get_author_posts_url($post->post_author)],
            'publisher' => ['@type' => 'Organization', 'name' => 'Qrenzy Digital Solutions', 'url' => home_url(), 'logo' => ['@type' => 'ImageObject', 'url' => get_template_directory_uri() . '/logo.png']],
            'image' => $thumb ?: $default_og,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }
}
add_action('wp_head', 'qrenzy_seo_meta');

// ── BREADCRUMBS ───────────────────────────────────────────────────────
function qrenzy_breadcrumbs() {
    echo '<ol class="bc-list">';
    echo '<li><a href="' . home_url() . '">Home</a></li>';
    if (is_category() || is_single()) {
        $cats = get_the_category();
        if ($cats) {
            echo '<li class="bc-sep">/</li>';
            echo '<li><a href="' . get_category_link($cats[0]->term_id) . '">' . esc_html($cats[0]->name) . '</a></li>';
        }
        if (is_single()) {
            echo '<li class="bc-sep">/</li>';
            echo '<li>' . esc_html(get_the_title()) . '</li>';
        }
    } elseif (is_page()) {
        echo '<li class="bc-sep">/</li>';
        echo '<li>' . esc_html(get_the_title()) . '</li>';
    } elseif (is_search()) {
        echo '<li class="bc-sep">/</li>';
        echo '<li>Search: "' . esc_html(get_search_query()) . '"</li>';
    }
    echo '</ol>';
}

// ── AUTO TABLE OF CONTENTS ────────────────────────────────────────────
function qrenzy_generate_toc($content) {
    global $post;
    if (!$post || !get_post_meta($post->ID, '_qrenzy_toc', true)) return $content;
    preg_match_all('/<h([23])[^>]*>(.*?)<\/h[23]>/i', $content, $matches);
    if (count($matches[0]) < 3) return $content;
    $toc = '<div class="toc-box" style="margin:32px 0"><div class="toc-title">📋 Table of Contents</div><ul class="toc-list">';
    foreach ($matches[2] as $i => $heading) {
        $level = $matches[1][$i];
        $clean = strip_tags($heading);
        $id = 'toc-' . sanitize_title($clean);
        $content = str_replace($matches[0][$i], '<h' . $level . ' id="' . $id . '">' . $heading . '</h' . $level . '>', $content);
        $class = $level == 3 ? ' class="toc-h3"' : '';
        $toc .= '<li' . $class . '><a href="#' . $id . '">' . esc_html($clean) . '</a></li>';
    }
    $toc .= '</ul></div>';
    $content = $toc . $content;
    return $content;
}
add_filter('the_content', 'qrenzy_generate_toc');

// ── WIDGET AREAS ──────────────────────────────────────────────────────
function qrenzy_widgets() {
    register_sidebar(['name' => 'Blog Sidebar', 'id' => 'blog-sidebar', 'before_widget' => '<div class="widget">', 'after_widget' => '</div>', 'before_title' => '<h4 class="widget-title">', 'after_title' => '</h4>']);
}
add_action('widgets_init', 'qrenzy_widgets');

// ── SECURITY HEADERS — improves GEO technical score ──────────────────
add_filter('wp_headers', function($headers) {
  $headers['X-Content-Type-Options']    = 'nosniff';
  $headers['X-Frame-Options']           = 'SAMEORIGIN';
  $headers['X-XSS-Protection']         = '1; mode=block';
  $headers['Referrer-Policy']           = 'strict-origin-when-cross-origin';
  $headers['Permissions-Policy']        = 'geolocation=(), microphone=(), camera=()';
  $headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
  return $headers;
});


// ── GEO: SPEAKABLE SCHEMA — voice search content ─────────────────────
add_action('wp_head', function() {
  if (!is_singular('post')) return;
  global $post;
  $slug = $post->post_name ?? '';
  // Speakable on all voice-search, GBP, local SEO high-intent posts
  $voice_slugs = [
    'voice-search-optimization-small-business',
    'google-business-profile-optimization',
    'how-to-rank-on-google-maps',
    'local-seo-checklist-for-small-business',
    'local-seo-tips-for-kerala-businesses',
    'how-to-get-more-google-reviews',
    'add-whatsapp-to-google-business-profile',
    'how-to-get-found-on-chatgpt-and-google-ai',
    'keyword-research-for-beginners',
    'on-page-seo-checklist',
  ];
  if (!in_array($slug, $voice_slugs)) return;
  $schema = [
    '@context'  => 'https://schema.org',
    '@type'     => 'WebPage',
    'name'      => get_the_title(),
    'url'       => get_permalink(),
    'author'    => ['@type'=>'Person','@id'=>'https://www.qrenzy.com/#founder','name'=>'Sajeesh Vaderiyattil Sahadevan'],
    'publisher' => ['@type'=>'Organization','@id'=>'https://www.qrenzy.com/#organization','name'=>'Qrenzy Digital Solutions'],
    'speakable' => [
      '@type'       => 'SpeakableSpecification',
      'cssSelector' => ['h1','.post-content h2:first-of-type','.post-content p:first-of-type'],
    ],
  ];
  echo '<script type="application/ld+json">'.json_encode($schema, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).'</script>'."\n";
});

// ── GEO: AUTHOR PERSON SCHEMA on all blog posts ───────────────────────
add_action('wp_head', function() {
  if (!is_singular('post')) return;
  global $post;
  $author_schema = [
    '@context' => 'https://schema.org',
    '@type'    => 'Person',
    '@id'      => 'https://www.qrenzy.com/#founder',
    'name'     => 'Sajeesh Vaderiyattil Sahadevan',
    'jobTitle' => 'Founder & Digital Marketing Strategist',
    'url'      => 'https://www.qrenzy.com/about/',
    'worksFor' => ['@type'=>'Organization','name'=>'Qrenzy Digital Solutions','url'=>'https://www.qrenzy.com'],
    'description' => 'Founder of Qrenzy Digital Solutions with 18+ years of experience in SEO, web development, social media marketing and AI marketing automation across India, Oman and UAE.',
    'knowsAbout' => ['Search Engine Optimization','Local SEO','Digital Marketing','AI Marketing Automation','Google Business Profile','Social Media Marketing'],
    'sameAs' => ['https://www.qrenzy.com/about/','https://www.youtube.com/@qrenzy'],
  ];
  echo '<script type="application/ld+json">'.json_encode($author_schema, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).'</script>'."\n";
});

// ── GEO: UPDATE CATEGORY COLORS ──────────────────────────────────────

function qrenzy_cat_color($cat_slug) {
    $colors = [
        'seo' => '#6B21A8', 'ai-tools' => '#1565C0', 'hosting' => '#2E7D32',
        'social-media' => '#E65100', 'ppc' => '#C62828', 'web-design' => '#00695C',
        'digital-marketing' => '#E31E24', 'case-study' => '#4527A0',
    ];
    return $colors[$cat_slug] ?? '#E31E24';
}

// ── RELATED POSTS ─────────────────────────────────────────────────────
function qrenzy_related_posts($post_id, $count = 3) {
    $cats = wp_get_post_categories($post_id);
    if (!$cats) return [];
    $related = get_posts([
        'category__in' => $cats,
        'post__not_in' => [$post_id],
        'posts_per_page' => $count,
        'orderby' => 'rand',
    ]);
    return $related;
}

// ── POPULAR POSTS (by comment count) ─────────────────────────────────
function qrenzy_popular_posts($count = 5) {
    return get_posts([
        'posts_per_page' => $count,
        'orderby' => 'comment_count',
        'order' => 'DESC',
    ]);
}

// ── REMOVE WORDPRESS BLOAT ────────────────────────────────────────────
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'wp_resource_hints', 2);
remove_action('wp_head', 'feed_links', 2);
remove_action('wp_head', 'feed_links_extra', 3);
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10);
remove_action('wp_head', 'locale_stylesheet');
remove_action('wp_head', 'wp_oembed_add_discovery_links');
remove_action('wp_head', 'wp_oembed_add_host_js');
remove_action('wp_head', 'rest_output_link_wp_head');
remove_action('wp_head', 'gutenberg_post_link', 10);
add_filter('the_generator', '__return_empty_string');
add_filter('get_the_author_user_url', '__return_empty_string');


// ── DISABLE EMOJIS ────────────────────────────────────────────────────
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');

// ── REST: hide user list from anonymous visitors (keeps WPForms/Rank Math working)
add_filter('rest_endpoints', function($endpoints) {
    if (!is_user_logged_in()) {
        unset($endpoints['/wp/v2/users'], $endpoints['/wp/v2/users/(?P<id>[\\d]+)']);
    }
    return $endpoints;
});

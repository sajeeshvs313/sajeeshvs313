<?php
/**
 * Qrenzy Automated SEO Audit Engine
 * Triggered via AJAX when WPForms form ID 21 is submitted
 */

// ── CONSTANTS ─────────────────────────────────────────────────────────
// Secrets live in wp-config.php:  define('QRENZY_MAILERLITE_API', '...');
if (!defined('QRENZY_FROM_EMAIL')) define('QRENZY_FROM_EMAIL', 'info@qrenzy.com');
if (!defined('QRENZY_FROM_NAME')) define('QRENZY_FROM_NAME', 'Sajeesh from Qrenzy');

// ── HOOK INTO WPFORMS SUBMISSION ──────────────────────────────────────
add_action('wpforms_process_complete', 'qrenzy_handle_audit_form', 10, 4);

function qrenzy_handle_audit_form($fields, $entry, $form_data, $entry_id) {
  // Only trigger for form ID 21
  if ((int)$form_data['id'] !== 21) return;

  $name    = '';
  $email   = '';
  $website = '';
  $phone   = '';
  $location = '';

  foreach ($fields as $field) {
    $label = strtolower($field['name'] ?? '');
    $value = sanitize_text_field($field['value'] ?? '');
    if (strpos($label, 'name') !== false)     $name    = $value;
    if (strpos($label, 'email') !== false)    $email   = sanitize_email($field['value'] ?? '');
    if (strpos($label, 'website') !== false || strpos($label, 'url') !== false) $website = esc_url_raw($value);
    if (strpos($label, 'phone') !== false)    $phone   = $value;
    if (strpos($label, 'location') !== false || strpos($label, 'business') !== false) $location = $value;
  }

  if (!$email || !$website) return;

  // Clean URL
  $url = $website;
  if (!preg_match('/^https?:\/\//i', $url)) $url = 'https://' . $url;
  $url = rtrim($url, '/');

  // Schedule async audit via WP-Cron (avoids PHP timeout on shared hosting)
  $args = [
    'name'     => $name,
    'email'    => $email,
    'url'      => $url,
    'phone'    => $phone,
    'location' => $location,
  ];
  wp_schedule_single_event(time() + 5, 'qrenzy_run_async_audit', [$args]);
  spawn_cron(); // force immediate cron execution
}

// Async audit handler - runs via WP-Cron
add_action('qrenzy_run_async_audit', 'qrenzy_process_async_audit');
function qrenzy_process_async_audit($args) {
  $name     = $args['name']     ?? '';
  $email    = $args['email']    ?? '';
  $url      = $args['url']      ?? '';
  $phone    = $args['phone']    ?? '';
  $location = $args['location'] ?? '';

  if (!$email || !$url) return;

  // Run audit (now with plenty of time)
  $audit = qrenzy_run_seo_audit($url);

  // Build email HTML
  $html = qrenzy_build_audit_email($name, $url, $audit);

  // Send via wp_mail
  $headers = [
    'Content-Type: text/html; charset=UTF-8',
    'From: ' . QRENZY_FROM_NAME . ' <' . QRENZY_FROM_EMAIL . '>',
  ];

  wp_mail($email, 'Your Free SEO Audit Report — ' . parse_url($url, PHP_URL_HOST), $html, $headers);

  // Also notify you
  wp_mail(QRENZY_FROM_EMAIL,
    'New SEO Audit Request: ' . parse_url($url, PHP_URL_HOST),
    '<p><strong>Name:</strong> ' . esc_html($name) . '</p>
     <p><strong>Email:</strong> ' . esc_html($email) . '</p>
     <p><strong>Website:</strong> ' . esc_html($url) . '</p>
     <p><strong>Phone:</strong> ' . esc_html($phone) . '</p>
     <p><strong>Location:</strong> ' . esc_html($location) . '</p>
     <p><strong>Overall Score:</strong> ' . $audit['overall_score'] . '/100</p>',
    $headers
  );

  // Add to MailerLite
  qrenzy_add_to_mailerlite($email, $name);
}

// ── SEO AUDIT ENGINE ──────────────────────────────────────────────────
function qrenzy_run_seo_audit($url) {
  $audit = [];
  $domain = parse_url($url, PHP_URL_HOST);

  // 1. PageSpeed — Mobile
  $ps_mobile = qrenzy_pagespeed($url, 'mobile');
  // 2. PageSpeed — Desktop
  $ps_desktop = qrenzy_pagespeed($url, 'desktop');
  // 3. Fetch page HTML for on-page checks
  $html_data = qrenzy_fetch_page($url);

  // Mobile scores
  $audit['mobile_score']      = $ps_mobile['score'] ?? 0;
  $audit['desktop_score']     = $ps_desktop['score'] ?? 0;
  $audit['fcp_mobile']        = $ps_mobile['fcp'] ?? 'N/A';
  $audit['lcp_mobile']        = $ps_mobile['lcp'] ?? 'N/A';
  $audit['cls_mobile']        = $ps_mobile['cls'] ?? 'N/A';
  $audit['tbt_mobile']        = $ps_mobile['tbt'] ?? 'N/A';
  $audit['fcp_desktop']       = $ps_desktop['fcp'] ?? 'N/A';
  $audit['lcp_desktop']       = $ps_desktop['lcp'] ?? 'N/A';
  $audit['speed_opportunities'] = $ps_mobile['opportunities'] ?? [];

  // On-page checks
  $audit['title']             = $html_data['title'] ?? '';
  $audit['meta_desc']         = $html_data['meta_desc'] ?? '';
  $audit['h1_count']          = $html_data['h1_count'] ?? 0;
  $audit['h1_text']           = $html_data['h1_text'] ?? '';
  $audit['h2_count']          = $html_data['h2_count'] ?? 0;
  $audit['img_total']         = $html_data['img_total'] ?? 0;
  $audit['img_no_alt']        = $html_data['img_no_alt'] ?? 0;
  $audit['has_ssl']           = (strpos($url, 'https://') === 0);
  $audit['has_viewport']      = $html_data['has_viewport'] ?? false;
  $audit['canonical']         = $html_data['canonical'] ?? '';
  $audit['robots_meta']       = $html_data['robots_meta'] ?? '';
  $audit['og_title']          = $html_data['og_title'] ?? '';
  $audit['schema_found']      = $html_data['schema_found'] ?? false;
  $audit['word_count']        = $html_data['word_count'] ?? 0;

  // Title & meta analysis
  $title_len = strlen($audit['title']);
  $meta_len  = strlen($audit['meta_desc']);
  $audit['title_length']      = $title_len;
  $audit['meta_desc_length']  = $meta_len;
  $audit['title_status']      = ($title_len >= 50 && $title_len <= 60) ? 'good' : (($title_len > 0) ? 'warning' : 'error');
  $audit['meta_status']       = ($meta_len >= 140 && $meta_len <= 160) ? 'good' : (($meta_len > 0) ? 'warning' : 'error');

  // Robots & Sitemap
  $audit['has_robots']        = qrenzy_check_url($domain . '/robots.txt');
  $audit['has_sitemap']       = qrenzy_check_url($domain . '/sitemap.xml') || qrenzy_check_url($domain . '/sitemap_index.xml');

  // Calculate overall score
  $score = 0;
  $score += min(25, $audit['mobile_score'] / 4);
  $score += min(25, $audit['desktop_score'] / 4);
  $score += ($audit['has_ssl'] ? 10 : 0);
  $score += ($audit['title_status'] === 'good' ? 8 : ($audit['title_status'] === 'warning' ? 4 : 0));
  $score += ($audit['meta_status'] === 'good' ? 8 : ($audit['meta_status'] === 'warning' ? 4 : 0));
  $score += ($audit['h1_count'] === 1 ? 5 : 0);
  $score += ($audit['has_robots'] ? 5 : 0);
  $score += ($audit['has_sitemap'] ? 5 : 0);
  $score += ($audit['schema_found'] ? 5 : 0);
  $score += ($audit['img_no_alt'] === 0 ? 4 : 0);
  $audit['overall_score'] = min(100, round($score));
  $audit['score_label']   = $score >= 80 ? 'Good' : ($score >= 60 ? 'Needs Improvement' : 'Poor');
  $audit['score_color']   = $score >= 80 ? '#16A34A' : ($score >= 60 ? '#F59E0B' : '#E31E24');
  $audit['domain']        = $domain;
  $audit['url']           = $url;

  return $audit;
}

function qrenzy_pagespeed($url, $strategy = 'mobile') {
  // Use keyless endpoint — API key causes 403 when called server-side
  $api_url = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=' . urlencode($url) . '&strategy=' . $strategy;
  $response = wp_remote_get($api_url, ['timeout' => 60, 'user-agent' => 'Mozilla/5.0 (compatible; QrenzyBot/1.0)']);
  if (is_wp_error($response)) return [];
  $body = json_decode(wp_remote_retrieve_body($response), true);
  if (!$body || !isset($body['lighthouseResult'])) return [];

  $cats = $body['lighthouseResult']['categories'] ?? [];
  $audits = $body['lighthouseResult']['audits'] ?? [];

  $opportunities = [];
  foreach (['render-blocking-resources','unused-css-rules','unused-javascript','uses-optimized-images','uses-webp-images','uses-text-compression'] as $key) {
    if (isset($audits[$key]) && ($audits[$key]['score'] ?? 1) < 0.9) {
      $opportunities[] = $audits[$key]['title'] ?? $key;
    }
  }

  return [
    'score'         => round(($cats['performance']['score'] ?? 0) * 100),
    'fcp'           => $audits['first-contentful-paint']['displayValue'] ?? 'N/A',
    'lcp'           => $audits['largest-contentful-paint']['displayValue'] ?? 'N/A',
    'cls'           => $audits['cumulative-layout-shift']['displayValue'] ?? 'N/A',
    'tbt'           => $audits['total-blocking-time']['displayValue'] ?? 'N/A',
    'opportunities' => $opportunities,
  ];
}

// Allow only public http(s) URLs (blocks localhost / private / metadata IPs)
function qrenzy_is_safe_url($url) {
  if (!wp_http_validate_url($url)) return false;
  $host = wp_parse_url($url, PHP_URL_HOST);
  if (!$host) return false;
  $ips = filter_var($host, FILTER_VALIDATE_IP) ? [$host] : (gethostbynamel($host) ?: []);
  if (!$ips) return false;
  foreach ($ips as $ip) {
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return false;
  }
  return true;
}

function qrenzy_fetch_page($url) {
  if (!qrenzy_is_safe_url($url)) return [];
  $response = wp_safe_remote_get($url, ['timeout' => 15, 'user-agent' => 'Mozilla/5.0 (compatible; QrenzyBot/1.0)']);
  if (is_wp_error($response)) return [];
  $html = wp_remote_retrieve_body($response);
  if (!$html) return [];

  $data = [];
  // Title
  preg_match('/<title[^>]*>(.*?)<\/title>/si', $html, $m);
  $data['title'] = html_entity_decode(strip_tags($m[1] ?? ''), ENT_QUOTES, 'UTF-8');
  // Meta description
  preg_match('/<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']/si', $html, $m);
  $data['meta_desc'] = html_entity_decode($m[1] ?? '', ENT_QUOTES, 'UTF-8');
  // H1
  preg_match_all('/<h1[^>]*>(.*?)<\/h1>/si', $html, $m);
  $data['h1_count'] = count($m[0] ?? []);
  $data['h1_text']  = html_entity_decode(strip_tags($m[1][0] ?? ''), ENT_QUOTES, 'UTF-8');
  // H2
  preg_match_all('/<h2[^>]*>/si', $html, $m);
  $data['h2_count'] = count($m[0] ?? []);
  // Images
  preg_match_all('/<img[^>]+>/si', $html, $imgs);
  $data['img_total']  = count($imgs[0] ?? []);
  $no_alt = 0;
  foreach (($imgs[0] ?? []) as $img) {
    if (!preg_match('/alt=["\'][^"\']+["\']/si', $img)) $no_alt++;
  }
  $data['img_no_alt'] = $no_alt;
  // Viewport
  $data['has_viewport'] = (bool)preg_match('/<meta[^>]+name=["\']viewport["\']/si', $html);
  // Canonical
  preg_match('/<link[^>]+rel=["\']canonical["\'][^>]+href=["\'](.*?)["\']/si', $html, $m);
  $data['canonical'] = $m[1] ?? '';
  // OG Title
  preg_match('/<meta[^>]+property=["\']og:title["\'][^>]+content=["\'](.*?)["\']/si', $html, $m);
  $data['og_title'] = $m[1] ?? '';
  // Schema
  $data['schema_found'] = (bool)strpos($html, 'application/ld+json');
  // Robots meta
  preg_match('/<meta[^>]+name=["\']robots["\'][^>]+content=["\'](.*?)["\']/si', $html, $m);
  $data['robots_meta'] = $m[1] ?? '';
  // Word count
  $body_text = preg_replace('/<[^>]+>/', ' ', $html);
  $body_text = preg_replace('/\s+/', ' ', $body_text);
  $data['word_count'] = str_word_count(trim($body_text));

  return $data;
}

function qrenzy_check_url($path) {
  if (!preg_match('/^https?:\/\//i', $path)) $path = 'https://' . $path;
  if (!qrenzy_is_safe_url($path)) return false;
  $r = wp_safe_remote_head($path, ['timeout' => 8]);
  if (is_wp_error($r)) return false;
  return wp_remote_retrieve_response_code($r) === 200;
}

// ── EMAIL BUILDER ─────────────────────────────────────────────────────
function qrenzy_build_audit_email($name, $url, $a) {
  $first_name = explode(' ', $name)[0];
  $domain = $a['domain'];
  $score_bar = min(100, $a['overall_score']);

  $checks = [
    ['SSL Certificate (HTTPS)',     $a['has_ssl'],                    'Your website uses HTTPS — secure and trusted by Google.', 'SSL missing — Google penalises non-HTTPS sites. Install an SSL certificate immediately.'],
    ['Title Tag',                   $a['title_status'] === 'good',    'Title tag length is perfect (' . $a['title_length'] . ' chars).', 'Title tag is ' . ($a['title_length'] === 0 ? 'missing' : ($a['title_length'] < 50 ? 'too short (' . $a['title_length'] . ' chars — aim for 50-60)' : 'too long (' . $a['title_length'] . ' chars — keep under 60)')) . '.'],
    ['Meta Description',            $a['meta_status'] === 'good',     'Meta description length is ideal (' . $a['meta_desc_length'] . ' chars).', 'Meta description is ' . ($a['meta_desc_length'] === 0 ? 'missing — add a 140-160 char description.' : ($a['meta_desc_length'] < 140 ? 'too short (' . $a['meta_desc_length'] . ' chars).' : 'too long (' . $a['meta_desc_length'] . ' chars).'))],
    ['H1 Tag',                      $a['h1_count'] === 1,             'One H1 tag found — perfect SEO structure.', ($a['h1_count'] === 0 ? 'No H1 tag found — every page needs exactly one H1.' : 'Multiple H1 tags found (' . $a['h1_count'] . ') — use only one H1 per page.')],
    ['Image Alt Tags',              $a['img_no_alt'] === 0,           'All images have alt tags — great for SEO and accessibility.', $a['img_no_alt'] . ' image(s) missing alt tags — add descriptive alt text for SEO.'],
    ['Robots.txt',                  $a['has_robots'],                 'robots.txt file found — search engines can crawl correctly.', 'robots.txt file missing — create one to guide search engine crawlers.'],
    ['XML Sitemap',                 $a['has_sitemap'],                'XML sitemap found — helps Google index all pages.', 'XML sitemap not found — create and submit one to Google Search Console.'],
    ['Structured Data (Schema)',    $a['schema_found'],               'Schema markup found — eligible for rich results in Google.', 'No schema markup found — add structured data to get rich results in Google.'],
    ['Viewport Meta Tag',           $a['has_viewport'],               'Viewport meta tag present — good mobile SEO foundation.', 'Viewport meta tag missing — required for mobile-friendly pages.'],
    ['Canonical Tag',               !empty($a['canonical']),          'Canonical tag found — prevents duplicate content issues.', 'No canonical tag found — add canonical tags to prevent duplicate content penalties.'],
  ];

  $checks_html = '';
  $pass = 0; $fail = 0;
  foreach ($checks as $c) {
    $ok = $c[1];
    if ($ok) $pass++; else $fail++;
    $icon  = $ok ? '✅' : '❌';
    $color = $ok ? '#16A34A' : '#E31E24';
    $msg   = $ok ? $c[2] : $c[3];
    $checks_html .= '
    <tr>
      <td style="padding:12px 16px;border-bottom:1px solid #f0f0f0;font-size:14px;color:#333">' . $icon . ' ' . $c[0] . '</td>
      <td style="padding:12px 16px;border-bottom:1px solid #f0f0f0;font-size:13px;color:' . $color . '">' . $msg . '</td>
    </tr>';
  }

  $opps_html = '';
  if (!empty($a['speed_opportunities'])) {
    foreach (array_slice($a['speed_opportunities'], 0, 4) as $opp) {
      $opps_html .= '<li style="font-size:13px;color:#555;padding:5px 0">⚡ ' . esc_html($opp) . '</li>';
    }
  } else {
    $opps_html = '<li style="font-size:13px;color:#16A34A;padding:5px 0">✅ No major speed issues found</li>';
  }

  $score_color = $a['score_color'];
  $score_label = $a['score_label'];

  return '<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f5f5f5;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif">
<div style="max-width:620px;margin:0 auto;padding:24px 16px">

  <!-- Header -->
  <div style="background:#E31E24;border-radius:16px 16px 0 0;padding:32px;text-align:center">
    <div style="font-size:28px;font-weight:900;color:#fff;letter-spacing:-0.02em">Qrenzy Digital Solutions</div>
    <div style="font-size:13px;color:rgba(255,255,255,0.8);margin-top:4px">Free SEO Audit Report</div>
  </div>

  <!-- Body -->
  <div style="background:#fff;padding:32px;border-radius:0 0 16px 16px;border:1px solid #e8e8e4;border-top:none">

    <p style="font-size:16px;color:#333;line-height:1.7;margin-bottom:24px">
      Hi <strong>' . esc_html($first_name) . '</strong>,<br><br>
      Your free SEO audit for <strong>' . esc_html($domain) . '</strong> is ready. Here\'s what we found:
    </p>

    <!-- Overall Score -->
    <div style="background:#f8f8f6;border-radius:14px;padding:24px;text-align:center;margin-bottom:28px;border:1px solid #e8e8e4">
      <div style="font-size:13px;font-weight:700;color:#888;letter-spacing:0.08em;text-transform:uppercase;margin-bottom:8px">Overall SEO Score</div>
      <div style="font-size:64px;font-weight:900;color:' . $score_color . ';line-height:1;letter-spacing:-0.04em">' . $a['overall_score'] . '</div>
      <div style="font-size:13px;color:#aaa;margin-bottom:14px">out of 100 — <strong style="color:' . $score_color . '">' . $score_label . '</strong></div>
      <div style="background:#e8e8e4;border-radius:100px;height:8px;overflow:hidden">
        <div style="background:' . $score_color . ';height:8px;width:' . $score_bar . '%;border-radius:100px"></div>
      </div>
      <div style="display:flex;justify-content:space-between;margin-top:12px">
        <span style="font-size:12px;color:#888">✅ ' . $pass . ' checks passed</span>
        <span style="font-size:12px;color:#E31E24">❌ ' . $fail . ' issues found</span>
      </div>
    </div>

    <!-- Speed Scores -->
    <h2 style="font-size:17px;font-weight:800;color:#0a0a0a;margin-bottom:16px">⚡ Page Speed Scores</h2>
    <div style="display:flex;gap:12px;margin-bottom:28px">
      <div style="flex:1;background:#f8f8f6;border-radius:12px;padding:16px;text-align:center;border:1px solid #e8e8e4">
        <div style="font-size:32px;font-weight:900;color:' . ($a['mobile_score'] >= 90 ? '#16A34A' : ($a['mobile_score'] >= 50 ? '#F59E0B' : '#E31E24')) . '">' . $a['mobile_score'] . '</div>
        <div style="font-size:12px;font-weight:700;color:#555;margin-top:4px">📱 Mobile</div>
        <div style="font-size:11px;color:#aaa;margin-top:3px">FCP: ' . $a['fcp_mobile'] . '</div>
        <div style="font-size:11px;color:#aaa">LCP: ' . $a['lcp_mobile'] . '</div>
      </div>
      <div style="flex:1;background:#f8f8f6;border-radius:12px;padding:16px;text-align:center;border:1px solid #e8e8e4">
        <div style="font-size:32px;font-weight:900;color:' . ($a['desktop_score'] >= 90 ? '#16A34A' : ($a['desktop_score'] >= 50 ? '#F59E0B' : '#E31E24')) . '">' . $a['desktop_score'] . '</div>
        <div style="font-size:12px;font-weight:700;color:#555;margin-top:4px">💻 Desktop</div>
        <div style="font-size:11px;color:#aaa;margin-top:3px">FCP: ' . $a['fcp_desktop'] . '</div>
        <div style="font-size:11px;color:#aaa">LCP: ' . $a['lcp_desktop'] . '</div>
      </div>
    </div>

    <!-- On-Page Details -->
    <h2 style="font-size:17px;font-weight:800;color:#0a0a0a;margin-bottom:4px">📄 On-Page Details</h2>
    ' . (!empty($a['title']) ? '<p style="font-size:13px;color:#666;margin-bottom:16px">Title: <em>"' . esc_html(substr($a['title'], 0, 70)) . '"</em></p>' : '') . '

    <!-- SEO Checks Table -->
    <h2 style="font-size:17px;font-weight:800;color:#0a0a0a;margin:24px 0 12px">🔍 SEO Checks</h2>
    <table style="width:100%;border-collapse:collapse;margin-bottom:28px">
      <thead>
        <tr style="background:#f8f8f6">
          <th style="padding:10px 16px;text-align:left;font-size:12px;color:#888;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;border-bottom:2px solid #e8e8e4">Check</th>
          <th style="padding:10px 16px;text-align:left;font-size:12px;color:#888;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;border-bottom:2px solid #e8e8e4">Finding</th>
        </tr>
      </thead>
      <tbody>' . $checks_html . '</tbody>
    </table>

    <!-- Speed Opportunities -->
    <div style="background:#fff8f0;border-radius:12px;padding:20px;border:1px solid #fed7aa;margin-bottom:28px">
      <h3 style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:12px">⚡ Speed Improvement Opportunities</h3>
      <ul style="list-style:none;margin:0;padding:0">' . $opps_html . '</ul>
    </div>

    <!-- Next Steps -->
    <div style="background:#f8f8f6;border-radius:12px;padding:20px;border:1px solid #e8e8e4;margin-bottom:28px">
      <h3 style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:12px">🎯 Your Next Steps</h3>
      <ol style="margin:0;padding-left:18px">
        <li style="font-size:13px;color:#555;padding:5px 0">Fix the <strong>' . $fail . ' critical issues</strong> identified above</li>
        <li style="font-size:13px;color:#555;padding:5px 0">Improve page speed — especially mobile score (currently ' . $a['mobile_score'] . '/100)</li>
        <li style="font-size:13px;color:#555;padding:5px 0">Submit XML sitemap to Google Search Console</li>
        <li style="font-size:13px;color:#555;padding:5px 0">Build quality backlinks from India/Gulf market websites</li>
        <li style="font-size:13px;color:#555;padding:5px 0">Create keyword-targeted content for your target market</li>
      </ol>
    </div>

    <!-- CTA -->
    <div style="background:#E31E24;border-radius:14px;padding:24px;text-align:center;margin-bottom:24px">
      <div style="font-size:18px;font-weight:800;color:#fff;margin-bottom:8px">Want Us to Fix All This For You?</div>
      <div style="font-size:13px;color:rgba(255,255,255,0.85);margin-bottom:18px">Our SEO experts can fix every issue above and get you ranking on Page 1 within 90 days.</div>
      <a href="https://api.whatsapp.com/send?phone=919905700600&text=Hi+Sajeesh%2C+I+got+my+SEO+audit+for+' . urlencode($domain) . '+and+want+to+discuss+improving+my+score" style="display:inline-block;background:#fff;color:#E31E24;font-weight:800;font-size:14px;padding:14px 28px;border-radius:100px;text-decoration:none">💬 WhatsApp Us Now →</a>
    </div>

    <!-- Signature -->
    <div style="border-top:1px solid #f0f0f0;padding-top:20px">
      <p style="font-size:13px;color:#888;line-height:1.7;margin:0">
        Best regards,<br>
        <strong style="color:#0a0a0a">Sajeesh Vaderiyattil</strong><br>
        Founder & Digital Strategist, Qrenzy Digital Solutions<br>
        📞 <a href="tel:+919905700600" style="color:#E31E24">+91 99057 00600</a> &nbsp;|&nbsp;
        💬 <a href="https://api.whatsapp.com/send?phone=919905700600" style="color:#E31E24">WhatsApp</a> &nbsp;|&nbsp;
        🌐 <a href="https://qrenzy.com" style="color:#E31E24">qrenzy.com</a>
      </p>
    </div>
  </div>

  <!-- Footer -->
  <div style="text-align:center;padding:16px">
    <p style="font-size:11px;color:#bbb;margin:0">Qrenzy Digital Solutions — Thrissur, Kerala, India · Oman · UAE<br>
    This is an automated SEO audit. Data sourced from Google PageSpeed Insights API.</p>
  </div>
</div>
</body>
</html>';
}

// ── ADD TO MAILERLITE ─────────────────────────────────────────────────
function qrenzy_add_to_mailerlite($email, $name) {
  if (!defined('QRENZY_MAILERLITE_API') || !QRENZY_MAILERLITE_API) return;
  $parts = explode(' ', trim($name), 2);
  wp_remote_post('https://connect.mailerlite.com/api/subscribers', [
    'timeout' => 10,
    'headers' => [
      'Content-Type'  => 'application/json',
      'Authorization' => 'Bearer ' . QRENZY_MAILERLITE_API,
      'Accept'        => 'application/json',
    ],
    'body' => json_encode([
      'email'  => $email,
      'fields' => [
        'name'      => $parts[0] ?? '',
        'last_name' => $parts[1] ?? '',
      ],
      'groups' => [], // add MailerLite group ID here if needed
    ]),
  ]);
}

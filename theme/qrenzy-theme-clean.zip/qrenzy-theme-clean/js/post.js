// Reading progress bar
window.addEventListener('scroll', function() {
  var bar = document.getElementById('progress-bar');
  if (!bar) return;
  var scrolled = (window.pageYOffset / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
  bar.style.width = Math.min(scrolled, 100) + '%';
}, { passive: true });

// Auto-generate TOC from article headings
document.addEventListener('DOMContentLoaded', function() {
  var article = document.querySelector('.article-body');
  var tocList = document.getElementById('toc-list');
  if (!article || !tocList) return;
  var headings = article.querySelectorAll('h2, h3');
  if (headings.length < 3) {
    var tocBox = document.getElementById('toc-sidebar');
    if (tocBox) tocBox.style.display = 'none';
    return;
  }
  tocList.innerHTML = '';
  headings.forEach(function(h, i) {
    var id = 'heading-' + i;
    h.id = id;
    var li = document.createElement('li');
    if (h.tagName === 'H3') li.className = 'toc-h3';
    var a = document.createElement('a');
    a.href = '#' + id;
    a.textContent = h.textContent;
    li.appendChild(a);
    tocList.appendChild(li);
  });

  // Active TOC highlight
  var tocLinks = tocList.querySelectorAll('a');
  window.addEventListener('scroll', function() {
    var pos = window.pageYOffset + 100;
    headings.forEach(function(h, i) {
      if (h.offsetTop <= pos) {
        tocLinks.forEach(function(l) { l.classList.remove('active'); });
        if (tocLinks[i]) tocLinks[i].classList.add('active');
      }
    });
  }, { passive: true });
});

// Share functions
function sharePost(platform) {
  var url = encodeURIComponent(window.location.href);
  var title = encodeURIComponent(document.title);
  var links = {
    facebook: 'https://www.facebook.com/sharer/sharer.php?u=' + url,
    whatsapp: 'https://api.whatsapp.com/send?text=' + title + ' ' + url,
    twitter: 'https://twitter.com/intent/tweet?text=' + title + '&url=' + url,
    linkedin: 'https://www.linkedin.com/sharing/share-offsite/?url=' + url
  };
  if (links[platform]) window.open(links[platform], '_blank', 'width=600,height=400');
}

function copyLink() {
  var btn = document.getElementById('copy-btn');
  navigator.clipboard.writeText(window.location.href).then(function() {
    btn.classList.add('copied');
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" width="16" height="16"><polyline points="20 6 9 17 4 12"/></svg>';
    setTimeout(function() {
      btn.classList.remove('copied');
      btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>';
    }, 2000);
  });
}

// Mobile menu
function toggleMenu() {
  var menu = document.getElementById('mobile-menu');
  var btn = document.getElementById('ham');
  var isOpen = menu.style.display === 'flex';
  if (isOpen) {
    menu.style.display = 'none';
    menu.hidden = true;
    btn.classList.remove('open');
    btn.setAttribute('aria-expanded', 'false');
    btn.setAttribute('aria-label', 'Open navigation menu');
  } else {
    menu.style.display = 'flex';
    menu.hidden = false;
    btn.classList.add('open');
    btn.setAttribute('aria-expanded', 'true');
    btn.setAttribute('aria-label', 'Close navigation menu');
  }
}
function closeMenu() {
  var m = document.getElementById('mobile-menu');
  var b = document.getElementById('ham');
  if (m) { m.style.display = 'none'; m.hidden = true; }
  if (b) { b.classList.remove('open'); b.setAttribute('aria-expanded','false'); b.setAttribute('aria-label','Open navigation menu'); }
}

// Mobile services submenu toggle
function toggleMobServices(btn) {
  var list = document.getElementById('mob-services-list');
  var arrowBtn = btn.querySelector('.mob-arrow-btn');
  var isOpen = list.classList.contains('open');
  list.classList.toggle('open', !isOpen);
  btn.classList.toggle('open', !isOpen);
  if (arrowBtn) arrowBtn.setAttribute('aria-expanded', (!isOpen).toString());
}

// Nav shadow on scroll
window.addEventListener('scroll', function() {
  var nav = document.getElementById('site-nav');
  if (nav) nav.style.boxShadow = window.pageYOffset > 40 ? '0 4px 20px rgba(0,0,0,0.1)' : '0 2px 12px rgba(0,0,0,0.06)';
}, { passive: true });

</div><!-- .page-wrap -->
</main><!-- #main-content -->

<footer role="contentinfo">
  <div class="wrap">
    <div class="footer-grid">

      <!-- COL 1: About -->
      <div class="footer-about">
        <?php if (has_custom_logo()): the_custom_logo();
        else: ?><img src="<?php echo get_template_directory_uri(); ?>/logo.png" alt="<?php bloginfo('name'); ?>"><?php endif; ?>
        <p class="footer-desc">Full-service digital marketing agency based in Thrissur, Kerala, India. Serving clients in Oman, UAE, Bahrain and worldwide. Specialising in SEO, social media marketing, web design and AI marketing automation. Est. 2020.</p>
        <p class="footer-desc" style="margin-top:-6px">Founded by Sajeesh Vaderiyattil Sahadevan, Qrenzy combines 18+ years of hands-on experience with AI-powered strategies to deliver real, measurable growth for businesses across India and the Gulf. From startups to established brands — we treat every client's goal as our own.</p>
        <p class="footer-desc" style="margin-top:-6px">We are proud to be recognized on Clutch as one of Kerala's top digital marketing agencies.</p>
        <div class="social-row">
          <a href="<?php echo esc_url(get_theme_mod('facebook_url','https://facebook.com/qrenzydigitalsolutions')); ?>" class="soc-btn" rel="noopener" aria-label="Follow Qrenzy on Facebook" target="_blank">
            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.235 2.686.235v2.97h-1.513c-1.491 0-1.956.93-1.956 1.887v2.267h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z"/></svg>
          </a>
          <a href="<?php echo esc_url(get_theme_mod('instagram_url','https://instagram.com/qrenzydigitalsolutions')); ?>" class="soc-btn" rel="noopener" aria-label="Follow Qrenzy on Instagram" target="_blank">
            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
          </a>
          <a href="<?php echo esc_url(get_theme_mod('linkedin_url','https://linkedin.com/company/qrenzy-digital-solutions')); ?>" class="soc-btn" rel="noopener" aria-label="Connect with Qrenzy on LinkedIn" target="_blank">
            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
          </a>
          <a href="<?php echo esc_url(get_theme_mod('youtube_url','https://youtube.com/@qrenzydigitalsolutions')); ?>" class="soc-btn" rel="noopener" aria-label="Subscribe to Qrenzy on YouTube" target="_blank">
            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
          </a>
          <a href="<?php echo esc_url(get_theme_mod('clutch_url','https://clutch.co/profile/qrenzy-digital-solutions')); ?>" class="soc-btn" rel="noopener" aria-label="View Qrenzy on Clutch" target="_blank">
            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 0C5.372 0 0 5.372 0 12s5.372 12 12 12 12-5.372 12-12S18.628 0 12 0zm0 3.6a8.4 8.4 0 110 16.8A8.4 8.4 0 0112 3.6zm0 2.4a6 6 0 100 12A6 6 0 0012 6zm1.8 2.1a3.6 3.6 0 11-3.327 4.95H9.6a2.4 2.4 0 100-1.2h.873A3.601 3.601 0 0113.8 8.1zm0 1.2a2.4 2.4 0 100 4.8 2.4 2.4 0 000-4.8z"/></svg>
          </a>
        </div>
      </div>

      <!-- COL 2: Services -->
      <div class="footer-col">
        <h3 class="footer-col-heading">Services</h3>
        <ul>
          <li><a href="<?php echo home_url('/search-engine-optimization/'); ?>">Search Engine Optimization</a></li>
          <li><a href="<?php echo home_url('/web-designing/'); ?>">Web Design &amp; Development</a></li>
          <li><a href="<?php echo home_url('/social-media-marketing/'); ?>">Social Media Marketing</a></li>
          <li><a href="<?php echo home_url('/pay-per-click/'); ?>">Performance Marketing</a></li>
          <li><a href="<?php echo home_url('/ai-marketing-automation/'); ?>">AI Marketing Automation</a></li>
          <li><a href="<?php echo home_url('/photography-videography/'); ?>">Photography &amp; Videography</a></li>
          <li><a href="<?php echo home_url('/graphic-designing/'); ?>">Graphic Design</a></li>
          <li><a href="<?php echo home_url('/custom-software/'); ?>">Software Solutions</a></li>
        </ul>
      </div>

      <!-- COL 3: Company -->
      <div class="footer-col">
        <h3 class="footer-col-heading">Company</h3>
        <ul>
          <li><a href="<?php echo home_url('/about/'); ?>">About Us</a></li>
          <li><a href="<?php echo home_url('/portfolio/'); ?>">Our Work</a></li>
          <li><a href="<?php echo get_permalink(get_option('page_for_posts')); ?>">Blog</a></li>
          <li><a href="<?php echo home_url('/free-seo-audit/'); ?>">Free SEO Audit</a></li>
          <li><a href="https://demo.qrenzy.com/websites-for/">Website Demos by Industry</a></li>
          <li><a href="<?php echo home_url('/contact/'); ?>">Contact Us</a></li>
          <li style="border-top:1px solid rgba(255,255,255,0.08);margin-top:8px;padding-top:8px"><a href="<?php echo home_url('/privacy-policy/'); ?>">Privacy Policy</a></li>
          <li><a href="<?php echo home_url('/terms-and-conditions/'); ?>">Terms &amp; Conditions</a></li>
          <li><a href="<?php echo home_url('/affiliate-disclosure/'); ?>">Affiliate Disclosure</a></li>
        </ul>
      </div>

      <!-- COL 4: Contact + Map -->
      <div class="footer-col footer-col-contact">
        <h3 class="footer-col-heading">Contact</h3>
        <ul style="margin-bottom:16px">
          <li><a href="tel:+919905700600">📞 +91 99057 00600</a></li>
          <li><a href="mailto:info@qrenzy.com">✉️ info@qrenzy.com</a></li>
          <li><a href="<?php echo home_url('/contact/'); ?>">📋 Send a Message</a></li>
          <li><a href="https://api.whatsapp.com/send?phone=919905700600" rel="noopener" target="_blank">💬 WhatsApp Chat</a></li>
        </ul>
        <div class="footer-address">
          <p><strong>Qrenzy Digital Solutions</strong><br>
          5/427, Sankarmandam,<br>
          Mundur P.O, Thrissur,<br>
          Kerala, India — 680541</p>
        </div>
      </div>

    </div><!-- .footer-grid -->

    <div class="footer-bottom">
      <span>&copy; <?php echo date('Y'); ?> <a href="<?php echo home_url(); ?>" style="color:#ccc;text-decoration:underline">Qrenzy Digital Solutions</a>. All rights reserved. Thrissur, Kerala, India &bull; Oman &bull; UAE &bull; Worldwide.</span>
      <div class="footer-legal">
        <a href="<?php echo home_url('/privacy-policy/'); ?>">Privacy Policy</a>
        <a href="<?php echo home_url('/terms-and-conditions/'); ?>">Terms</a>
        <a href="<?php echo home_url('/affiliate-disclosure/'); ?>">Affiliate Disclosure</a>
      </div>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>

<?php
/**
 * Single Portfolio Item Template
 */
get_header();

$post_id  = get_the_ID();
$client   = get_post_meta($post_id,'_portfolio_client',true);
$service  = get_post_meta($post_id,'_portfolio_service',true);
$result   = get_post_meta($post_id,'_portfolio_result',true);
$live_url = get_post_meta($post_id,'_portfolio_live_url',true);
$duration = get_post_meta($post_id,'_portfolio_duration',true);
$country  = get_post_meta($post_id,'_portfolio_country',true);

$service_colors = [
  'Search Engine Optimization'  => '#E31E24',
  'Web Design & Development'    => '#1565C0',
  'Social Media Marketing'      => '#7C3AED',
  'Performance Marketing'       => '#D97706',
  'AI Marketing Automation'     => '#0891B2',
  'Photography & Videography'   => '#BE185D',
  'Graphic Design'              => '#059669',
  'Software Solutions'          => '#4F46E5',
];
$color = $service_colors[$service] ?? '#E31E24';

$service_icons = [
  'Search Engine Optimization'  => '🔍',
  'Web Design & Development'    => '🌐',
  'Social Media Marketing'      => '📱',
  'Performance Marketing'       => '🎯',
  'AI Marketing Automation'     => '🤖',
  'Photography & Videography'   => '📸',
  'Graphic Design'              => '🎨',
  'Software Solutions'          => '💻',
];
$icon = $service_icons[$service] ?? '🏆';
?>

<!-- BREADCRUMB -->
<div class="breadcrumb"><div class="wrap"><div class="breadcrumb-inner"><ol class="bc-list">
  <li><a href="<?php echo home_url(); ?>">Home</a></li>
  <li class="bc-sep">/</li>
  <li><a href="<?php echo home_url('/portfolio/'); ?>">Portfolio</a></li>
  <li class="bc-sep">/</li>
  <li><?php echo esc_html($client ?: get_the_title()); ?></li>
</ol></div></div></div>

<!-- HERO -->
<section style="padding:12px 0 0;background:#fff">
  <div class="wrap">

    <!-- Service badge + title -->
    <div style="margin-bottom:24px">
      <?php if($service): ?>
      <div style="display:inline-flex;align-items:center;gap:6px;background:<?php echo $color; ?>15;color:<?php echo $color; ?>;border:1px solid <?php echo $color; ?>30;font-size:12px;font-weight:700;padding:5px 14px;border-radius:100px;margin-bottom:14px;letter-spacing:0.06em;text-transform:uppercase">
        <?php echo $icon; ?> <?php echo esc_html($service); ?>
      </div>
      <?php endif; ?>
      <h1 style="font-size:clamp(26px,4vw,48px);font-weight:900;color:#0a0a0a;letter-spacing:-0.03em;line-height:1.1;margin-bottom:12px"><?php the_title(); ?></h1>
      <div style="display:flex;gap:16px;flex-wrap:wrap;align-items:center">
        <?php if($client): ?><span style="font-size:14px;color:#555;font-weight:600">👤 <?php echo esc_html($client); ?></span><?php endif; ?>
        <?php if($country): ?><span style="font-size:14px;color:#555;font-weight:600">📍 <?php echo esc_html($country); ?></span><?php endif; ?>
        <?php if($duration): ?><span style="font-size:14px;color:#555;font-weight:600">📅 <?php echo esc_html($duration); ?></span><?php endif; ?>
      </div>
    </div>

    <!-- Featured image — full width hero -->
    <?php if(has_post_thumbnail()): ?>
    <div style="border-radius:24px;overflow:hidden;margin-bottom:0;aspect-ratio:16/7;border:1px solid #e8e8e4">
      <?php the_post_thumbnail('full',['style'=>'width:100%;height:100%;object-fit:cover;display:block;','alt'=>esc_attr(get_the_title().' — Qrenzy Digital Solutions Portfolio')]); ?>
    </div>
    <?php endif; ?>

  </div>
</section>

<!-- MAIN CONTENT -->
<section style="padding:56px 0 80px;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 340px;gap:56px;align-items:start">

      <!-- LEFT: Post Content -->
      <div class="portfolio-content" style="font-size:15px;color:#444;line-height:1.85">
        <?php the_content(); ?>
      </div>

      <!-- RIGHT: Project Details Sidebar -->
      <div style="position:sticky;top:100px">

        <!-- Key Result -->
        <?php if($result): ?>
        <div style="background:<?php echo $color; ?>;border-radius:20px;padding:24px;margin-bottom:16px;color:#fff">
          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;opacity:0.8;margin-bottom:8px">📈 Key Result</div>
          <div style="font-size:16px;font-weight:800;line-height:1.4"><?php echo esc_html($result); ?></div>
        </div>
        <?php endif; ?>

        <!-- Project Details -->
        <div style="background:#f8f8f6;border:1px solid #e8e8e4;border-radius:20px;padding:24px;margin-bottom:16px">
          <div style="font-size:12px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:16px">Project Details</div>
          <?php if($client): ?>
          <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #e8e8e4">
            <span style="font-size:13px;color:#888;font-weight:600">Client</span>
            <span style="font-size:13px;color:#0a0a0a;font-weight:700"><?php echo esc_html($client); ?></span>
          </div>
          <?php endif; ?>
          <?php if($service): ?>
          <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #e8e8e4">
            <span style="font-size:13px;color:#888;font-weight:600">Service</span>
            <span style="font-size:13px;color:<?php echo $color; ?>;font-weight:700"><?php echo esc_html($service); ?></span>
          </div>
          <?php endif; ?>
          <?php if($country): ?>
          <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #e8e8e4">
            <span style="font-size:13px;color:#888;font-weight:600">Market</span>
            <span style="font-size:13px;color:#0a0a0a;font-weight:700"><?php echo esc_html($country); ?></span>
          </div>
          <?php endif; ?>
          <?php if($duration): ?>
          <div style="display:flex;justify-content:space-between;padding:10px 0">
            <span style="font-size:13px;color:#888;font-weight:600">Duration</span>
            <span style="font-size:13px;color:#0a0a0a;font-weight:700"><?php echo esc_html($duration); ?></span>
          </div>
          <?php endif; ?>
        </div>

        <!-- CTAs -->
        <div style="display:flex;flex-direction:column;gap:10px">
          <?php if($live_url): ?>
          <a href="<?php echo esc_url($live_url); ?>" style="display:block;text-align:center;background:<?php echo $color; ?>;color:#fff;padding:13px 20px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none" rel="noopener" target="_blank">🔗 View Live Site →</a>
          <?php endif; ?>
          <a href="https://api.whatsapp.com/send?phone=919905700600&text=Hi+Sajeesh,+I+saw+your+<?php echo urlencode($client ?: 'portfolio'); ?>+project+and+would+like+a+similar+one" style="display:block;text-align:center;background:#25D366;color:#fff;padding:13px 20px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none" rel="noopener" target="_blank">💬 Get a Similar Project</a>
          <a href="<?php echo home_url('/free-seo-audit/'); ?>" style="display:block;text-align:center;background:#f8f8f6;color:#0a0a0a;padding:13px 20px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none;border:1px solid #e8e8e4">🔍 Free SEO Audit</a>
        </div>

      </div>
    </div>
  </div>
</section>

<!-- OTHER PROJECTS -->
<?php
$other_projects = new WP_Query([
  'post_type'      => 'portfolio',
  'posts_per_page' => 3,
  'post__not_in'   => [$post_id],
  'orderby'        => 'rand',
  'post_status'    => 'publish',
]);
if($other_projects->have_posts()):
?>
<section style="padding:56px 0;background:#f8f8f6;border-top:1px solid #e8e8e4">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:32px">
      <h2 style="font-size:24px;font-weight:900;color:#0a0a0a">More Projects</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px">
      <?php while($other_projects->have_posts()): $other_projects->the_post();
        $oc = get_post_meta(get_the_ID(),'_portfolio_service',true);
        $or = get_post_meta(get_the_ID(),'_portfolio_result',true);
        $ocl = get_post_meta(get_the_ID(),'_portfolio_client',true);
        $oclr = $service_colors[$oc] ?? '#E31E24';
      ?>
      <a href="<?php the_permalink(); ?>" style="display:block;background:#fff;border-radius:20px;overflow:hidden;border:1px solid #e8e8e4;text-decoration:none;transition:box-shadow 0.2s" onmouseover="this.style.boxShadow='0 12px 40px rgba(0,0,0,0.08)'" onmouseout="this.style.boxShadow='none'">
        <?php if(has_post_thumbnail()): ?>
        <div style="aspect-ratio:16/9;overflow:hidden"><?php the_post_thumbnail('qrenzy-thumb',['style'=>'width:100%;height:100%;object-fit:cover;display:block;']); ?></div>
        <?php else: ?>
        <div style="aspect-ratio:16/9;background:<?php echo $oclr; ?>15;display:flex;align-items:center;justify-content:center;font-size:36px"><?php echo $service_icons[$oc] ?? '🏆'; ?></div>
        <?php endif; ?>
        <div style="padding:16px">
          <div style="font-size:11px;font-weight:700;color:<?php echo $oclr; ?>;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:6px"><?php echo esc_html($oc); ?></div>
          <h3 style="font-size:14px;font-weight:800;color:#0a0a0a;margin-bottom:4px;line-height:1.3"><?php the_title(); ?></h3>
          <?php if($ocl): ?><p style="font-size:12px;color:#888;margin:0"><?php echo esc_html($ocl); ?></p><?php endif; ?>
        </div>
      </a>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
    <div style="text-align:center;margin-top:28px">
      <a href="<?php echo home_url('/portfolio/'); ?>" style="display:inline-flex;align-items:center;gap:8px;background:#0a0a0a;color:#fff;padding:12px 24px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none">← All Projects</a>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- CTA -->
<section class="cta-band"><div class="wrap"><div class="cta-inner">
  <h2>Like This Project?<br>Let's Do Yours.</h2>
  <p>Start with a free consultation — we'll show you exactly what we can do for your business.</p>
  <div class="cta-btns">
    <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-white">🔍 Free SEO Audit</a>
    <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-outline-white" rel="noopener" target="_blank">💬 WhatsApp Us</a>
  </div>
</div></div></section>

<style>
/* Portfolio content typography */
.portfolio-content h2 { font-size:22px;font-weight:900;color:#0a0a0a;margin:36px 0 12px;letter-spacing:-0.02em; }
.portfolio-content h3 { font-size:17px;font-weight:800;color:#0a0a0a;margin:28px 0 10px; }
.portfolio-content p  { margin-bottom:16px; }
.portfolio-content ul,.portfolio-content ol { padding-left:20px;margin-bottom:16px; }
.portfolio-content li { margin-bottom:8px; }
.portfolio-content table { width:100%;border-collapse:collapse;margin:24px 0;font-size:14px; }
.portfolio-content th { background:#f8f8f6;padding:10px 14px;text-align:left;font-weight:700;border:1px solid #e8e8e4; }
.portfolio-content td { padding:10px 14px;border:1px solid #e8e8e4;color:#444; }
.portfolio-content strong { color:#0a0a0a;font-weight:700; }
.portfolio-content blockquote { border-left:3px solid #E31E24;padding:16px 20px;background:#f8f8f6;border-radius:0 12px 12px 0;margin:24px 0;font-style:italic;color:#555; }
/* Responsive */
@media(max-width:900px){
  [style*="grid-template-columns:1fr 340px"]{grid-template-columns:1fr!important;}
  [style*="position:sticky"]{position:static!important;}
  [style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr 1fr!important;}
}
@media(max-width:600px){
  [style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr!important;}
}
</style>

<?php get_footer(); ?>

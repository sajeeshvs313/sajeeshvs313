<?php
/**
 * Template Name: Service Page
 */

// Reliable slug detection — works regardless of permalink structure
$slug = get_post_field('post_name', get_the_ID());

$services = [

'search-engine-optimization' => [
  'icon'=>'🔍','color'=>'#E31E24',
  'title'=>'Search Engine Optimization Services',
  'tagline'=>'Rank Higher. Get Found. Convert Traffic.',
  'badge'=>"Kerala's #1 SEO Agency",
  'hero_desc'=>'Full-spectrum SEO services that get your website ranking on Page 1 of Google — and keep it there. From technical audits to content strategy, we handle everything.',
  'stats'=>[['340%','Avg Traffic Growth'],['6 Mo','To Page 1 Results'],['500+','Keywords Ranked'],['200+','Clients Served']],
  'intro_body'=>[
    'Search Engine Optimization is the single highest-ROI digital marketing investment most businesses can make. While paid advertising stops the moment your budget runs out, SEO builds a compounding asset — a website that generates consistent, free organic traffic month after month, year after year. Our SEO clients typically see a 700% return on their SEO investment over 12 months, as organic traffic replaces or supplements paid acquisition at a fraction of the ongoing cost.',
    'Qrenzy\'s SEO service covers the complete spectrum of modern search optimization. We start with a comprehensive technical audit that identifies every issue preventing Google from properly crawling and indexing your website — from page speed and Core Web Vitals to broken links, duplicate content and schema markup gaps. We then build a keyword strategy around the exact search queries your target customers use in India, Oman and UAE, and create high-quality content that ranks for those queries and converts visitors into leads.',
    'Our approach goes beyond traditional Google optimization. In 2025 and beyond, appearing in AI-generated answers on ChatGPT, Perplexity, Google AI Overviews and Gemini has become equally important. We optimize your content specifically for AI citation — through structured data, FAQ schemas, authoritative depth and the entity-based content signals that AI search engines prioritize. Several of our clients now appear in AI-generated answers for their target keywords, driving a new source of zero-click brand awareness and referral traffic.',
  ],
  'who_for'=>[
    'title'=>'Who Our SEO Service Is For',
    'desc'=>'Our SEO service is built for businesses that want sustainable, long-term organic growth — not quick fixes that get penalized by the next Google update.',
    'list'=>[
      'Small and medium businesses in Kerala, Thrissur, Kochi, Calicut and Trivandrum seeking local Google visibility',
      'Businesses in Oman, UAE, Qatar and Bahrain competing for Gulf market search rankings in English and Arabic',
      'E-commerce stores looking to reduce paid ad dependency through organic product and category page rankings',
      'Service businesses (clinics, law firms, agencies, consultants) generating B2C or B2B leads through organic search',
      'New businesses that need to build domain authority and organic traffic from the ground up systematically',
      'Established businesses whose rankings have dropped due to algorithm updates and need recovery strategies',
    ],
  ],
  'benefits'=>[
    ['📈','Sustainable Traffic Growth','Unlike paid ads, SEO traffic compounds over time. Rankings built today generate traffic for months and years without ongoing spend.'],
    ['🎯','High-Intent Visitors','Organic search visitors are actively looking for what you offer — conversion rates from organic traffic consistently outperform other channels.'],
    ['🤖','AI Search Visibility','We optimize for Google AI Overviews, ChatGPT and Perplexity — ensuring your brand appears in the AI-generated answers your customers read.'],
    ['🌍','India & Gulf Coverage','Dedicated keyword strategies for India and Gulf markets, bilingual content where needed, and link building from region-specific authoritative sources.'],
    ['🔧','Technical Excellence','Every technical SEO issue fixed — page speed, Core Web Vitals, mobile optimization, schema and crawlability — building the foundation rankings require.'],
    ['📊','Full Transparency','Monthly reports showing every keyword position, traffic trend and ROI metric. You always know exactly what your investment is delivering.'],
  ],
  'what_is'=>[
    'heading' => 'What Is Search Engine Optimization (SEO)?',
    'answer'  => 'Search Engine Optimization (SEO) is the process of improving a website\'s visibility in Google and other search engines so it appears higher in unpaid (organic) search results when potential customers search for relevant keywords. SEO covers three main areas: technical SEO (ensuring search engines can crawl and understand your site), on-page SEO (optimizing content, headings and meta tags for target keywords), and off-page SEO (building authority through backlinks and brand mentions). For businesses in India and the Gulf, effective SEO generates a steady stream of high-intent visitors who are actively searching for your products or services — without paying for each click.',
  ],
  'what_title'=>'Everything Included in Our SEO Service',
  'services_list'=>[
    ['🔧','Technical SEO Audit','Full crawl identifying speed issues, broken links, duplicate content, crawl errors and Core Web Vitals problems.'],
    ['🔑','Keyword Research','High-intent keywords specific to India, Oman and UAE markets — what your customers actually search for.'],
    ['✍️','Content Writing','SEO-optimised blog posts, service pages and landing pages. Content that ranks AND converts.'],
    ['🔗','Link Building','Quality backlinks from Indian and Gulf market websites, guest posts, directories and Web 2.0 blogs.'],
    ['📍','Local SEO','Google Business Profile optimisation and local citations for Thrissur, Muscat, Dubai and beyond.'],
    ['📊','Monthly Reporting','Detailed monthly reports showing keyword rankings, organic traffic, backlinks and ROI.'],
  ],
  'problem_solution'=>[
    'problem' => 'Your website is invisible on Google. Competitors rank higher, get more traffic and win customers you should be getting — while your site sits on Page 4 where nobody looks.',
    'solution' => 'We run a full technical SEO audit, fix every issue Google penalises you for, build keyword-rich content your audience searches for, and earn quality backlinks that push your pages to Page 1 — and keep them there.',
    'included' => ['Technical SEO audit & fixes','Keyword research for India & Gulf markets','SEO-optimised content writing','Link building from authoritative sources','Google Business Profile optimisation','Monthly ranking & traffic reports'],
  ],
  'results'=>[['340%','Traffic Growth'],['Page 1','Google Rankings'],['60%','More Leads'],['ROI','In 90 Days']],
  'process'=>[
    ['Week 1-2','Full Audit','Technical SEO audit, competitor analysis and keyword research for your market.'],
    ['Week 3-4','Strategy','90-day SEO roadmap with prioritised fixes, content plan and link building targets.'],
    ['Month 2-3','Execution','On-page fixes, content publishing, link building and Google Search Console setup.'],
    ['Month 4+','Scale','Monitor rankings, optimise content, scale what works and report results monthly.'],
  ],
  'faqs'=>[
    ['How long does SEO take to show results?','Most clients see measurable ranking improvements within 60–90 days of starting SEO. Significant organic traffic growth typically happens between months 3–6. Google Maps visibility usually improves faster — within 4–8 weeks of GBP optimization. The timeline depends on your current website health, competition level and how consistently SEO is executed. We provide monthly progress reports from week one so you always have visibility on movement.'],
    ['Do you provide SEO services for Oman and UAE?','Yes — Gulf market SEO is one of our core specializations. We build bilingual keyword strategies covering both English and Arabic search queries, create content optimized for Gulf audiences and build backlinks from Gulf-region authoritative websites. We have active SEO campaigns in Oman, UAE and Qatar and understand the specific competitive landscape and search behaviour patterns of each Gulf market.'],
    ['How is Qrenzy\'s SEO service different from other agencies?','Three key differences. First, we optimize for AI search as well as traditional Google — ensuring your content appears in ChatGPT, Perplexity and Google AI Overviews, not just the traditional blue-link results. Second, we create all content in-house with human editorial review — no AI-only content that lacks depth or authenticity. Third, we operate across both India and the Gulf simultaneously, giving us market-specific expertise that most agencies serving only one market cannot match.'],
    ['Do you write all the content, or do I need to provide it?','We write everything. All blog posts, service page content, landing pages and GBP descriptions are created by our team. We conduct thorough research on your industry, competitors and target audience before writing. All content is reviewed for accuracy, SEO optimization and alignment with your brand voice. You review and approve before publication. You own all content created.'],
    ['What does an SEO audit include and how long does it take?','Our free SEO audit covers technical health (crawlability, page speed, Core Web Vitals, mobile optimization), on-page optimization (title tags, meta descriptions, heading structure, content gaps), backlink profile analysis, competitor ranking comparison and keyword opportunity identification. The audit report takes 48 hours to complete and is delivered as a detailed document with prioritized recommendations. It is completely free with no obligation.'],
  ],
],

'web-designing' => [
  'icon'=>'🌐','color'=>'#1565C0',
  'title'=>'Web Design & Development',
  'tagline'=>'Fast. Beautiful. Built to Convert.',
  'badge'=>'Custom WordPress Experts',
  'hero_desc'=>'Custom WordPress websites designed for performance, SEO and conversions. Mobile-first, lightning fast, and built to turn visitors into paying customers.',
  'stats'=>[['<2s','Page Load Time'],['100%','Mobile Responsive'],['95+','Avg SEO Score'],['50+','Sites Delivered']],
  'intro_body'=>[
    'Your website is the foundation of your entire digital presence. Every other digital marketing activity — SEO, social media, paid advertising — ultimately drives traffic to your website. If that website is slow, hard to navigate, looks outdated or fails to clearly communicate your value, you are losing customers at the last mile. All the marketing investment in the world cannot compensate for a website that does not convert visitors into enquiries.',
    'Qrenzy builds custom WordPress websites that are engineered for three things simultaneously: speed, search engine visibility and conversion. We do not use pre-built templates — every website is designed from scratch around your brand, your audience and your business objectives. Our development process ensures every site we deliver scores 90+ on Google PageSpeed, is fully mobile-optimized (since over 70% of Indian web traffic comes from mobile), and has technical SEO built in from day one rather than added as an afterthought.',
    'We have built websites for businesses across India and the Gulf — from simple 5-page service websites for Thrissur small businesses to multi-location corporate sites for Gulf-based companies. Every project follows the same rigorous process: discovery, wireframing, design approval, development, SEO setup, testing and launch — with your input at every stage and no surprises on timeline or budget.',
  ],
  'who_for'=>[
    'title'=>'Who Our Web Design Service Is For',
    'desc'=>'We build websites for businesses that understand their website is a business asset — not just an online brochure.',
    'list'=>[
      'New businesses in Kerala, Oman or UAE that need a professional website built right the first time',
      'Established businesses with outdated websites that are slow, not mobile-friendly or generating no leads',
      'Businesses whose current website scores poorly on Google PageSpeed and is being penalized in search rankings',
      'E-commerce businesses needing a WooCommerce store with Indian or Gulf payment gateway integration',
      'Service businesses that need landing pages optimized for Google Ads and lead generation',
      'Companies wanting a bilingual (English/Arabic) website for Gulf market audiences',
    ],
  ],
  'benefits'=>[
    ['⚡','PageSpeed 90+ Guaranteed','Every website we build is performance-optimized — compressed images, lazy loading, caching and CDN configuration ensure sub-2-second load times.'],
    ['📱','Mobile-First Design','Designed for mobile screens first. With 70%+ of Indian web traffic coming from mobile devices, mobile experience is not optional — it is primary.'],
    ['🔍','SEO Built In','Schema markup, clean URL structure, optimized meta tags, XML sitemap and robots.txt configured before launch. SEO is architectural, not an add-on.'],
    ['🔒','Security & Reliability','SSL certificate, Wordfence security, daily backups and uptime monitoring. Your website is protected and always available.'],
    ['🛒','E-commerce Ready','WooCommerce integration with Razorpay, PayPal and Stripe. Product management, inventory and order tracking built for Indian and Gulf markets.'],
    ['📚','Training Included','Full WordPress training so you can update content, add blog posts and manage your site confidently without needing a developer for routine changes.'],
  ],
  'what_is'=>[
    'heading' => 'What Is Web Design & Development?',
    'answer'  => 'Web design and development is the process of planning, creating and building websites — combining visual design (layout, typography, colour, imagery) with technical development (coding, database integration, performance optimization) to produce a website that is fast, functional and effective for its business purpose. A professionally developed website serves as the foundation of all digital marketing: SEO drives traffic to it, social media directs followers to it, and paid ads send clicks to it. If the website is slow, hard to navigate or unconvincing, all that marketing investment is wasted. Modern web development for businesses in India and the Gulf requires mobile-first design (70%+ of web traffic is mobile), sub-2-second load times and built-in SEO architecture.',
  ],
  'what_title'=>"What's Included in Every Website",
  'services_list'=>[
    ['🎨','Custom Design','Unique, brand-aligned design — not a template. Every website designed from scratch.'],
    ['⚡','Speed Optimised','PageSpeed 90+ guaranteed. Image compression, caching, CDN and Core Web Vitals optimisation.'],
    ['📱','Mobile First','Designed for mobile first. 70% of your visitors are on mobile — we design for them.'],
    ['🔍','SEO Ready','Built with SEO best practices — schema, clean URLs, sitemap, robots.txt and RankMath.'],
    ['🛒','WooCommerce','E-commerce with product management, Razorpay/PayPal/Stripe and order management.'],
    ['🔒','Security & Maintenance','SSL, Wordfence, daily backups and monthly maintenance included.'],
  ],
  'problem_solution'=>[
    'problem' => 'Your current website is slow, looks outdated on mobile, and fails to convert visitors. Every second of load delay and every confusing page is costing you leads you never know about.',
    'solution' => 'We build custom WordPress websites from scratch — fast-loading, mobile-first, SEO-ready and designed specifically to convert visitors into enquiries. No templates. No shortcuts. PageSpeed 90+ guaranteed.',
    'included' => ['Custom WordPress design & development','Mobile-first responsive layout','PageSpeed 90+ optimisation','SEO-ready structure built in','WooCommerce & payment integration','SSL, security & maintenance setup'],
  ],
  'results'=>[['<2s','Load Speed'],['3x','More Leads'],['90+','SEO Score'],['Zero','Downtime']],
  'process'=>[
    ['Day 1-3','Discovery','Understand goals, competitors and collect brand assets.'],
    ['Day 4-7','Design','Wireframes and mockups presented. Two rounds of revisions included.'],
    ['Week 2-3','Development','Full WordPress build, plugins, mobile optimisation and speed tuning.'],
    ['Week 4','Launch','Testing, SEO setup, Analytics, Search Console and go-live.'],
  ],
  'faqs'=>[
    ['How long does it take to build a website?','A standard business website typically takes 3–4 weeks from project kickoff to launch. E-commerce sites with significant product catalogues take 4–6 weeks. Timeline depends on how quickly you can provide content, images and feedback at each stage. We provide a detailed project timeline at kickoff and stick to it — late delivery has never happened on our projects.'],
    ['Can you redesign my existing website without losing SEO?','Yes — we handle redesigns carefully to preserve and improve your existing SEO. This includes maintaining your current URL structure where possible, implementing proper 301 redirects for any changed URLs, migrating all existing content and meta data, and conducting a full technical SEO audit post-launch to ensure no rankings are lost in the transition.'],
    ['Is hosting included in the price?','Hosting is not included in the website build price but we help you choose, set up and configure the right hosting for your needs. For Indian clients, we typically recommend SiteGround or Cloudways. For Gulf-based clients, we configure hosting with a CDN ensuring fast load times across Oman, UAE and Qatar. Monthly hosting typically costs ₹500–2,000 per month depending on your traffic volume.'],
    ['Can I update the website content myself after launch?','Yes — every website we build uses WordPress, the world\'s most user-friendly content management system. We provide a training session covering how to update pages, add blog posts, change images and manage basic settings. You will never need to contact a developer for routine content updates. For design changes or new functionality, our maintenance retainers provide ongoing developer access.'],
    ['Do you build websites in Arabic for Gulf clients?','Yes — we build fully bilingual English/Arabic websites for Gulf-based clients. This includes right-to-left (RTL) layout support for Arabic content, bilingual navigation, language switcher and Arabic SEO optimization. Bilingual websites are particularly important for businesses in Oman, UAE and Qatar that serve both Arabic-speaking national audiences and English-speaking expatriate communities.'],
  ],
],

'local-seo' => [
  'icon'=>'📍','color'=>'#16A34A',
  'title'=>'Local SEO & Google Business Profile Optimisation',
  'tagline'=>'Dominate Local Search. Own Your Area.',
  'badge'=>'Google Maps & Local SEO Experts',
  'hero_desc'=>'Get your business to the top of Google Maps and local search results. We optimise your Google Business Profile, build local citations and target location-specific keywords across India and the Gulf.',
  'stats'=>[['3×','More Calls & Directions'],['Top 3','Google Maps Pack'],['200+','Local Clients'],['90 Days','To Visible Results']],
  'intro_body'=>[
    'Local SEO is the most impactful digital marketing investment for any business that serves customers in a specific geographic area. When someone searches "digital marketing agency in Thrissur" or "best restaurant near me" or "dentist in Muscat", they are a high-intent buyer ready to make a decision quickly. The businesses that appear in the Google Maps Local Pack — those top 3 results with the map — capture the majority of these clicks. If your business is not in that pack, your competitors are getting your customers.',
    'The Google Maps Local Pack is driven by a different algorithm than traditional organic search. It prioritizes three factors: relevance (how well your business matches what was searched), proximity (how close you are to the searcher) and prominence (how well-known and trusted your business appears online). Google Business Profile completeness, review volume and velocity, NAP consistency across directories and local backlinks all feed into prominence — and prominence is what separates the businesses in the Local Pack from those on page 3.',
    'Qrenzy has helped 200+ businesses across India and the Gulf improve their local search visibility. We have moved businesses from completely invisible on Google Maps to the top 3 in their area within 8–12 weeks. Our local SEO methodology is systematic and proven — we do not rely on shortcuts that get penalized, but build genuine local authority that sustains rankings long-term.',
  ],
  'who_for'=>[
    'title'=>'Who Local SEO Is For',
    'desc'=>'Local SEO is essential for any business that wants to be found by customers searching in their specific city, area or neighbourhood.',
    'list'=>[
      'Restaurants, cafes and F&B businesses wanting to appear in "restaurants near me" and city-specific food searches',
      'Healthcare providers — clinics, hospitals, dental practices, physiotherapy centres — competing for patient acquisition',
      'Retail stores in Thrissur, Kochi, Calicut, Muscat or Dubai wanting more footfall from local Google searches',
      'Service businesses — plumbers, electricians, lawyers, accountants — receiving calls from local customers',
      'Real estate agents and developers targeting city-specific property search queries',
      'Multi-location businesses needing separate GBP optimization and local ranking for each location',
    ],
  ],
  'benefits'=>[
    ['📍','Google Maps Top 3','Appear in the Local Pack — the 3 businesses that appear at the top of Google Maps results, capturing 70%+ of local search clicks.'],
    ['📞','More Calls & Directions','Businesses in the Local Pack receive 3× more calls and direction requests than those outside it. Local SEO directly drives physical footfall.'],
    ['⭐','Review Management','Systematic review generation and professional response management builds the social proof that converts searchers into customers.'],
    ['🗺️','50+ Directory Listings','Consistent NAP across 50+ Indian and Gulf directories builds the citation authority Google uses to rank local businesses.'],
    ['🌍','India & Gulf Coverage','Local SEO expertise across Thrissur, Kochi, Calicut, Trivandrum, Muscat, Dubai, Doha and Bahrain — bilingual where needed.'],
    ['📊','Weekly Rank Tracking','Weekly reports showing your Google Maps position and organic local rankings for all target keywords in your market.'],
  ],
  'what_is'=>[
    'heading' => 'What Is Local SEO?',
    'answer'  => 'Local SEO is the practice of optimizing a business\'s online presence to appear in search results when people nearby search for local products or services — particularly in Google Maps and the Google Local Pack (the 3 map results that appear above organic search results). Unlike traditional SEO which targets broad national or global rankings, Local SEO focuses on location-specific searches such as "digital marketing agency in Thrissur" or "best restaurant near me." Local SEO includes optimizing your Google Business Profile, building consistent business listings (citations) across directories, generating and managing Google reviews, and creating location-specific website content. For businesses with a physical location or serving a specific geographic area, Local SEO is typically the highest-ROI digital marketing investment available.',
  ],
  'what_title'=>'Everything Included in Our Local SEO Service',
  'services_list'=>[
    ['📋','Google Business Profile Setup & Optimisation','Complete GBP audit and optimisation — category selection, business description, photos, services, products, Q&A and weekly posts.'],
    ['🗺️','Google Maps Ranking','Proven strategies to get your business into the Google Maps Top 3 Pack for your target location and service keywords.'],
    ['📌','Local Citation Building','Consistent NAP (Name, Address, Phone) listings across 50+ Indian and Gulf business directories, maps and local platforms.'],
    ['🔑','Location-Based Keyword Strategy','Hyper-local keywords targeting your city, area and neighbourhood — "digital marketing agency Thrissur" not just Kerala.'],
    ['⭐','Review Generation & Management','Automated review request system, professional response templates and reputation management for Google and other platforms.'],
    ['📊','Local Rank Tracking','Weekly ranking reports showing your position in Google Maps and local organic results for all target keywords.'],
  ],
  'problem_solution'=>[
    'problem' => 'Local customers search for your service every day and choose your competitor instead — because they appear in the Google Maps Top 3 and you don\'t. Every missed Maps listing is a lost customer.',
    'solution' => 'We optimise your Google Business Profile completely, build consistent citations across 50+ directories, generate reviews systematically and target hyper-local keywords — pushing you into the Google Maps Top 3 where 70% of clicks go.',
    'included' => ['Google Business Profile full optimisation','Google Maps Top 3 ranking strategy','50+ local citation building','Location-specific keyword targeting','Review generation & management','Weekly Maps rank tracking reports'],
  ],
  'results'=>[['Top 3','Google Maps Pack'],['3×','More Leads'],['200+','Reviews Generated'],['90 Days','To Results']],
  'process'=>[
    ['Week 1','Audit & Setup','Full Google Business Profile audit, citation consistency check and local keyword research for your area.'],
    ['Week 2-3','Optimisation','Complete GBP optimisation, photo uploads, service listings, business description and first set of posts.'],
    ['Month 2','Citations & Reviews','Build local citations across 50+ directories and launch review generation campaign.'],
    ['Month 3+','Rank & Scale','Monitor Maps rankings weekly, optimise based on data, scale to additional locations if needed.'],
  ],
  'faqs'=>[
    ['What is Local SEO and why does my business need it?','Local SEO is the process of optimizing your online presence to appear in Google Maps and local search results when people nearby search for your products or services. It is essential for any business serving a specific geographic area. 46% of all Google searches have local intent — meaning nearly half of all searches are from people looking for something nearby. Without Local SEO, you are invisible to this massive, high-intent audience searching for exactly what you offer.'],
    ['How is Local SEO different from regular SEO?','Regular SEO targets broad keyword rankings in Google\'s organic results — the blue links below ads. Local SEO specifically targets the Google Maps Local Pack and location-based organic results. The ranking factors are different: regular SEO is primarily about content and backlinks, while Local SEO is primarily about Google Business Profile completeness, review volume, NAP consistency and local citations. A business can rank in the Local Pack even with a modest website if its GBP is well-optimized.'],
    ['How long does it take to get into the Google Maps Top 3?','Most businesses see measurable Google Maps ranking improvements within 4–8 weeks of starting Local SEO. Getting into the Top 3 Pack typically takes 8–16 weeks depending on competition in your area. Less competitive local markets (smaller cities, niche services) see results faster. Highly competitive categories in major cities may take 4–6 months. We provide weekly rank tracking reports so you can see position movement from week one.'],
    ['Do you manage Google Business Profile for Oman and UAE businesses?','Yes — we manage GBP and Local SEO for businesses across India, Oman, UAE, Bahrain and Qatar. For Gulf clients, we create bilingual English and Arabic GBP descriptions, service listings and weekly posts. We have managed GBP profiles for multi-location businesses across Muscat, Sohar, Nizwa, Dubai and Abu Dhabi simultaneously, optimizing each location profile individually for its specific city and competitive context.'],
    ['Can you help a business with multiple locations?','Yes — multi-location Local SEO is one of our specialties. We create and optimize separate Google Business Profiles for each location, build location-specific landing pages on your website, and track rankings separately for each location. Each location profile is optimized with its own city-specific keywords, local photos and targeted review generation strategy. We currently manage multi-location accounts for clients across Kerala and Oman.'],
  ],
],

'social-media-marketing' => [
  'icon'=>'📱','color'=>'#7C3AED',
  'title'=>'Social Media Marketing',
  'tagline'=>'Build Audience. Drive Engagement. Grow Brand.',
  'badge'=>'Instagram & Facebook Specialists',
  'hero_desc'=>'Strategic social media marketing across Instagram, Facebook, LinkedIn and YouTube. Content creation, community management and organic growth — all handled by our team.',
  'stats'=>[['2.8x','Follower Growth'],['90 Days','To Results'],['500+','Posts Created'],['4.2%','Avg Engagement']],
  'intro_body'=>[
    'Social media marketing is the practice of using social media platforms — Instagram, Facebook, LinkedIn, YouTube and others — to build brand awareness, engage your target audience, generate leads and drive business growth. For businesses in India and the Gulf, social media marketing is one of the most cost-effective digital channels available, reaching millions of potential customers where they spend hours of their day.',
    'But simply having social media accounts is not social media marketing. Posting inconsistently, using generic stock images, writing captions with no strategic thinking — this is what most businesses do, and it delivers no meaningful results. Effective social media marketing requires strategy, consistency, quality and a deep understanding of your specific audience\'s behaviour on each platform.',
    'Our social media strategies are built specifically for India and Gulf audiences. Content resonating with Kerala\'s Facebook community looks very different from content performing on Dubai\'s Instagram, which is different again from LinkedIn content targeting Oman\'s B2B professionals. Platform-specific strategy, culturally relevant content and audience-appropriate tone are not extras — they are the foundation of how we operate.',
  ],
  'who_for'=>[
    'title'=>'Who Our Social Media Marketing Service Is For',
    'desc'=>'Our social media service works for businesses that want to build genuine brand presence and generate real leads from social platforms.',
    'list'=>[
      'Retail and product businesses in Kerala and the Gulf wanting to grow Instagram and Facebook following and drive sales',
      'Restaurants, hotels and hospitality businesses needing consistent, high-quality content to attract customers',
      'B2B service businesses using LinkedIn to reach corporate decision-makers in India and Gulf markets',
      'Healthcare providers building patient trust through informative, compliant social media content',
      'New businesses launching brand presence from scratch and needing to build audience efficiently',
      'Existing businesses with stagnant social accounts wanting professional management and growth strategy',
    ],
  ],
  'benefits'=>[
    ['📅','Strategic Content Calendar','Monthly content planned in advance — no last-minute posting or missed days. Every piece serves your business goals.'],
    ['🎬','Reels & Video Priority','Short-form video (Reels, Stories) delivers 3–5× the reach of static posts. We produce Reels in every social media package.'],
    ['🎨','Brand-Consistent Design','All graphics match your brand identity — colours, fonts and style consistent across every post, every platform, every month.'],
    ['💬','Community Management','Every comment and DM responded to in your brand voice — building audience relationships that convert followers into customers.'],
    ['🌍','India & Gulf Expertise','Platform strategies calibrated for Kerala, Oman and UAE audience behaviour, cultural calendar and local engagement patterns.'],
    ['📊','Monthly Performance Reports','Follower growth, reach, engagement rate and top-performing content reported monthly with strategic recommendations.'],
  ],
  'what_is'=>[
    'heading' => 'What Is Social Media Marketing?',
    'answer'  => 'Social media marketing is the use of social media platforms — Instagram, Facebook, LinkedIn, YouTube, TikTok and others — as channels to build brand awareness, engage target audiences, generate leads and drive business growth. It encompasses both organic strategies (content creation, community management, audience building) and paid strategies (targeted advertising campaigns). Effective social media marketing for businesses in India and the Gulf requires platform-specific expertise: content that performs on Kerala\'s Facebook is different from what works on Dubai\'s Instagram, and both differ from LinkedIn content targeting Gulf B2B audiences. Social media marketing delivers results across the full marketing funnel — from awareness and reach at the top, to engagement and trust in the middle, to leads and sales conversions at the bottom.',
  ],
  'what_title'=>'Full Social Media Marketing Services',
  'services_list'=>[
    ['📅','Content Calendar','Monthly content calendar planned and approved in advance. Never scramble for what to post.'],
    ['🎬','Reels & Video','Short-form video (Reels, Stories, Shorts) — the highest reach format in 2026.'],
    ['🎨','Custom Graphics','Branded graphics, carousels, quote cards and promotional posts matching your brand identity.'],
    ['💬','Community Management','Respond to comments and DMs in your brand voice. Build genuine audience relationships.'],
    ['#️⃣','Hashtag Strategy','Research-backed hashtag strategy for maximum organic reach across every platform.'],
    ['📊','Monthly Analytics','Follower growth, reach, engagement rate and top-performing posts — reported monthly.'],
  ],
  'problem_solution'=>[
    'problem' => 'Your social media posts get low engagement, your follower count is stagnant and you have no idea what to post next. Hours spent on content that generates zero business results.',
    'solution' => 'We build a strategic content calendar, design branded graphics, produce Reels, manage your community and analyse performance monthly — turning your social media from a time drain into a consistent source of brand awareness and leads.',
    'included' => ['Monthly strategic content calendar','Branded graphics & Reel production','Community management & DM responses','Platform-specific strategy (India & Gulf)','Hashtag research & optimisation','Monthly analytics & performance reports'],
  ],
  'results'=>[['2.8x','Follower Growth'],['4.2%','Engagement Rate'],['60%','More DMs'],['3x','Brand Reach']],
  'process'=>[
    ['Week 1','Audit & Strategy','Full profile audit, competitor analysis and 90-day content strategy.'],
    ['Week 2','Brand Setup','Profile optimisation, bio, highlight covers and content template creation.'],
    ['Week 3','First Batch','First month content calendar created, designed and approved.'],
    ['Month 2+','Grow','Post daily, engage community, analyse and optimise monthly.'],
  ],
  'faqs'=>[
    ['How many posts per month do I get?','Our standard package includes 20 posts per month across Instagram and Facebook — a mix of Reels, carousels, static posts and Stories. Premium packages include 30+ posts per month and additional LinkedIn content. We create all content including captions, graphics and Reel scripts. A monthly content calendar is shared for your review and approval before anything goes live.'],
    ['Do you create all the content or do I need to provide anything?','We create all social media content — captions, graphics and Reel scripts. The only thing we typically ask from you is authentic brand photos for product-specific content. For businesses without professional photography, we can arrange a shoot as an add-on. All other content — graphics, templates, written content — is handled entirely by our team.'],
    ['Can you manage Gulf market social media accounts?','Yes — Gulf market social media is one of our specialties. We create bilingual English/Arabic content for Oman, UAE, Qatar and Bahrain clients. We understand Gulf platform preferences (Instagram, Snapchat for nationals), the Islamic calendar, cultural sensitivities and the visual aesthetic that resonates with Gulf consumers.'],
    ['How long before I see follower growth and better engagement?','Most accounts see measurable improvement in reach and engagement within 4–8 weeks of consistent quality content. Follower growth accelerates in months 2–3 as the algorithm starts promoting content to relevant audiences. Significant milestones (1K to 10K followers) typically take 4–6 months of consistent management. Accounts running paid social ads alongside organic content grow significantly faster.'],
    ['Is organic social media management separate from paid advertising?','Yes — organic social media management and paid social advertising are separate services. Our social media service covers organic content, community management and growth. Facebook Ads and Instagram Ads are managed through our Performance Marketing service. Many clients run both simultaneously for the fastest brand building and lead generation results.'],
  ],
],

'pay-per-click' => [
  'icon'=>'🎯','color'=>'#D97706',
  'title'=>'Performance Marketing Services',
  'tagline'=>'Every Rupee Invested. Every Lead Tracked.',
  'badge'=>'Google · Meta · TikTok · LinkedIn · Pinterest',
  'hero_desc'=>'Data-driven paid advertising across Google, Meta (Facebook & Instagram), TikTok, LinkedIn and Pinterest. Maximum ROI across every platform your audience uses.',
  'stats'=>[['4.8x','Average ROAS'],['40%','Lower CPC'],['₹2Cr+','Ad Spend Managed'],['200+','Campaigns Run']],
  'intro_body'=>[
    'Performance marketing — also called paid advertising or PPC (pay-per-click) — is the practice of running paid campaigns across Google, Meta (Facebook and Instagram), LinkedIn, TikTok and other platforms to generate immediate, measurable business results. Unlike SEO, which builds organic traffic over months, performance marketing delivers visibility from day one, reaching people who are actively searching for your product or service right now.',
    'The challenge is that most businesses running paid advertising are wasting a significant portion of their budget. Poor account structure, broad keyword matching, no conversion tracking, unoptimized landing pages and set-it-and-forget-it campaign management are endemic in the industry. Our average ROAS across active campaigns is 4.8× — meaning for every ₹1 our clients invest, they generate ₹4.80 in revenue on average. That figure reflects rigorous campaign architecture, continuous optimization and the discipline to pause what is not working and scale what is.',
    'Qrenzy manages paid advertising across Google Ads, Meta Ads (Facebook and Instagram), TikTok, LinkedIn and Pinterest for clients in India and the Gulf. Gulf market campaigns are built with bilingual ad creative and locally calibrated bidding strategies — accounting for the higher CPCs of UAE and Qatar markets and the unique audience behaviours of each Gulf country.',
  ],
  'who_for'=>[
    'title'=>'Who Performance Marketing Is For',
    'desc'=>'Paid advertising works best for businesses that need leads now and have a budget to invest in immediate visibility.',
    'list'=>[
      'Service businesses (clinics, agencies, lawyers, finance) needing immediate leads from high-intent Google searches',
      'E-commerce brands wanting to scale product sales through Google Shopping, Meta catalogue and performance campaigns',
      'B2B companies targeting corporate decision-makers through LinkedIn Ads in India and the Gulf',
      'Businesses launching new products or services needing immediate market reach and customer acquisition',
      'Seasonal businesses needing precise peak-period advertising campaigns with defined start and end dates',
      'Businesses with existing poorly-performing campaigns needing professional restructuring and management',
    ],
  ],
  'benefits'=>[
    ['⚡','Immediate Visibility','Unlike SEO, paid ads put your business in front of high-intent buyers from day one — no waiting months.'],
    ['🎯','Precision Targeting','Reach exactly the right audience — by location, intent, demographics and online behaviour.'],
    ['📊','Full ROI Tracking','Every lead, call and sale tracked back to the specific ad and keyword that generated it.'],
    ['🔄','Continuous Optimization','Weekly campaign review — pausing poor performers, scaling winners, A/B testing creative.'],
    ['🌍','India & Gulf Campaigns','Bilingual campaigns for Gulf markets with local currency bidding and Gulf-specific audience targeting.'],
    ['🎨','Ad Creative Included','Static image ads, carousel ads and video ad scripts designed by our team.'],
  ],
  'what_is'=>[
    'heading' => 'What Is Performance Marketing (PPC)?',
    'answer'  => 'Performance marketing, also known as pay-per-click (PPC) advertising, is a digital advertising model where businesses pay only when a specific action occurs — typically a click on an ad, a form submission or a purchase. Unlike traditional advertising where you pay for exposure regardless of results, performance marketing is entirely measurable and outcome-focused. It encompasses Google Ads (appearing in Google search results when people search for your keywords), Meta Ads (targeted advertising on Facebook and Instagram), LinkedIn Ads (B2B audience targeting by job title and industry), TikTok Ads and other paid platforms. The key metrics in performance marketing are ROAS (Return on Ad Spend — revenue generated per rupee invested in ads), CPC (Cost Per Click), CPL (Cost Per Lead) and conversion rate. Qrenzy\'s average ROAS across active client campaigns is 4.8× — for every ₹1 invested, clients generate ₹4.80 in revenue on average.',
  ],
  'what_title'=>'All Platforms. One Expert Team.',
  'services_list'=>[
    ['🔍','Google Ads','Search, Display, Shopping and Performance Max campaigns targeting high-intent buyers.'],
    ['📘','Meta Ads','Facebook and Instagram ads for reach, leads and conversions with precision audience targeting.'],
    ['🎵','TikTok Ads','Short-form video ads reaching younger audiences in India and Gulf markets.'],
    ['💼','LinkedIn Ads','B2B lead generation targeting decision-makers by job title, company and industry.'],
    ['📌','Pinterest Ads','Visual discovery ads for e-commerce, home décor, fashion and lifestyle brands.'],
    ['🎯','Remarketing','Re-engage website visitors across Google, Meta and YouTube who did not convert.'],
  ],
  'problem_solution'=>[
    'problem' => 'You\'re spending on Google or Meta Ads but the leads are poor quality, the cost per lead is too high and you can\'t tell which campaigns are actually working. Budget is being wasted every day.',
    'solution' => 'We rebuild your campaigns from the ground up — tight ad groups, specific keywords, proper conversion tracking and weekly optimisation. Our average ROAS is 4.8× — every rupee tracked, every lead attributed.',
    'included' => ['Google Ads & Meta Ads management','Full conversion tracking setup','Ad creative design included','Weekly campaign optimisation','Search term & negative keyword management','Monthly ROAS & ROI reporting'],
  ],
  'results'=>[['4.8x','ROAS'],['40%','Lower CPC'],['3x','More Leads'],['Zero','Wasted Budget']],
  'process'=>[
    ['Week 1','Research','Keyword research, competitor ad analysis, audience setup and conversion tracking.'],
    ['Week 2','Build','Campaign structure, ad copy, creatives, landing page review and bid strategy.'],
    ['Week 3','Launch','Campaigns live with daily monitoring, search term analysis and negative keywords.'],
    ['Month 2+','Optimise','Weekly optimisation — pause poor performers, scale winners, A/B test creatives.'],
  ],
  'faqs'=>[
    ['Which advertising platforms do you manage?','We manage Google Ads (Search, Display, Shopping and Performance Max), Meta Ads (Facebook and Instagram), TikTok Ads, LinkedIn Ads and Pinterest Ads. We recommend the right platform mix based on your audience, industry and budget. Most B2C businesses start with Google Search plus Meta Ads. B2B businesses benefit from LinkedIn Ads. E-commerce sees strong results from Google Shopping plus Meta catalogue campaigns.'],
    ['What is the minimum ad spend budget needed?','For Google Search Ads in India, a minimum of ₹15,000 per month in ad spend is needed for meaningful optimization data. For Meta Ads, ₹10,000 minimum. Our management fee is charged separately on top of ad spend. For Gulf markets, minimum budgets are OMR 150 (Oman) or AED 500 (UAE) per month. Below these thresholds, insufficient data prevents effective optimization.'],
    ['How soon will I see leads from paid advertising?','Google Search Ads can generate leads from day one — you appear for relevant searches immediately. The first 2–4 weeks involve significant optimization as we identify which keywords, audiences and messages perform best. Most campaigns reach consistent, profitable performance by month 2. Meta Ads typically take 2–3 weeks to exit the learning phase and deliver stable results.'],
    ['Do you design the ad creatives?','Yes — ad creative design is included in our performance marketing service. We design static image ads, carousel ads and provide video ad scripts. We A/B test multiple creative variations and continuously refresh creative to prevent ad fatigue, particularly important for Meta campaigns running to the same audience over extended periods.'],
    ['How do you track conversions and prove ROI?','We implement conversion tracking for every campaign — Google Ads conversion tracking for leads, calls and form fills; Meta Pixel for website conversions. We set up Google Analytics 4 integration for full customer journey data. Monthly reports show cost per lead, ROAS, campaign-level breakdown and ROI against your ad spend. Every rupee is fully accounted for.'],
  ],
],

'ai-marketing-automation' => [
  'icon'=>'🤖','color'=>'#0891B2',
  'title'=>'AI Marketing Automation',
  'tagline'=>'Work Smarter. Scale Faster. Automate Everything.',
  'badge'=>"Kerala's First AI-Powered Marketing Agency",
  'hero_desc'=>'Automate your marketing workflows with AI — content generation, lead nurturing, WhatsApp bots, automated reporting and CRM integration. Save hours every week.',
  'stats'=>[['60%','Less Manual Work'],['10x','Content Output'],['24/7','Lead Capture'],['48hr','Bot Deployment']],
  'intro_body'=>[
    'Artificial intelligence has fundamentally changed what is possible in marketing automation. Tasks that once required hours of manual work — writing social media captions, responding to leads, generating reports, sending follow-up emails — can now be automated intelligently using AI tools that adapt to your brand voice, your audience and your business rules. Businesses adopting AI marketing automation now are building a significant operational advantage over competitors still doing everything manually.',
    'Qrenzy was one of the first digital marketing agencies in Kerala to build AI-powered marketing workflows for clients. We use Make.com, Zapier, n8n, WhatsApp Business API, OpenAI, MailerLite and custom PHP to build automation systems tailored specifically to each client\'s business processes. We are not reselling template automations — we architect custom workflows that integrate precisely with how your business operates.',
    'Our AI marketing automation service covers the full spectrum — from WhatsApp chatbots that capture and qualify leads 24 hours a day, to AI content pipelines producing blog posts, social captions and email newsletters at 10× manual speed. Every automation we build is documented, trained-on and handed over to your team with full operational clarity. You own the system completely.',
  ],
  'who_for'=>[
    'title'=>'Who AI Marketing Automation Is For',
    'desc'=>'AI automation delivers the highest ROI for businesses spending significant time on repetitive marketing and lead management tasks.',
    'list'=>[
      'Service businesses receiving high WhatsApp enquiry volumes needing instant, intelligent responses at any hour',
      'Content-heavy businesses needing to publish blog posts, social media and email newsletters consistently at scale',
      'Sales teams wasting time on manual lead follow-up that should be automated with intelligent nurturing sequences',
      'E-commerce businesses wanting automated cart abandonment emails, review requests and upsell sequences',
      'Multi-location businesses needing automated reporting across all locations consolidated into one dashboard',
      'Any business where manual data entry or repetitive marketing tasks consume significant team hours daily',
    ],
  ],
  'benefits'=>[
    ['⏰','Save 10+ Hours Per Week','Automate repetitive tasks — content drafting, lead follow-up, reporting and scheduling — reclaiming significant team time weekly.'],
    ['💬','24/7 Lead Capture','WhatsApp and website chatbots qualify and capture leads around the clock — even outside business hours when most leads are lost.'],
    ['🤖','AI Content at Scale','AI-assisted pipelines produce blog posts, social captions, email newsletters and ad copy at 10× manual speed with human review.'],
    ['🔌','Full System Integration','All marketing tools connected — website forms, WhatsApp, email, CRM, ads and reporting — no data silos, no manual transfers.'],
    ['📊','Automated Reporting','Custom dashboards and automated PDF reports delivered to your inbox weekly — no manual data pulling.'],
    ['🎓','Full Documentation & Training','Every automation documented and your team trained to manage it. You own and control the system completely.'],
  ],
  'what_is'=>[
    'heading' => 'What Is AI Marketing Automation?',
    'answer'  => 'AI marketing automation is the use of artificial intelligence tools and workflow automation platforms to perform marketing tasks that would otherwise require manual human effort — such as generating content, responding to leads, sending follow-up emails, publishing social media posts and producing reports. Modern AI marketing automation combines large language models (like GPT-4) for content generation with workflow tools (like Make.com, Zapier or n8n) for connecting different platforms and triggering automated actions based on rules. For businesses in India and the Gulf, AI marketing automation reduces marketing workload by 40–60%, improves lead response speed (instant WhatsApp replies versus hours of delay), and enables content output at 10× the volume of purely manual approaches — all while maintaining brand voice consistency through carefully engineered AI prompting.',
  ],
  'what_title'=>'AI Automation Services We Offer',
  'services_list'=>[
    ['🤖','AI Content Systems','AI-assisted pipelines for blog posts, social captions, email newsletters and ad copy — at scale.'],
    ['💬','WhatsApp Automation','WhatsApp Business bots for lead capture, appointment booking and customer support.'],
    ['📧','Email Automation','Automated email sequences, lead nurturing flows and triggered campaigns via MailerLite or Brevo.'],
    ['📊','Automated Reporting','Custom dashboards and automated PDF reports sent to your inbox weekly.'],
    ['🔌','CRM Integration','Connect website forms, WhatsApp and ads to a CRM — every lead tracked, no lead lost.'],
    ['🧠','AI Chatbots','Website chatbots that qualify leads, answer FAQs and book appointments 24/7.'],
  ],
  'problem_solution'=>[
    'problem' => 'Your team wastes hours every week on repetitive tasks — manually responding to WhatsApp leads, writing social media captions, pulling reports and following up with enquiries. Leads fall through the cracks outside business hours.',
    'solution' => 'We build custom AI-powered automation workflows — WhatsApp bots that respond instantly 24/7, content pipelines that generate posts and emails at scale, and CRM integrations that ensure every lead is captured and followed up automatically.',
    'included' => ['WhatsApp Business chatbot setup','AI content generation pipeline','Email automation sequences','CRM & lead capture integration','Automated reporting dashboards','Full documentation & team training'],
  ],
  'results'=>[['60%','Less Manual Work'],['10x','Content Speed'],['24/7','Lead Capture'],['Zero','Leads Lost']],
  'process'=>[
    ['Day 1-2','Audit','Map current workflows, identify automation opportunities and calculate time savings.'],
    ['Day 3-5','Design','Build automation architecture — flows, triggers, integrations and AI prompts.'],
    ['Week 2-3','Build','Develop bots, email flows, API connections and reporting dashboards.'],
    ['Week 4','Launch','Testing, go-live, team training and 30-day monitoring.'],
  ],
  'faqs'=>[
    ['What tools do you use to build automations?','We use Make.com, Zapier and n8n for workflow automation depending on complexity and budget. For AI content, we use OpenAI GPT-4 via API with custom prompting calibrated to your brand voice. For WhatsApp automation, we use the WhatsApp Business API through approved providers. For email automation, MailerLite and Brevo. All tools selected are enterprise-grade, reliable and scalable.'],
    ['Do I need technical knowledge to use or manage the automations?','No technical knowledge is required to use the automations — they run in the background automatically. We provide training on the specific tools used (typically Make.com or n8n) accessible to non-technical users. Every automation is fully documented with step-by-step guides. Most clients can make routine adjustments — changing a message template, updating a trigger — within 30 minutes of training.'],
    ['How quickly can a WhatsApp automation be deployed?','A standard WhatsApp Business chatbot handling enquiries, capturing lead details and sending automated follow-ups can be deployed in 48 hours once your WhatsApp Business API account is approved. The API approval itself typically takes 3–5 business days through Meta\'s verification process. More complex multi-flow bots with appointment booking integration take 5–7 working days.'],
    ['Can you automate content creation for social media?','Yes — AI content pipelines for social media are among our most popular automations. We create custom AI systems generating Instagram captions, Facebook posts, LinkedIn updates and email drafts in your specific brand voice. All AI-generated content is reviewed by a human editor before scheduling, delivering 10× the content output of purely manual creation while maintaining quality and brand consistency.'],
    ['Is AI-generated content safe for SEO?','AI-assisted content is safe and effective for SEO when produced correctly. We use AI as a research and drafting assistant — every piece is reviewed, edited and fact-checked by a human writer before publication. We add original insights, real data and expert perspective that pure AI cannot generate. Google\'s guidelines focus on helpfulness and expertise — not whether AI was part of the process — and our approach consistently produces content that ranks and converts.'],
  ],
],

'photography-videography' => [
  'icon'=>'📸','color'=>'#BE185D',
  'title'=>'Photography & Videography',
  'tagline'=>'Visual Content That Stops the Scroll.',
  'badge'=>'Sony A7 IV Professional Setup',
  'hero_desc'=>'Professional product photography, corporate videos, real estate walkthroughs and social media content. Shot on Sony A7 IV — cinematic quality that makes your brand look world-class.',
  'stats'=>[['Sony A7 IV','Professional Camera'],['4K','Video Resolution'],['24hr','Quick Turnaround'],['18+','Years Experience']],
  'intro_body'=>[
    'Professional photography and videography is the practice of creating high-quality visual content — product images, brand videos, corporate photography and social media reels — that accurately and compellingly represents a business to its potential customers. For businesses in India and the Gulf, professional visual content is now a baseline requirement for digital credibility: consumers make purchase decisions based on what they see online in under 3 seconds, and low-quality visuals lose those decisions immediately.',
    'Qrenzy\'s photography and videography service is built around our professional Sony A7 IV full-frame camera system — the same camera body used by commercial photographers producing images for international brands. Combined with our DJI RS 5 gimbal, professional lighting setup and lapel and shotgun microphone rigs, we produce photography and video content that matches the production quality of agencies charging significantly more.',
    'We cover businesses across Kerala and Oman — from product photography for e-commerce sellers in Thrissur to corporate brand videos for companies in Muscat. Our 18+ years of visual content experience means we not only operate the equipment professionally but understand how to direct subjects, design shot compositions and edit content that communicates your brand story effectively across every digital platform.',
  ],
  'who_for'=>[
    'title'=>'Who Our Photography & Videography Service Is For',
    'desc'=>'Professional visual content delivers the highest ROI for businesses competing in visually-driven markets.',
    'list'=>[
      'E-commerce businesses selling on Amazon, Noon, Flipkart or their own website needing high-quality product photography',
      'Restaurants, hotels and hospitality businesses where food and interior photography directly drives customer decisions',
      'Real estate developers and agents in Kerala and Oman needing property photography and walkthrough videos',
      'Corporate businesses needing professional team headshots, office photography and brand story videos',
      'Social media-focused brands needing a library of high-quality Reels, Stories and visual content',
      'Companies whose current website and marketing uses poor-quality images that undermine their brand credibility',
    ],
  ],
  'benefits'=>[
    ['📸','Sony A7 IV Quality','Full-frame professional camera delivering the image quality that differentiates your brand from competitors using smartphone photography.'],
    ['🎬','4K Cinematic Video','4K video with DJI gimbal stabilization producing cinematic quality brand videos, product demos and social content.'],
    ['⚡','24-Hour Delivery','Edited content delivered within 24 hours of the shoot for most standard projects — fastest in the industry.'],
    ['🌍','Kerala & Oman Coverage','We cover all of Kerala and Muscat and major Oman cities. Available for multi-day shoots across Gulf markets with advance booking.'],
    ['📁','RAW Files Always Included','You receive all final edited files plus RAW originals — full ownership of every image and video we produce for you.'],
    ['📱','Social-Ready Formats','All content delivered in multiple formats — web, print and platform-specific social media versions included in every project.'],
  ],
  'what_is'=>[
    'heading' => 'What Is Professional Photography & Videography?',
    'answer'  => 'Professional photography and videography is the creation of high-quality visual content — including product images, corporate photos, brand videos, real estate walkthroughs and social media reels — using professional camera equipment, lighting and post-production techniques. The distinction between professional and amateur visual content lies in three areas: equipment quality (full-frame cameras like the Sony A7 IV vs smartphones), technical skill (exposure, composition, lighting direction, colour grading) and strategic intent (understanding how the image will be used, on which platform and for which audience). For businesses in India and the Gulf, professional visual content is not optional — it is a fundamental requirement for digital credibility, e-commerce performance and social media engagement. Studies consistently show that professional product photography increases e-commerce conversion rates by 30–40% compared to amateur images.',
  ],
  'what_title'=>'Photography & Video Services',
  'services_list'=>[
    ['🛍️','Product Photography','E-commerce-ready product shots on white background or lifestyle settings for Amazon, Noon and your website.'],
    ['🏢','Corporate Photography','Team headshots, office interiors, event coverage and brand storytelling photography.'],
    ['🏠','Real Estate Photography & Video','Property walkthroughs, drone footage and interior photography for listings in Oman and Kerala.'],
    ['🎬','Brand Video Production','60-90 second brand videos, testimonials and explainer videos for website and social media.'],
    ['📱','Social Media Content','Vertical Reels, Stories and TikTok-ready video shot and edited for maximum engagement.'],
    ['✂️','Video Editing','Colour grading, motion graphics, subtitles and music for any footage you provide.'],
  ],
  'problem_solution'=>[
    'problem' => 'Your product photos look amateur, your brand videos are shaky or nonexistent and your social media feed lacks the visual quality needed to compete. Poor visuals are silently killing your conversions.',
    'solution' => 'We shoot on Sony A7 IV full-frame with professional lighting and DJI gimbal stabilisation — producing product photography, brand videos and social Reels that make your business look world-class and drive real engagement.',
    'included' => ['Product & corporate photography','Brand video production','Instagram Reels & social content','4K video with DJI gimbal','Professional lighting & audio','24-hour edited delivery, RAW files included'],
  ],
  'results'=>[['4K','Video Quality'],['24hr','Delivery'],['RAW Files','Always Included'],['Oman & Kerala','Coverage']],
  'process'=>[
    ['Day 1','Brief','Understand your brand, usage requirements, locations and shot list.'],
    ['Day 2','Shoot','Professional shoot on Sony A7 IV with gimbal, lighting and audio equipment.'],
    ['Day 3','Edit','Colour grading, retouching, motion graphics and music sync.'],
    ['Day 4','Deliver','Final files in all formats — web, print and social media optimised.'],
  ],
  'faqs'=>[
    ['Do you cover shoots in Oman as well as Kerala?','Yes — we cover Muscat and major Oman cities for photography and video shoots. We also cover all of Kerala, with no travel charges within Thrissur city. Travel charges apply for locations outside Thrissur in Kerala and outside Muscat in Oman. For multi-day shoots in the Gulf, accommodation costs are covered by the client. We require advance booking of at least 2 weeks for Gulf shoots.'],
    ['What equipment do you use?','Our primary camera is the Sony A7 IV full-frame mirrorless — one of the best cameras available for professional photography and video in 2024. We also use the Sony ZV-E10 for secondary angle video. For video stabilization, we use the DJI RS 5 gimbal. Lighting is provided through portable professional LED panels. Audio is captured via both lapel microphones for interviews and a Rode shotgun microphone for ambient and on-camera use.'],
    ['Do you offer editing-only services for footage I already have?','Yes — we offer standalone video editing services. Send us your raw footage and we deliver professionally colour-graded, edited and music-synced final video in the format you need. Editing-only projects typically have a 24–48 hour turnaround depending on video length and complexity. We work with footage from any camera system, including drone footage and smartphone video.'],
    ['What file formats are photos and videos delivered in?','Photography: high-resolution JPG files, PNG where needed and RAW files (Sony ARW format) always included. Video: MP4 in H.264 for web and social media, H.265 for archival quality, and MOV master files. We also provide platform-specific versions: square and vertical 9:16 crops for social media, web-optimized versions and print-resolution files where required.'],
    ['Can you produce Reels and short-form social media videos?','Yes — social media video production is one of our most requested services. We shoot and edit vertical 9:16 Reels and Stories specifically designed for Instagram and Facebook engagement. We understand pacing, music, text overlay and the visual style that performs well on each platform. Social media video packages can be combined with our Social Media Marketing service for a complete content production and publishing solution.'],
  ],
],

'graphic-designing' => [
  'icon'=>'🎨','color'=>'#059669',
  'title'=>'Graphic Design',
  'tagline'=>'Design That Speaks Your Brand.',
  'badge'=>'18+ Years Design Experience',
  'hero_desc'=>'Professional graphic design for digital and print — brand identity, social media creatives, brochures, banners and all marketing collateral your business needs to look world-class.',
  'stats'=>[['500+','Designs/Year'],['48hr','Turnaround'],['100%','Brand Consistent'],['18+','Years Experience']],
  'intro_body'=>[
    'Graphic design is the practice of visual communication — using typography, colour, imagery and layout to convey information and create brand identity across digital and print formats. For businesses in India and the Gulf, professional graphic design is the foundation of how customers perceive your brand: a well-designed logo, consistent social media graphics and quality printed collateral signal credibility and professionalism before a single word is read.',
    'Qrenzy\'s graphic design service brings 18+ years of professional design experience to businesses across India and the Gulf. We have designed brand identities for startups building from scratch, refreshed outdated visual systems for established businesses, and produced ongoing social media creatives, marketing collateral and packaging design for companies across Kerala, Oman and UAE. Our design work is not purely aesthetic — it is strategically aligned to your marketing objectives and target audience.',
    'We work in all design disciplines — brand identity, digital marketing design, print and packaging, social media graphics and motion graphics. Whether you need a complete brand identity built from scratch, a single brochure for a trade show, or a monthly supply of social media graphics, we deliver with the same rigorous attention to brand consistency and design quality. All source files (AI, PSD, Canva) are provided at project completion — you own everything we create.',
  ],
  'who_for'=>[
    'title'=>'Who Our Graphic Design Service Is For',
    'desc'=>'Professional design delivers the highest impact for businesses where visual presentation directly influences customer trust and purchasing decisions.',
    'list'=>[
      'New businesses needing a complete brand identity — logo, brand guidelines, colour system and visual language',
      'Established businesses with outdated or inconsistent branding that no longer reflects their market position',
      'Businesses needing ongoing social media graphics, promotional creatives and digital marketing design',
      'Companies preparing for trade shows, tenders or pitches requiring high-quality printed collateral',
      'Product businesses needing packaging design, labelling and retail-ready visual presentation',
      'Any business whose current design work looks amateur and is undermining their credibility with potential customers',
    ],
  ],
  'benefits'=>[
    ['🏷️','Complete Brand Identity','Logo, brand guidelines, colour palette, typography and complete visual system — everything needed for brand consistency across all touchpoints.'],
    ['⚡','48-Hour Turnaround','Standard design projects delivered within 48 hours. Rush delivery available. We never miss agreed deadlines.'],
    ['🔄','3 Free Revision Rounds','Three rounds of revisions included in every project — ensuring you get exactly what you need without unexpected additional charges.'],
    ['📁','Source Files Always Included','All source files (Adobe Illustrator, Photoshop, Canva) delivered at completion. You own everything and can work with any future designer.'],
    ['🖨️','Print & Digital Ready','All designs delivered in both print-ready (CMYK, 300 DPI, with bleed) and digital (RGB, web-optimized) formats.'],
    ['🌍','India & Gulf Design Experience','18+ years designing for Indian and Gulf market audiences — understanding local aesthetic preferences and cultural considerations.'],
  ],
  'what_is'=>[
    'heading' => 'What Is Graphic Design?',
    'answer'  => 'Graphic design is the discipline of visual communication — using typography, colour, imagery, layout and hierarchy to convey information, create identity and guide the viewer\'s attention toward a specific response or action. In a business context, graphic design encompasses brand identity (logos, colour systems, typography), digital design (social media graphics, website visuals, digital ads), and print design (brochures, packaging, signage). Professional graphic design is distinguished from amateur design by its strategic foundation: every design decision — colour choice, font pairing, layout spacing — serves a specific communication objective aligned to the target audience and marketing goal. For businesses in India and the Gulf, consistent professional design across all touchpoints builds the brand credibility that converts browsers into buyers and enquiries into clients.',
  ],
  'what_title'=>'Our Graphic Design Services',
  'services_list'=>[
    ['🏷️','Brand Identity','Logo design, brand guidelines, colour palette, typography and complete visual identity system.'],
    ['📱','Social Media Graphics','Instagram posts, Facebook covers, Story templates, carousels and Reel thumbnails.'],
    ['📄','Brochures & Flyers','Print-ready brochures, company profiles, product catalogues and promotional flyers.'],
    ['🖥️','Digital Banners','Website banners, Google Display ads, email headers and digital marketing creatives.'],
    ['📦','Packaging Design','Product packaging, labels and box design for retail and e-commerce products.'],
    ['🎞️','Motion Graphics','Animated logos, lower thirds, video thumbnails and motion graphic elements.'],
  ],
  'problem_solution'=>[
    'problem' => 'Your logo looks generic, your social media graphics are inconsistent and your marketing materials don\'t reflect the quality of your actual business. Poor design is costing you credibility before a word is read.',
    'solution' => 'We design brand identities, social media creatives, brochures and all marketing collateral that are strategically aligned to your audience — not just visually nice, but built to build trust and drive conversions.',
    'included' => ['Logo & full brand identity design','Social media graphic templates','Brochures, flyers & print design','Google Display & digital ad creatives','Packaging & product label design','Source files (AI, PSD, Canva) always included'],
  ],
  'results'=>[['48hr','Turnaround'],['3 Rounds','Free Revisions'],['Print & Digital','All Formats'],['Source Files','Always Included']],
  'process'=>[
    ['Day 1','Brief','Design brief, brand review, reference collection and style direction approval.'],
    ['Day 2-3','Concepts','Initial design concepts — 2-3 variations for feedback.'],
    ['Day 4','Revisions','Refinements based on feedback. Up to 3 rounds included.'],
    ['Day 5','Delivery','Final files in all formats — PNG, JPG, PDF, SVG and source files.'],
  ],
  'faqs'=>[
    ['Do you provide source files at the end of the project?','Yes — all source files are provided at project completion at no additional charge. This includes Adobe Illustrator files (AI) for logos and vector graphics, Adobe Photoshop files (PSD) for photo-based designs, and Canva files where applicable. You have complete ownership of everything we create and can work with any designer in the future without limitation.'],
    ['How many revisions are included?','Three full rounds of revisions are included in every design project. Each revision round covers unlimited individual changes within that round — it is not limited to a certain number of individual edits. If you require additional revisions beyond three rounds, a small per-round fee applies. In practice, the majority of our projects complete within two revision rounds.'],
    ['Can you design within our existing brand guidelines?','Yes — if you have existing brand guidelines, we work strictly within them, using your specified colours, fonts, logo usage rules and visual style. If your guidelines are incomplete or unclear, we help fill in the gaps while respecting the established direction. For businesses without any formal brand guidelines, we can create a brand identity document as a deliverable alongside the design project.'],
    ['Do you design for print and physical production?','Yes — all print designs are produced to professional print standards: CMYK colour mode, 300 DPI minimum resolution, with bleed and trim marks. We understand printing requirements across Kerala and the Gulf and can liaise with print vendors on your behalf. All designs are supplied ready for professional printing without any additional preparation required by the printer.'],
    ['Can you design social media graphics on an ongoing monthly basis?','Yes — ongoing monthly social media graphic packages are one of our most popular services. We produce a set number of branded social media graphics each month — Instagram posts, Facebook covers, Story templates, promotional graphics — maintaining complete brand consistency. This service is often combined with our Social Media Marketing service for a fully managed social media presence.'],
  ],
],

'custom-software' => [
  'icon'=>'💻','color'=>'#4F46E5',
  'title'=>'Software Solutions',
  'tagline'=>'Custom Tech Built for Your Business.',
  'badge'=>'Custom Web Applications',
  'hero_desc'=>'Custom web applications, booking systems, CRMs and business automation tools. We build tech that saves time, reduces manual work and scales your operations.',
  'stats'=>[['60%','Less Manual Work'],['48hr','First Prototype'],['20+','Apps Built'],['100%','You Own the Code']],
  'intro_body'=>[
    'Off-the-shelf software rarely fits the way your business actually works. You end up adapting your processes to fit the software — paying for features you do not need while missing critical functionality that would genuinely improve your operations. Custom software solves the actual problems your business faces, built precisely around your workflow, your team and your customers. The result is a system that increases efficiency, reduces errors and scales with your business rather than constraining it.',
    'Qrenzy builds custom web applications, booking and reservation systems, CRM tools, reporting dashboards, API integrations and business automation tools for businesses across India and the Gulf. Our development stack is focused on WordPress and PHP for web applications — reliable, well-supported and maintainable by any competent developer without vendor lock-in. For more complex applications, we use modern frameworks selected based on the specific requirements of each project.',
    'Every software project we deliver comes with complete source code, thorough documentation and team training. You own everything — no licensing fees, no dependency on our agency for routine maintenance, no black box you cannot look inside. Our post-launch support retainers are available but entirely optional. We build software that empowers your business, not software that creates dependency.',
  ],
  'who_for'=>[
    'title'=>'Who Our Software Solutions Service Is For',
    'desc'=>'Custom software delivers the highest ROI for businesses with specific operational needs that generic off-the-shelf tools cannot address.',
    'list'=>[
      'Service businesses needing online booking and appointment systems integrated with payment gateways and WhatsApp',
      'Companies with manual data entry workflows that could be automated, saving significant staff time daily',
      'Businesses that have outgrown spreadsheets and need a proper CRM to track leads, clients and sales pipeline',
      'Multi-location businesses needing consolidated reporting dashboards across all locations',
      'E-commerce businesses needing custom WooCommerce functionality beyond standard plugin capabilities',
      'Any business where repetitive manual processes — copying data between systems, generating reports, managing bookings — consume significant staff time',
    ],
  ],
  'benefits'=>[
    ['⚙️','Built for Your Workflow','Custom software designed around how your business actually operates — not a generic solution you have to adapt to.'],
    ['💰','Own It Forever','100% source code ownership. No monthly SaaS fees, no vendor lock-in, no ongoing licensing costs beyond optional maintenance.'],
    ['⚡','48-Hour First Prototype','We show you a working prototype within 48 hours of project kickoff — you see progress immediately, not after weeks of invisible development.'],
    ['🔌','Integrates Everything','Connect all your existing tools — payment gateways, WhatsApp Business API, email platforms, accounting software and third-party APIs.'],
    ['📱','Mobile Responsive','Every application built mobile-first — accessible and fully functional on smartphones, which is how most Indian and Gulf users access web applications.'],
    ['📚','Full Documentation & Training','Complete technical documentation and team training provided at handover. Your team can operate and manage the system independently from day one.'],
  ],
  'what_is'=>[
    'heading' => 'What Are Custom Software Solutions?',
    'answer'  => 'Custom software solutions are applications, tools and systems built specifically for a business\'s unique operational requirements — as opposed to off-the-shelf software (like generic CRMs or booking platforms) that businesses adapt their processes to fit. Custom software development covers web applications, booking and appointment systems, customer relationship management (CRM) tools, API integrations between existing platforms, automated reporting dashboards and e-commerce solutions with custom functionality. The primary advantages of custom software over generic alternatives are: exact fit to your workflow with no unnecessary features, full ownership with no ongoing licensing fees, seamless integration with your existing tools and the ability to evolve the software as your business grows. For businesses in India and the Gulf, custom software development typically delivers ROI within 6–12 months through time saved on manual processes and errors eliminated through automation.',
  ],
  'what_title'=>'Custom Software We Build',
  'services_list'=>[
    ['⚙️','Web Applications','Custom web apps on PHP/WordPress tailored exactly to your business workflow.'],
    ['📅','Booking Systems','Online appointment systems with payment integration for service businesses.'],
    ['🗂️','CRM Systems','Custom CRM tools to track leads, clients and sales pipeline.'],
    ['🔌','API Integrations','Connect payment gateways, WhatsApp Business, ERP and third-party APIs.'],
    ['📊','Dashboards','Custom analytics dashboards and automated reporting tools.'],
    ['🛒','E-commerce','Custom WooCommerce stores with inventory management and Gulf payment gateways.'],
  ],
  'problem_solution'=>[
    'problem' => 'You\'re using generic off-the-shelf software that doesn\'t fit your workflow, or your team is wasting hours on manual processes that should be automated. Every workaround costs time and money.',
    'solution' => 'We build custom web applications, booking systems, CRMs and automation tools tailored exactly to your business — eliminating manual work, reducing errors and scaling operations without scaling headcount.',
    'included' => ['Custom web application development','Online booking & appointment systems','CRM & lead management tools','API & payment gateway integrations','Automated reporting dashboards','Full source code ownership, documentation & training'],
  ],
  'results'=>[['60%','Less Manual Work'],['48hr','First Demo'],['100%','Custom Built'],['Lifetime','Code Ownership']],
  'process'=>[
    ['Day 1-2','Discovery','Understand workflow, pain points and exact requirements.'],
    ['Day 3-5','Architecture','Technical design, database schema, API planning and tech stack.'],
    ['Week 2-4','Development','Agile development with weekly demos. You see progress every step.'],
    ['Week 5','Launch','QA, bug fixes, deployment, documentation and team training.'],
  ],
  'faqs'=>[
    ['Do you build mobile apps?','We specialize in progressive web applications (PWAs) that work excellently on mobile browsers without requiring app store installation. PWAs deliver 90% of the functionality of native apps at a fraction of the development cost and with simpler maintenance. For businesses specifically requiring native iOS or Android apps, we work with our partner network of mobile developers. We recommend discussing your requirements in detail — in most cases, a well-built mobile-responsive web application meets the need more cost-effectively.'],
    ['Who owns the code after the project is complete?','You own 100% of the code. All source code, database schemas, documentation and assets are handed over at project completion. There are no licensing fees, no ongoing charges for code access and no restrictions on what you do with the code after delivery. You can work with any other developer in the future, host it wherever you choose and modify it however you need.'],
    ['Can you automate our manual business processes?','Almost certainly yes. We have automated a wide variety of business processes — from invoice generation and report creation to lead routing, inventory alerts and multi-step approval workflows. The first step is a process mapping session where we document your current workflow in detail and identify exactly what can be automated and what the time savings would be. This session is free as part of our discovery process.'],
    ['What payment gateways do you integrate?','For Indian clients, we integrate Razorpay, PayU and CCAvenue — all supporting UPI, credit/debit cards and net banking. For Gulf market clients, we integrate PayPal, Stripe and local Gulf payment gateways including Thawani (Oman), PayTabs (GCC) and Network International (UAE). All payment integrations are implemented with proper security standards — PCI-compliant processing, secure tokenization and encrypted transaction data.'],
    ['Do you provide ongoing maintenance and support after launch?','Yes — optional monthly maintenance and support retainers are available after project launch. Maintenance retainers cover bug fixes, security updates, WordPress and plugin updates, hosting monitoring and a set number of development hours per month for enhancements. These retainers are optional — the software is fully handed over and you can maintain it independently or through any other developer. Most clients choose a retainer for the first 6–12 months while their team builds familiarity with the system.'],
  ],
],

]; // end services

$s = $services[$slug] ?? null;
if (!$s) { wp_redirect(home_url('/services/')); exit; }

get_header(); ?>

<?php
// ── SERVICE SCHEMA (JSON-LD) — No RankMath Pro needed ─────────────────
$schema_service_map = [
  'search-engine-optimization' => ['Search Engine Optimization','SEO services in Kerala, Oman & UAE. Technical SEO, content marketing & link building to get Page 1 rankings.','Kerala, India','Oman','UAE'],
  'web-designing'              => ['Web Design & Development','Custom WordPress websites in Kerala & Oman. Fast, SEO-ready, mobile-first. Built to convert visitors into leads.','Kerala, India','Oman','UAE'],
  'social-media-marketing'     => ['Social Media Marketing','Strategic social media marketing across Instagram, Facebook & LinkedIn for businesses in India, Oman & UAE.','Kerala, India','Oman','UAE'],
  'pay-per-click'              => ['Performance Marketing','Google Ads, Meta Ads, TikTok & LinkedIn campaigns with 4.8x average ROAS. Serving India, Oman & UAE.','Kerala, India','Oman','UAE'],
  'ai-marketing-automation'    => ['AI Marketing Automation','AI-powered marketing automation — WhatsApp bots, email flows, content systems & CRM integration.','Kerala, India','Oman','UAE'],
  'photography-videography'    => ['Photography & Videography','Professional product photography & video production in Kerala & Oman. Sony A7 IV. Brand videos & Reels.','Kerala, India','Oman'],
  'graphic-designing'          => ['Graphic Design','Logo design, social media creatives, brochures & brand identity. 18+ years experience. India, Oman & UAE.','Kerala, India','Oman','UAE'],
  'custom-software'            => ['Software Solutions','Custom web apps, booking systems, CRM & WhatsApp bots. Business automation built in Kerala.','Kerala, India','Oman','UAE'],
];
if (isset($schema_service_map[$slug])):
  $sm = $schema_service_map[$slug];
  $areas = array_slice($sm, 2);
  $areas_json = json_encode(array_map(fn($a) => ['@type'=>'Place','name'=>$a], $areas));
  $schema = json_encode([
    '@context'    => 'https://schema.org',
    '@type'       => 'Service',
    'name'        => $sm[0],
    'description' => $sm[1],
    'provider'    => [
      '@type'  => 'ProfessionalService',
      'name'   => 'Qrenzy Digital Solutions',
      'url'    => 'https://www.qrenzy.com',
      'logo'   => 'https://www.qrenzy.com/wp-content/uploads/logo.png',
      'telephone' => '+919905700600',
      'email'  => 'info@qrenzy.com',
      'address'=> ['@type'=>'PostalAddress','addressLocality'=>'Thrissur','addressRegion'=>'Kerala','addressCountry'=>'IN'],
      'sameAs'  => ['https://www.facebook.com/qrenzydigitalsolutions','https://www.instagram.com/qrenzydigitalsolutions','https://www.linkedin.com/company/qrenzy-digital-solutions','https://www.youtube.com/@qrenzydigitalsolutions','https://clutch.co/profile/qrenzy-digital-solutions'],
    ],
    'areaServed'  => json_decode($areas_json),
    'url'         => get_permalink(),
    'image'       => [
      '@type'       => 'ImageObject',
      'url'         => has_post_thumbnail() ? get_the_post_thumbnail_url(null,'qrenzy-featured') : get_template_directory_uri().'/og-service.jpg',
      'width'       => 1200,
      'height'      => 628,
    ],
    'offers'      => [
      '@type'       => 'Offer',
      'priceCurrency' => 'INR',
      'availability'  => 'https://schema.org/InStock',
      'seller'        => ['@type'=>'Organization','name'=>'Qrenzy Digital Solutions'],
    ],
  ], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
?>
<script type="application/ld+json"><?php echo $schema; ?></script>

<?php
// ── BREADCRUMB SCHEMA for service pages ──────────────────────────────
$breadcrumb = json_encode([
  '@context'        => 'https://schema.org',
  '@type'           => 'BreadcrumbList',
  'itemListElement' => [
    ['@type'=>'ListItem','position'=>1,'name'=>'Home','item'=>'https://www.qrenzy.com/'],
    ['@type'=>'ListItem','position'=>2,'name'=>'Services','item'=>'https://www.qrenzy.com/services/'],
    ['@type'=>'ListItem','position'=>3,'name'=>$sm[0],'item'=>get_permalink()],
  ],
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);

// ── REVIEW SCHEMA for service pages ──────────────────────────────────
$review_schema = json_encode([
  '@context' => 'https://schema.org',
  '@type'    => 'Product',
  'name'     => $sm[0] . ' — Qrenzy Digital Solutions',
  'url'      => get_permalink(),
  'brand'    => ['@type'=>'Brand','name'=>'Qrenzy Digital Solutions'],
  'description' => 'Professional ' . $sm[0] . ' services for businesses in India, Oman and UAE by Qrenzy Digital Solutions, Thrissur, Kerala.',
  'aggregateRating' => [
    '@type'       => 'AggregateRating',
    'ratingValue' => '4.9',
    'reviewCount' => '87',
    'bestRating'  => '5',
    'worstRating' => '1',
  ],
  'review' => [
    [
      '@type'        => 'Review',
      'reviewRating' => ['@type'=>'Rating','ratingValue'=>'5','bestRating'=>'5'],
      'author'       => ['@type'=>'Person','name'=>'Ahmed Al Rashidi'],
      'reviewBody'   => 'Qrenzy completely transformed our online presence. Leads increased by 70% in just three months. Their SEO strategy was spot on for the Oman market.',
      'datePublished'=> '2025-11-01',
    ],
    [
      '@type'        => 'Review',
      'reviewRating' => ['@type'=>'Rating','ratingValue'=>'5','bestRating'=>'5'],
      'author'       => ['@type'=>'Person','name'=>'Rajesh Menon'],
      'reviewBody'   => 'We went from zero visibility to Page 1 for our main keywords in Kerala. The team understands local business needs in Thrissur perfectly.',
      'datePublished'=> '2025-10-15',
    ],
  ],
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
?>
<script type="application/ld+json"><?php echo $breadcrumb; ?></script>
<script type="application/ld+json"><?php echo $review_schema; ?></script>
<?php endif; ?>

<div class="breadcrumb"><div class="wrap"><div class="breadcrumb-inner"><ol class="bc-list">
  <li><a href="<?php echo home_url(); ?>">Home</a></li>
  <li class="bc-sep">/</li>
  <li><a href="<?php echo home_url('/services/'); ?>">Services</a></li>
  <li class="bc-sep">/</li>
  <li><?php echo $s['title']; ?></li>
</ol></div></div></div>

<!-- HERO -->
<section style="padding:12px 0 48px;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 400px;gap:56px;align-items:center">
      <div>
        <div class="section-tag" style="display:table;margin-bottom:16px">✦ <?php echo $s['badge']; ?></div>
        <h1 style="font-size:clamp(28px,4.5vw,50px);font-weight:900;color:#0a0a0a;letter-spacing:-0.03em;line-height:1.1;margin-bottom:14px">
          <?php echo $s['title']; ?><br><span style="color:<?php echo $s['color']; ?>"><?php echo $s['tagline']; ?></span>
        </h1>
        <p style="font-size:16px;color:#555;line-height:1.8;margin-bottom:28px;max-width:520px"><?php echo $s['hero_desc']; ?></p>
        <div style="display:flex;gap:12px;flex-wrap:wrap">
          <a href="<?php echo home_url('/free-seo-audit/'); ?>" style="background:<?php echo $s['color']; ?>;color:#fff;padding:14px 26px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none">🔍 Get Free Audit</a>
          <a href="https://api.whatsapp.com/send?phone=919905700600" style="background:#f8f8f6;color:#0a0a0a;padding:14px 26px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none;border:1px solid #e8e8e4" rel="noopener" target="_blank">💬 WhatsApp Us</a>
        </div>
      </div>
      <div>
        <?php if(has_post_thumbnail()): ?>
        <div style="border-radius:20px;overflow:hidden;margin-bottom:16px;aspect-ratio:16/9">
          <?php the_post_thumbnail('qrenzy-featured', ['style'=>'width:100%;height:100%;object-fit:cover;display:block;','loading'=>'lazy','alt'=>esc_attr($s['title'].' — Qrenzy Digital Solutions')]); ?>
        </div>
        <?php endif; ?>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
          <?php foreach($s['stats'] as $st): ?>
          <div style="background:#f8f8f6;border-radius:16px;padding:18px;text-align:center;border:1px solid #e8e8e4">
            <div style="font-size:22px;font-weight:900;color:<?php echo $s['color']; ?>;letter-spacing:-0.03em;line-height:1.1"><?php echo $st[0]; ?></div>
            <div style="font-size:12px;color:#666;margin-top:4px;font-weight:600"><?php echo $st[1]; ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<?php if(!empty($s['problem_solution'])): ?>
<!-- PROBLEM / SOLUTION -->
<section style="padding:0 0 0;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0;border:1px solid #e8e8e4;border-radius:24px;overflow:hidden">

      <!-- THE PROBLEM -->
      <div style="background:#0a0a0a;padding:40px 36px">
        <div style="display:inline-flex;align-items:center;gap:8px;background:rgba(239,68,68,0.15);border:1px solid rgba(239,68,68,0.3);color:#f87171;font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;padding:5px 14px;border-radius:100px;margin-bottom:20px">
          ❌ The Problem
        </div>
        <p style="font-size:16px;color:rgba(255,255,255,0.85);line-height:1.8;margin:0"><?php echo esc_html($s['problem_solution']['problem']); ?></p>
      </div>

      <!-- THE SOLUTION -->
      <div style="background:#fff;padding:40px 36px;border-left:1px solid #e8e8e4">
        <div style="display:inline-flex;align-items:center;gap:8px;background:<?php echo $s['color']; ?>15;border:1px solid <?php echo $s['color']; ?>30;color:<?php echo $s['color']; ?>;font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;padding:5px 14px;border-radius:100px;margin-bottom:20px">
          ✅ Our Solution
        </div>
        <p style="font-size:16px;color:#333;line-height:1.8;margin-bottom:24px"><?php echo esc_html($s['problem_solution']['solution']); ?></p>
        <!-- What's included mini list -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <?php foreach($s['problem_solution']['included'] as $item): ?>
          <div style="display:flex;align-items:center;gap:8px;font-size:13px;color:#444">
            <span style="color:<?php echo $s['color']; ?>;font-size:14px;flex-shrink:0">✓</span>
            <?php echo esc_html($item); ?>
          </div>
          <?php endforeach; ?>
        </div>
        <a href="<?php echo home_url('/free-seo-audit/'); ?>" style="display:inline-flex;align-items:center;gap:8px;background:<?php echo $s['color']; ?>;color:#fff;padding:12px 24px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none;margin-top:24px">Get Started →</a>
      </div>

    </div>
  </div>
</section>
<?php endif; ?>

<?php if(!empty($s['intro_body'])): ?>
<!-- INTRO BODY -->
<section style="padding:64px 0;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 360px;gap:56px;align-items:start">
      <div>
        <?php foreach($s['intro_body'] as $para): ?>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:18px"><?php echo esc_html($para); ?></p>
        <?php endforeach; ?>
      </div>
      <div style="position:sticky;top:100px">
        <div style="background:#f8f8f6;border:1px solid #e8e8e4;border-radius:20px;padding:28px">
          <div style="font-size:13px;font-weight:700;color:<?php echo $s['color']; ?>;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:20px">Quick Facts</div>
          <?php foreach($s['stats'] as $st): ?>
          <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid #e8e8e4">
            <span style="font-size:13px;color:#666"><?php echo esc_html($st[1]); ?></span>
            <span style="font-size:16px;font-weight:900;color:<?php echo $s['color']; ?>"><?php echo esc_html($st[0]); ?></span>
          </div>
          <?php endforeach; ?>
          <a href="<?php echo home_url('/free-seo-audit/'); ?>" style="display:block;background:<?php echo $s['color']; ?>;color:#fff;text-align:center;padding:14px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none;margin-top:20px">Get Free Audit →</a>
        </div>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if(!empty($s['what_is'])): ?>
<!-- WHAT IS SECTION — AI citability definitional block -->
<section style="padding:56px 0;background:#fff;border-top:1px solid #f0f0ed">
  <div class="wrap" style="max-width:860px">
    <h2 style="font-size:clamp(20px,2.8vw,30px);font-weight:900;color:#0a0a0a;margin-bottom:16px;letter-spacing:-0.02em"><?php echo esc_html($s['what_is']['heading']); ?></h2>
    <p style="font-size:15px;color:#444;line-height:1.9;border-left:3px solid <?php echo $s['color']; ?>;padding-left:20px;margin:0"><?php echo esc_html($s['what_is']['answer']); ?></p>
  </div>
</section>
<?php endif; ?>

<!-- INCLUDED -->
<section style="padding:80px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ What's Included</div>
      <h2 class="section-title"><?php echo $s['what_title']; ?></h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px">
      <?php foreach($s['services_list'] as $item): ?>
      <div style="background:#fff;border-radius:20px;padding:26px;border:1px solid #e8e8e4">
        <div style="font-size:30px;margin-bottom:12px"><?php echo $item[0]; ?></div>
        <h3 style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:8px"><?php echo $item[1]; ?></h3>
        <p style="font-size:13px;color:#666;line-height:1.65;margin:0"><?php echo $item[2]; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- RESULTS BAR -->
<section style="padding:44px 0;background:<?php echo $s['color']; ?>">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:repeat(4,1fr);text-align:center">
      <?php foreach($s['results'] as $i=>$r): ?>
      <div style="padding:16px;<?php echo $i<3?'border-right:1px solid rgba(255,255,255,0.2)':''; ?>">
        <div style="font-size:26px;font-weight:900;color:#fff;letter-spacing:-0.03em"><?php echo $r[0]; ?></div>
        <div style="font-size:12px;color:rgba(255,255,255,0.8);margin-top:4px;font-weight:600"><?php echo $r[1]; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PROCESS -->
<section style="padding:80px 0;background:#fff">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ Our Process</div>
      <h2 class="section-title">How We Deliver <?php echo $s['title']; ?> Results</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;max-width:960px;margin:0 auto">
      <?php foreach($s['process'] as $i=>$p): ?>
      <div style="text-align:center;padding:26px 18px;background:#f8f8f6;border-radius:20px;border:1px solid #e8e8e4;position:relative">
        <?php if($i<3): ?><div style="position:absolute;right:-12px;top:42px;font-size:18px;color:#ddd;z-index:1">→</div><?php endif; ?>
        <div style="font-size:11px;font-weight:700;color:<?php echo $s['color']; ?>;letter-spacing:0.08em;text-transform:uppercase;margin-bottom:8px"><?php echo $p[0]; ?></div>
        <h3 style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:8px"><?php echo $p[1]; ?></h3>
        <p style="font-size:13px;color:#666;line-height:1.65;margin:0"><?php echo $p[2]; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php if(!empty($s['who_for'])): ?>
<!-- WHO FOR -->
<section style="padding:72px 0;background:#0a0a0a">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:56px;align-items:start">
      <div>
        <div class="section-tag" style="background:rgba(255,255,255,0.08);border-color:rgba(255,255,255,0.15);color:rgba(255,255,255,0.7)">✦ Is This Right for You?</div>
        <h2 style="font-size:clamp(22px,3vw,34px);font-weight:900;color:#fff;margin:12px 0 16px;letter-spacing:-0.02em;line-height:1.2"><?php echo esc_html($s['who_for']['title']); ?></h2>
        <p style="font-size:15px;color:rgba(255,255,255,0.55);line-height:1.75;margin-bottom:28px"><?php echo esc_html($s['who_for']['desc']); ?></p>
        <a href="<?php echo home_url('/free-seo-audit/'); ?>" style="display:inline-flex;align-items:center;gap:8px;background:<?php echo $s['color']; ?>;color:#fff;padding:13px 24px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none">Start Free Audit →</a>
      </div>
      <div>
        <?php foreach($s['who_for']['list'] as $item): ?>
        <div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:14px;padding:14px 16px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:12px">
          <span style="color:<?php echo $s['color']; ?>;font-size:16px;flex-shrink:0;margin-top:1px">✓</span>
          <span style="font-size:14px;color:rgba(255,255,255,0.7);line-height:1.6"><?php echo esc_html($item); ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if(!empty($s['benefits'])): ?>
<!-- BENEFITS -->
<section style="padding:72px 0;background:#fff">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 12px">✦ Why Choose Qrenzy</div>
      <h2 class="section-title">The Qrenzy Advantage</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px">
      <?php foreach($s['benefits'] as $b): ?>
      <div style="background:#f8f8f6;border:1px solid #e8e8e4;border-radius:20px;padding:26px;border-top:3px solid <?php echo $s['color']; ?>">
        <div style="font-size:28px;margin-bottom:12px"><?php echo $b[0]; ?></div>
        <h3 style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:8px"><?php echo esc_html($b[1]); ?></h3>
        <p style="font-size:13px;color:#666;line-height:1.65;margin:0"><?php echo esc_html($b[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- FAQ -->
<section style="padding:80px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:300px 1fr;gap:56px;align-items:start">
      <div style="position:sticky;top:100px">
        <div class="section-tag" style="display:table;margin-bottom:12px">✦ FAQ</div>
        <h2 style="font-size:clamp(22px,2.5vw,30px);font-weight:900;color:#0a0a0a;margin:0 0 14px;letter-spacing:-0.02em;line-height:1.2">Common Questions About Our <?php echo esc_html($s['title']); ?></h2>
        <p style="font-size:14px;color:#777;line-height:1.7;margin-bottom:24px">Can't find your answer? Talk to us directly.</p>
        <a href="https://api.whatsapp.com/send?phone=919905700600" style="display:inline-flex;align-items:center;gap:8px;background:#25D366;color:#fff;padding:12px 20px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none" rel="noopener" target="_blank">💬 WhatsApp Us</a>
      </div>
      <div>
        <?php
        // FAQ schema
        $faq_schema = ['@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>[]];
        foreach($s['faqs'] as $f):
          $faq_schema['mainEntity'][] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]];
        endforeach;
        echo '<script type="application/ld+json">'.json_encode($faq_schema,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).'</script>';
        ?>
        <?php foreach($s['faqs'] as $fi=>$f): ?>
        <details style="background:#fff;border:1px solid #e8e8e4;border-radius:14px;margin-bottom:10px;overflow:hidden" <?php if($fi===0) echo 'open'; ?>>
          <summary style="padding:18px 22px;font-size:15px;font-weight:700;color:#0a0a0a;cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center;gap:12px">
            <?php echo esc_html($f[0]); ?>
            <span style="font-size:20px;color:<?php echo $s['color']; ?>;flex-shrink:0;line-height:1">+</span>
          </summary>
          <div style="padding:0 22px 18px;font-size:14px;color:#555;line-height:1.8;border-top:1px solid #f0f0ed"><?php echo esc_html($f[1]); ?></div>
        </details>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- OTHER SERVICES + LOCATIONS -->
<section style="padding:64px 0;background:#f8f8f6">
  <div class="wrap">

    <!-- Other Services -->
    <div style="margin-bottom:48px">
      <div style="text-align:center;margin-bottom:24px">
        <div class="section-tag" style="display:table;margin:0 auto 10px">✦ More Services</div>
        <h2 style="font-size:20px;font-weight:800;color:#0a0a0a">Explore Our Other Services</h2>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center">
        <?php
        $all=[
          ['🔍','Search Engine Optimization','search-engine-optimization'],
          ['🌐','Web Design & Development','web-designing'],
          ['📱','Social Media Marketing','social-media-marketing'],
          ['🎯','Performance Marketing','pay-per-click'],
          ['🤖','AI Marketing Automation','ai-marketing-automation'],
          ['📸','Photography & Videography','photography-videography'],
          ['🎨','Graphic Design','graphic-designing'],
          ['💻','Software Solutions','custom-software'],
          ['📍','Local SEO','local-seo'],
        ];
        foreach($all as $a): if($a[2]===$slug) continue; ?>
        <a href="<?php echo home_url('/'.$a[2].'/'); ?>" style="display:inline-flex;align-items:center;gap:8px;padding:10px 16px;background:#fff;border:1px solid #e8e8e4;border-radius:100px;font-size:13px;font-weight:600;color:#333;text-decoration:none;transition:border-color 0.2s" onmouseover="this.style.borderColor='<?php echo $s['color']; ?>'" onmouseout="this.style.borderColor='#e8e8e4'">
          <?php echo $a[0].' '.$a[1]; ?>
        </a>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Locations We Serve -->
    <div style="border-top:1px solid #e8e8e4;padding-top:48px">
      <div style="text-align:center;margin-bottom:24px">
        <div class="section-tag" style="display:table;margin:0 auto 10px">✦ Where We Work</div>
        <h2 style="font-size:20px;font-weight:800;color:#0a0a0a"><?php echo esc_html($s['title']); ?> — Available Across India & the Gulf</h2>
        <p style="font-size:14px;color:#777;margin-top:8px">We deliver <?php echo esc_html($s['title']); ?> for businesses in these markets. Click your location to learn more.</p>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;max-width:900px;margin:0 auto">
        <?php
        $loc_links = [
          ['Thrissur','digital-marketing-agency-thrissur','🇮🇳'],
          ['Kerala','digital-marketing-agency-kerala','🇮🇳'],
          ['Kochi','digital-marketing-agency-kochi','🇮🇳'],
          ['Calicut','digital-marketing-agency-calicut','🇮🇳'],
          ['Trivandrum','digital-marketing-agency-trivandrum','🇮🇳'],
          ['Oman','digital-marketing-agency-oman','🇴🇲'],
          ['UAE','digital-marketing-agency-uae','🇦🇪'],
          ['Dubai','digital-marketing-agency-dubai','🇦🇪'],
          ['Qatar','digital-marketing-agency-qatar','🇶🇦'],
          ['Bahrain','digital-marketing-agency-bahrain','🇧🇭'],
        ];
        foreach($loc_links as $ll): ?>
        <a href="<?php echo home_url('/'.$ll[1].'/'); ?>" style="display:flex;align-items:center;gap:8px;background:#fff;border:1px solid #e8e8e4;border-radius:12px;padding:12px 14px;text-decoration:none;color:#0a0a0a;font-size:13px;font-weight:600;transition:all 0.2s" onmouseover="this.style.borderColor='<?php echo $s['color']; ?>';this.style.color='<?php echo $s['color']; ?>'" onmouseout="this.style.borderColor='#e8e8e4';this.style.color='#0a0a0a'">
          <span style="font-size:16px"><?php echo $ll[2]; ?></span>
          <?php echo $ll[0]; ?>
        </a>
        <?php endforeach; ?>
      </div>
    </div>

  </div>
</section>

<!-- CTA -->
<section class="cta-band"><div class="wrap"><div class="cta-inner">
  <h2>Ready to Get Started<br>with <?php echo $s['title']; ?>?</h2>
  <p>Start with a free consultation — we will show you exactly what we can do for your business.</p>
  <div class="cta-btns">
    <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-white">🔍 Get Free Audit</a>
    <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-outline-white" rel="noopener" target="_blank">💬 WhatsApp Us</a>
  </div>
</div></div></section>

<script>
function toggleFaq(i){
  var b=document.getElementById('fb'+i),ic=document.getElementById('fi'+i);
  if(b.style.display==='none'){b.style.display='block';ic.textContent='−';}
  else{b.style.display='none';ic.textContent='+';}
}
</script>
<style>
@media(max-width:900px){
  [style*="grid-template-columns:1fr 400px"],[style*="grid-template-columns:1fr 360px"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr 1fr!important;}
  [style*="grid-template-columns:repeat(4,1fr)"]{grid-template-columns:1fr 1fr!important;}
  [style*="grid-template-columns:1fr 1fr"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:300px 1fr"]{grid-template-columns:1fr!important;}
  [style*="position:sticky"]{position:static!important;}
}
@media(max-width:600px){[style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr!important;}}
</style>
<?php get_footer(); ?>

<?php
/**
 * Template Name: Why Us
 */
get_header();
?>

<?php
// Breadcrumb
?>
<div class="breadcrumb"><div class="wrap"><div class="breadcrumb-inner">
  <ol class="bc-list">
    <li><a href="<?php echo home_url(); ?>">Home</a></li>
    <li class="bc-sep">/</li>
    <li>Why Choose Qrenzy</li>
  </ol>
</div></div></div>

<style>
/* ── WHY US PAGE ─────────────────────────────────── */
.why-hero { padding: 12px 0 56px; background: #fff; }
.why-tag { display:inline-flex;align-items:center;gap:8px;background:#fff0f0;color:#E31E24;font-size:12px;font-weight:700;padding:6px 16px;border-radius:100px;border:1px solid #ffd5d5;margin-bottom:16px;letter-spacing:.06em;text-transform:uppercase }
.why-h1 { font-size:clamp(32px,5vw,60px);font-weight:900;color:#0a0a0a;line-height:1.05;letter-spacing:-.03em;margin-bottom:16px }
.why-h1 em { color:#E31E24;font-style:normal }
.why-lead { font-size:16px;color:#555;line-height:1.8;max-width:620px;margin-bottom:32px }
.why-hero-grid { display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center }

/* Hero stats strip */
.why-stats-strip { display:flex;gap:0;background:#0a0a0a;border-radius:20px;overflow:hidden;margin-top:48px }
.why-stat-box { flex:1;padding:28px 24px;text-align:center;border-right:1px solid rgba(255,255,255,0.08) }
.why-stat-box:last-child { border-right:none }
.why-stat-n { font-size:clamp(24px,3vw,36px);font-weight:900;color:#E31E24;letter-spacing:-.02em }
.why-stat-l { font-size:12px;color:rgba(255,255,255,.5);font-weight:600;margin-top:4px;line-height:1.4 }

/* Reasons grid */
.why-reasons { padding:72px 0;background:#f8f8f6 }
.why-reasons-grid { display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:40px }
.why-card { background:#fff;border-radius:24px;padding:32px;border:1px solid #e8e8e4;position:relative;overflow:hidden;transition:transform .2s,box-shadow .2s }
.why-card:hover { transform:translateY(-4px);box-shadow:0 16px 48px rgba(227,30,36,0.1) }
.why-card::before { content:'';position:absolute;top:0;left:0;right:0;height:3px;background:#E31E24 }
.why-card-icon { font-size:32px;margin-bottom:16px }
.why-card h3 { font-size:17px;font-weight:800;color:#0a0a0a;margin-bottom:10px;letter-spacing:-.01em }
.why-card p { font-size:13px;color:#666;line-height:1.75;margin:0 }
.why-card-badge { display:inline-block;background:#fff0f0;color:#E31E24;font-size:11px;font-weight:700;padding:4px 10px;border-radius:100px;margin-bottom:12px }

/* Comparison table */
.why-compare { padding:72px 0;background:#fff }
.why-table { width:100%;border-collapse:collapse;margin-top:40px;border-radius:20px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.06) }
.why-table th { padding:18px 24px;font-size:13px;font-weight:800;letter-spacing:.05em;text-transform:uppercase }
.why-table th:first-child { background:#f8f8f6;color:#888;text-align:left }
.why-table th.col-them { background:#f8f8f6;color:#aaa;text-align:center }
.why-table th.col-us { background:#E31E24;color:#fff;text-align:center }
.why-table td { padding:16px 24px;border-top:1px solid #f0f0ee;font-size:14px }
.why-table td:first-child { color:#444;font-weight:500 }
.why-table td.col-them { text-align:center;color:#aaa }
.why-table td.col-us { text-align:center;background:#fff8f8 }
.why-table tr:hover td { background:#fafafa }
.why-table tr:hover td.col-us { background:#fff0f0 }
.check { color:#22c55e;font-size:18px }
.cross { color:#ddd;font-size:18px }

/* Process */
.why-process { padding:72px 0;background:#0a0a0a }
.why-process-steps { display:grid;grid-template-columns:repeat(5,1fr);gap:0;margin-top:48px;position:relative }
.why-process-steps::before { content:'';position:absolute;top:32px;left:10%;right:10%;height:2px;background:linear-gradient(to right,#E31E24,#ff6b6b,#E31E24);z-index:0 }
.why-step { text-align:center;position:relative;z-index:1 }
.why-step-num { width:64px;height:64px;background:#E31E24;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:900;color:#fff;margin:0 auto 16px;border:4px solid #0a0a0a }
.why-step h4 { font-size:13px;font-weight:800;color:#fff;margin-bottom:6px }
.why-step p { font-size:11px;color:rgba(255,255,255,.4);line-height:1.5;max-width:100px;margin:0 auto }

/* Testimonials */
.why-testi { padding:72px 0;background:#f8f8f6 }
.why-testi-grid { display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:40px }
.why-testi-card { background:#fff;border-radius:20px;padding:28px;border:1px solid #e8e8e4 }
.why-testi-quote { font-size:14px;color:#333;line-height:1.8;margin-bottom:20px;position:relative;padding-top:24px }
.why-testi-quote::before { content:'"';position:absolute;top:0;left:0;font-size:40px;color:#E31E24;line-height:1;font-family:Georgia,serif }
.why-testi-name { font-size:13px;font-weight:800;color:#0a0a0a }
.why-testi-role { font-size:11px;color:#999;margin-top:2px }
.why-testi-stars { color:#f59e0b;font-size:14px;margin-bottom:12px }

/* ── LOCATION LINKS SECTION ── */
.why-locations { padding:72px 0;background:#fff }
.loc-links-intro { max-width:640px;margin-bottom:48px }
.loc-links-grid { display:grid;grid-template-columns:repeat(2,1fr);gap:32px }
.loc-links-col h4 { font-size:11px;font-weight:800;color:#999;text-transform:uppercase;letter-spacing:.1em;margin-bottom:16px;display:flex;align-items:center;gap:8px }
.loc-links-col h4::after { content:'';flex:1;height:1px;background:#e8e8e4 }
.loc-link-card { display:flex;align-items:center;gap:14px;padding:14px 18px;border-radius:14px;border:1px solid #e8e8e4;text-decoration:none;margin-bottom:10px;transition:all .2s;background:#fff }
.loc-link-card:hover { border-color:#E31E24;background:#fff8f8;transform:translateX(4px) }
.loc-link-flag { font-size:22px;flex-shrink:0 }
.loc-link-text { flex:1 }
.loc-link-city { font-size:14px;font-weight:800;color:#0a0a0a;display:block }
.loc-link-desc { font-size:12px;color:#888;margin-top:2px }
.loc-link-arrow { color:#E31E24;font-size:14px;font-weight:700 }

/* ── RESPONSIVE ── */
@media(max-width:900px){
  .why-hero-grid { grid-template-columns:1fr }
  .why-reasons-grid { grid-template-columns:1fr 1fr }
  .why-process-steps { grid-template-columns:1fr 1fr;gap:24px }
  .why-process-steps::before { display:none }
  .why-testi-grid { grid-template-columns:1fr 1fr }
  .why-stats-strip { flex-wrap:wrap }
  .why-stat-box { flex:1 1 40% }
  .loc-links-grid { grid-template-columns:1fr }
}
@media(max-width:600px){
  .why-reasons-grid,.why-testi-grid { grid-template-columns:1fr }
  .why-table { font-size:12px }
  .why-table th,.why-table td { padding:12px 14px }
  .why-process-steps { grid-template-columns:1fr 1fr }
  .why-stat-box { flex:1 1 45% }
}
</style>

<!-- ── HERO ───────────────────────────────────────────────── -->
<section class="why-hero">
  <div class="wrap">
    <div class="why-hero-grid">
      <div>
        <div class="why-tag">✦ Why Qrenzy</div>
        <h1 class="why-h1">Not Just Another<br>Agency. <em>Your Growth<br>Partner.</em></h1>
        <p class="why-lead">Hundreds of digital agencies promise results. We deliver them — with 18+ years of hands-on experience, AI-powered strategies, and a team that treats your business like our own.</p>
        <div style="display:flex;gap:12px;flex-wrap:wrap">
          <a href="<?php echo home_url('/free-seo-audit/'); ?>" style="background:#E31E24;color:#fff;padding:14px 28px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none">🔍 Get Free SEO Audit →</a>
          <a href="https://api.whatsapp.com/send?phone=919905700600" style="background:#f8f8f6;color:#0a0a0a;padding:14px 24px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none;border:1px solid #e8e8e4" rel="noopener" target="_blank">💬 WhatsApp Us</a>
        </div>
      </div>
      <!-- Right: Quick trust visual -->
      <div style="background:#f8f8f6;border-radius:24px;padding:32px;border:1px solid #e8e8e4">
        <?php
        $trust = [
          ['🏆','Clutch Verified Agency','Top Digital Marketing Agency — Kerala 2024'],
          ['⚡','AI-First Approach','GPT-4 + Automation tools built into every campaign'],
          ['🌍','3 Countries Active','India • Oman • UAE — Gulf-tested strategies'],
          ['📊','Full Transparency','Weekly reports, live dashboards, zero guesswork'],
          ['🤝','Dedicated Manager','One point of contact, always available for you'],
          ['🔁','No Lock-in Contracts','Month-to-month — we earn your trust every month'],
        ];
        foreach($trust as $t): ?>
        <div style="display:flex;gap:14px;align-items:flex-start;padding:12px 0;border-bottom:1px solid #f0f0ee">
          <span style="font-size:22px;flex-shrink:0"><?php echo $t[0]; ?></span>
          <div>
            <div style="font-size:13px;font-weight:800;color:#0a0a0a"><?php echo $t[1]; ?></div>
            <div style="font-size:12px;color:#888;margin-top:2px"><?php echo $t[2]; ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Stats strip -->
    <div class="why-stats-strip">
      <?php
      $stats = [
        ['200+','Happy Clients','India & Gulf'],
        ['18+','Years Experience','Since 2006'],
        ['5,200+','Keywords Ranked','Across all clients'],
        ['4.8×','Average ROAS','Google & Meta'],
        ['4.9★','Client Rating','Clutch & Google'],
      ];
      foreach($stats as $s): ?>
      <div class="why-stat-box">
        <div class="why-stat-n"><?php echo $s[0]; ?></div>
        <div class="why-stat-l"><?php echo $s[1]; ?><br><?php echo $s[2]; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── ABOUT BODY ───────────────────────────────────────────── -->
<section style="padding:72px 0;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:start">
      <div>
        <div class="why-tag" style="display:table">✦ Our Story</div>
        <h2 style="font-size:clamp(24px,3.5vw,38px);font-weight:900;color:#0a0a0a;margin:12px 0 20px;letter-spacing:-0.02em;line-height:1.2">Built in Thrissur. Trusted Across India & the Gulf.</h2>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:16px">Qrenzy Digital Solutions was founded in Thrissur, Kerala in 2020 — not as another generic digital marketing agency, but with a specific mission: to give small and medium businesses in India and the Gulf the same quality of digital marketing strategy that large corporations receive. We have grown to serve 200+ clients across Kerala, Oman, UAE, Qatar and Bahrain while remaining true to that founding mission.</p>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:16px">Our founding team brings 18+ years of combined hands-on experience across IT infrastructure, SEO, web development, social media marketing, performance advertising and AI marketing automation. This is not theoretical knowledge — it is practical, client-tested expertise built through hundreds of real campaigns across diverse industries and markets. We have ranked websites, managed ad budgets, built automations, shot videos and designed brands — all from within our team, not outsourced.</p>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:16px">What makes Qrenzy genuinely different is our dual-market position. Most agencies serve either India or the Gulf. We serve both simultaneously, and the crossover expertise this creates is uniquely valuable for clients in either market. We understand how Kerala businesses target Gulf NRI customers. We understand how Gulf-based companies with Indian ownership navigate marketing to both local and expatriate audiences. This India-Gulf marketing intelligence is built into everything we do.</p>
        <p style="font-size:15px;color:#444;line-height:1.85">We were also among the first agencies in Kerala to build genuine AI-powered marketing workflows for clients — not as a marketing claim, but as a practical operational reality. AI tools are integrated into our content creation, campaign optimization, lead automation and reporting systems. The result is faster execution, higher output quality and better results for clients at every budget level.</p>
      </div>
      <div>
        <div style="background:#f8f8f6;border-radius:20px;padding:32px;margin-bottom:20px;border:1px solid #e8e8e4">
          <div style="font-size:13px;font-weight:700;color:#E31E24;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:20px">Qrenzy By The Numbers</div>
          <?php
          $numbers = [
            ['200+','Businesses Served','Across India, Oman, UAE, Qatar & Bahrain'],
            ['18+','Years Combined Experience','Digital marketing, IT & multimedia'],
            ['5,200+','Keywords Ranked','On Google Page 1 for clients'],
            ['4.8×','Average ROAS','Across all active ad campaigns'],
            ['4.9★','Client Rating','Average across Clutch & Google reviews'],
            ['90 Days','Average to Results','From onboarding to measurable ROI'],
            ['48 hrs','Campaign Launch Speed','From strategy approval to live'],
            ['5','Countries Active','India, Oman, UAE, Qatar, Bahrain'],
          ];
          foreach($numbers as $n): ?>
          <div style="display:flex;justify-content:space-between;align-items:center;padding:11px 0;border-bottom:1px solid #e8e8e4">
            <div>
              <div style="font-size:12px;font-weight:700;color:#0a0a0a"><?php echo esc_html($n[1]); ?></div>
              <div style="font-size:11px;color:#888;margin-top:1px"><?php echo esc_html($n[2]); ?></div>
            </div>
            <div style="font-size:18px;font-weight:900;color:#E31E24;letter-spacing:-0.02em"><?php echo esc_html($n[0]); ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ── WHAT WE BELIEVE ──────────────────────────────────────── -->
<section style="padding:72px 0;background:#0a0a0a">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="why-tag" style="display:table;margin:0 auto 12px;background:rgba(227,30,36,0.15);border-color:rgba(227,30,36,0.3)">✦ Our Philosophy</div>
      <h2 style="font-size:clamp(24px,3.5vw,38px);font-weight:900;color:#fff;margin:0;letter-spacing:-0.02em">What We Believe About Digital Marketing</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px">
      <?php
      $beliefs = [
        ['📊','Transparency Over Everything','You should know exactly what your digital marketing investment is doing — every rupee, every keyword, every lead. We believe in full visibility, monthly reports and honest conversations when something is not working.'],
        ['🏗️','Strategy Before Tactics','Most agencies jump straight to posting and advertising. We start with a clear strategy — understanding your market, your customers and your competitive position before recommending a single tactic.'],
        ['🌱','Long-Term Over Short-Term','We build digital assets that compound over time — SEO authority, brand recognition, content libraries. We resist shortcuts that deliver quick wins but create long-term problems.'],
        ['🎯','Results Over Relationships','We are not the agency that sends you a nice monthly report full of impressions and reach while your business is not growing. We are the agency that has an uncomfortable conversation when strategy needs to change.'],
        ['🤝','Partnership Over Transactions','Our best client relationships are partnerships — where we understand your business deeply enough to make strategic recommendations, not just execute tasks. We want to grow with you, not just serve you.'],
        ['🔬','Test, Learn, Optimize','Digital marketing is not a set-it-and-forget-it exercise. We test hypotheses, analyse results and optimize continuously. What works in month one may not be what works in month six. We adapt.'],
      ];
      foreach($beliefs as $b): ?>
      <div style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:28px">
        <div style="font-size:28px;margin-bottom:12px"><?php echo $b[0]; ?></div>
        <h3 style="font-size:15px;font-weight:800;color:#fff;margin-bottom:10px"><?php echo esc_html($b[1]); ?></h3>
        <p style="font-size:13px;color:rgba(255,255,255,0.55);line-height:1.7;margin:0"><?php echo esc_html($b[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── 9 REASONS ──────────────────────────────────────────── -->
<section class="why-reasons">
  <div class="wrap">
    <div class="why-tag">✦ The Qrenzy Difference</div>
    <h2 style="font-size:clamp(26px,4vw,44px);font-weight:900;color:#0a0a0a;margin:12px 0 0;letter-spacing:-.02em">9 Reasons Businesses Choose Us<br><em style="color:#E31E24;font-style:normal">Over Everyone Else</em></h2>
    <div class="why-reasons-grid">
      <?php
      $reasons = [
        ['🎯','Hook-Based Strategy','We lead with conversion psychology — every headline, CTA and landing page is engineered to capture attention and drive action.',  'Conversion-First'],
        ['🤖','AI-Powered Execution','From content creation to ad optimization, we use AI tools daily — cutting costs and accelerating results for our clients.', 'AI Tools Daily'],
        ['📍','Local Market Expertise','We know Thrissur, Kochi, Oman and UAE markets inside out. No generic campaigns — hyper-local targeting that converts.', 'Hyper-Local'],
        ['📊','Data-Driven Decisions','Every campaign decision is backed by real data. We track, test and optimize weekly — not monthly.', 'Weekly Optimization'],
        ['🌐','Full-Service Under One Roof','SEO, paid ads, social media, web design, AI automation — all in one agency. No vendor juggling.', 'One Agency'],
        ['⚡','Fast Onboarding','From signup to live campaign in 48 hours. We move fast because your business can\'t afford to wait.', '48hr Launch'],
        ['🔍','Free SEO Audit First','Every client relationship starts with a free, no-obligation SEO audit — so you see exactly what\'s holding you back.', 'Free Audit'],
        ['💬','Real Human Support','No bots, no ticket systems. Direct access to your account manager on WhatsApp — always.', 'WhatsApp Access'],
        ['📈','Results or Refund Mindset','We don\'t hide behind vanity metrics. If we commit to results, we back it up with transparent reporting.', 'Full Transparency'],
      ];
      foreach($reasons as $r): ?>
      <div class="why-card">
        <div class="why-card-badge"><?php echo $r[3]; ?></div>
        <div class="why-card-icon"><?php echo $r[0]; ?></div>
        <h3><?php echo $r[1]; ?></h3>
        <p><?php echo $r[2]; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── COMPARISON TABLE ───────────────────────────────────── -->
<section class="why-compare">
  <div class="wrap">
    <div class="why-tag">✦ Side by Side</div>
    <h2 style="font-size:clamp(26px,4vw,44px);font-weight:900;color:#0a0a0a;margin:12px 0 0;letter-spacing:-.02em">Qrenzy vs <em style="color:#E31E24;font-style:normal">Other Agencies</em></h2>
    <p style="font-size:15px;color:#666;margin-top:8px">See why growing businesses switch to Qrenzy</p>
    <table class="why-table">
      <thead>
        <tr>
          <th>Feature</th>
          <th class="col-them">Typical Agency</th>
          <th class="col-us">Qrenzy ✦</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $rows = [
          ['AI-Powered Campaigns', false, true],
          ['Dedicated Account Manager', false, true],
          ['Free SEO Audit Before Start', false, true],
          ['No Lock-in Contracts', false, true],
          ['WhatsApp Direct Access', false, true],
          ['Weekly Reporting', false, true],
          ['Local Kerala & Gulf Market Knowledge', false, true],
          ['Full-Service (SEO + Ads + Social + Web)', false, true],
          ['48hr Campaign Launch', false, true],
          ['Transparent Pricing', false, true],
        ];
        foreach($rows as $row): ?>
        <tr>
          <td><?php echo $row[0]; ?></td>
          <td class="col-them"><?php echo $row[1] ? '<span class="check">✓</span>' : '<span class="cross">✗</span>'; ?></td>
          <td class="col-us"><?php echo $row[2] ? '<span class="check">✓</span>' : '<span class="cross">✗</span>'; ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>

<!-- ── PROCESS ────────────────────────────────────────────── -->
<section class="why-process">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:0">
      <div class="why-tag" style="background:rgba(227,30,36,0.15);border-color:rgba(227,30,36,0.3)">✦ How We Work</div>
      <h2 style="font-size:clamp(26px,4vw,44px);font-weight:900;color:#fff;margin:12px 0 0;letter-spacing:-.02em">From <em style="color:#E31E24;font-style:normal">Hello</em> to Results<br>in 5 Simple Steps</h2>
    </div>
    <div class="why-process-steps">
      <?php
      $steps = [
        ['01','Free Audit','We analyse your website, competitors & market — at zero cost.'],
        ['02','Strategy Call','30-minute call to align on goals, budget & timeline.'],
        ['03','Custom Plan','Tailored strategy built for your market — Kerala, Gulf or global.'],
        ['04','Launch Fast','Campaign live within 48 hours of approval.'],
        ['05','Grow & Scale','Weekly reports, ongoing optimization and continuous growth.'],
      ];
      foreach($steps as $s): ?>
      <div class="why-step">
        <div class="why-step-num"><?php echo $s[0]; ?></div>
        <h4><?php echo $s[1]; ?></h4>
        <p><?php echo $s[2]; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── TESTIMONIALS ───────────────────────────────────────── -->
<section class="why-testi">
  <div class="wrap">
    <div class="why-tag">✦ Client Stories</div>
    <h2 style="font-size:clamp(26px,4vw,44px);font-weight:900;color:#0a0a0a;margin:12px 0 40px;letter-spacing:-.02em">Don't Take Our Word For It</h2>
    <div class="why-testi-grid">
      <?php
      $testimonials = [
        ['Qrenzy took our Thrissur jewellery business from zero online presence to ranking #1 for 15 keywords in 4 months. The ROI has been incredible.', 'Rajesh Menon', 'Jewellery Business Owner, Thrissur', '★★★★★'],
        ['As an Oman-based company, we needed an agency that understood both Indian and Gulf markets. Qrenzy nailed it — bilingual campaigns, local insights, real results.', 'Ahmed Al Rashdi', 'Trading Company, Muscat', '★★★★★'],
        ['The WhatsApp direct access is a game changer. I message my account manager anytime and get a response within hours. No other agency does this.', 'Priya Thomas', 'E-commerce Brand, Kochi', '★★★★★'],
        ['We tried 3 agencies before Qrenzy. Nobody else gave us a free audit first, laid out a clear strategy, and then actually delivered.', 'Suresh Kumar', 'Healthcare Clinic, Calicut', '★★★★★'],
        ['Our Google Ads ROAS went from 1.8x to 4.9x in 60 days. The AI-optimized targeting Qrenzy uses is genuinely different from what we had before.', 'Sarah Al Dhaheri', 'Retail Brand, Dubai', '★★★★★'],
        ['Qrenzy built our website and managed our SEO simultaneously. Launching in 48 hours and ranking in 90 days — that kind of speed is rare.', 'Mohammed Basheer', 'Restaurant Chain, Bahrain', '★★★★★'],
      ];
      foreach($testimonials as $t): ?>
      <div class="why-testi-card">
        <div class="why-testi-stars"><?php echo $t[3]; ?></div>
        <div class="why-testi-quote"><?php echo $t[0]; ?></div>
        <div class="why-testi-name"><?php echo $t[1]; ?></div>
        <div class="why-testi-role"><?php echo $t[2]; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── LOCATION LINKS — INTERNAL LINKING ─────────────────── -->
<section class="why-locations">
  <div class="wrap">
    <div class="why-tag">✦ We Serve These Markets</div>
    <div class="loc-links-intro">
      <h2 style="font-size:clamp(26px,4vw,44px);font-weight:900;color:#0a0a0a;margin:12px 0 12px;letter-spacing:-.02em">Digital Marketing Services<br><em style="color:#E31E24;font-style:normal">Near You</em></h2>
      <p style="font-size:15px;color:#666;line-height:1.75">We operate across India and the Gulf with market-specific strategies for each location. Click your city or country to see how we can help your local business grow.</p>
    </div>

    <div class="loc-links-grid">
      <!-- India -->
      <div class="loc-links-col">
        <h4>🇮🇳 India — Cities</h4>
        <?php
        $india_locs = [
          ['/digital-marketing-agency-thrissur/', 'Thrissur', 'Our home base — Kerala\'s cultural capital', '🏠'],
          ['/digital-marketing-agency-kerala/', 'Kerala', 'Full Kerala coverage across all 14 districts', '🌴'],
          ['/digital-marketing-agency-kochi/', 'Kochi', 'Kerala\'s commercial & IT hub', '🏙️'],
          ['/digital-marketing-agency-calicut/', 'Calicut', 'Malabar\'s business capital', '🕌'],
          ['/digital-marketing-agency-trivandrum/', 'Trivandrum', 'Kerala\'s capital & Technopark hub', '🏛️'],
        ];
        foreach($india_locs as $l): ?>
        <a href="<?php echo home_url($l[0]); ?>" class="loc-link-card">
          <span class="loc-link-flag"><?php echo $l[3]; ?></span>
          <span class="loc-link-text">
            <span class="loc-link-city">Digital Marketing Agency in <?php echo $l[1]; ?></span>
            <span class="loc-link-desc"><?php echo $l[2]; ?></span>
          </span>
          <span class="loc-link-arrow">→</span>
        </a>
        <?php endforeach; ?>
      </div>

      <!-- Gulf -->
      <div class="loc-links-col">
        <h4>🌍 Gulf — Countries & Cities</h4>
        <?php
        $gulf_locs = [
          ['/digital-marketing-agency-oman/', 'Oman', 'Vision 2040-ready digital strategies', '🇴🇲'],
          ['/digital-marketing-agency-uae/', 'UAE', 'Dubai, Abu Dhabi & all emirates', '🇦🇪'],
          ['/digital-marketing-agency-dubai/', 'Dubai', 'UAE\'s most competitive digital market', '🏗️'],
          ['/digital-marketing-agency-bahrain/', 'Bahrain', 'Fintech & retail growth campaigns', '🇧🇭'],
          ['/digital-marketing-agency-qatar/', 'Qatar', 'Post-World Cup digital boom', '🇶🇦'],
        ];
        foreach($gulf_locs as $l): ?>
        <a href="<?php echo home_url($l[0]); ?>" class="loc-link-card">
          <span class="loc-link-flag"><?php echo $l[3]; ?></span>
          <span class="loc-link-text">
            <span class="loc-link-city">Digital Marketing Agency in <?php echo $l[1]; ?></span>
            <span class="loc-link-desc"><?php echo $l[2]; ?></span>
          </span>
          <span class="loc-link-arrow">→</span>
        </a>
        <?php endforeach; ?>
      </div>
    </div>

    <div style="margin-top:40px;text-align:center;padding:32px;background:#f8f8f6;border-radius:24px;border:1px solid #e8e8e4">
      <p style="font-size:15px;color:#555;margin-bottom:16px">Don't see your city? We work with businesses <strong>worldwide.</strong></p>
      <a href="<?php echo home_url('/contact/'); ?>" style="background:#E31E24;color:#fff;padding:14px 32px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none;display:inline-block">📩 Get in Touch →</a>
    </div>
  </div>
</section>

<!-- ── FINAL CTA ──────────────────────────────────────────── -->
<section class="cta-band">
  <div class="wrap"><div class="cta-inner">
    <h2>Ready to See Why 200+ Businesses<br>Trust Qrenzy?</h2>
    <p>Start with a free audit. No credit card. No commitment. Just results.</p>
    <div class="cta-btns">
      <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-white">🔍 Free SEO Audit</a>
      <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-outline-white" rel="noopener" target="_blank">💬 WhatsApp Now</a>
    </div>
  </div></div>
</section>

<!-- JSON-LD -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {"@type":"Question","name":"Why should I choose Qrenzy over other digital marketing agencies?","acceptedAnswer":{"@type":"Answer","text":"Qrenzy combines 18+ years of experience with AI-powered tools, no lock-in contracts, free SEO audits and direct WhatsApp access to your account manager — delivering transparent, results-driven digital marketing across India, Oman and UAE."}},
    {"@type":"Question","name":"How fast can Qrenzy launch my campaign?","acceptedAnswer":{"@type":"Answer","text":"From strategy approval to live campaign in 48 hours. We move fast because your business can't afford to wait."}},
    {"@type":"Question","name":"Does Qrenzy serve businesses outside Kerala?","acceptedAnswer":{"@type":"Answer","text":"Yes. We actively serve clients in Oman, UAE, Bahrain, Qatar and worldwide, with market-specific strategies for each location."}}
  ]
}
</script>
<style>
@media(max-width:900px){
  [style*="grid-template-columns:1fr 1fr"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr 1fr!important;}
  [style*="position:sticky"]{position:static!important;}
}
@media(max-width:600px){
  [style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr!important;}
}
</style>
<?php get_footer(); ?>

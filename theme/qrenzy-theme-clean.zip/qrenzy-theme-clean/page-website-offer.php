<?php
/**
 * Template Name: Landing Page — Website Offer
 * Template Post Type: page
 */
get_header();
?>

<!-- ANNOUNCEMENT STRIP -->
<div style="background:#E31E24;padding:10px 0;text-align:center">
  <p style="font-size:13px;color:#fff;font-weight:600;margin:0">
    🔥 Limited Offer — <strong>Professional Website Starting from ₹10,000</strong> — Hosting & Domain Included · SEO Ready · Delivered in 2 Weeks
  </p>
</div>

<!-- HERO -->
<section class="hero-section" style="padding:48px 0 64px">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 440px;gap:64px;align-items:center">

      <!-- Left -->
      <div>
        <div class="section-tag" style="display:table;margin-bottom:18px">🚀 Special Offer — Limited Time</div>
        <h1 class="hero-title" style="font-size:clamp(32px,4.5vw,56px);font-weight:900;color:#0a0a0a;letter-spacing:-0.03em;line-height:1.1;margin-bottom:20px">
          Your Business Deserves a<br><span class="red">Website That Actually Works.</span>
        </h1>
        <p style="font-size:17px;color:#555;line-height:1.75;margin-bottom:32px;max-width:480px">
          Get a professionally designed, lightning-fast, SEO-ready website — with hosting and domain included. Built for service providers and small business owners. No shortcuts. No hidden charges.
        </p>

        <!-- Price -->
        <div style="display:inline-flex;align-items:baseline;gap:4px;background:#f8f8f6;border:1px solid #e8e8e4;border-radius:16px;padding:16px 24px;margin-bottom:28px">
          <span style="font-size:22px;font-weight:700;color:#888;align-self:flex-start;margin-top:6px">₹</span>
          <span style="font-size:56px;font-weight:900;color:#0a0a0a;letter-spacing:-0.04em;line-height:1">10,000</span>
          <div style="display:flex;flex-direction:column;margin-left:8px">
            <span style="font-size:13px;color:#E31E24;font-weight:700">Starting Price</span>
            <span style="font-size:12px;color:#888">Hosting & Domain Included</span>
          </div>
        </div>

        <!-- CTAs -->
        <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:24px">
          <a href="#get-quote" class="btn-primary">🚀 Get Free Quote →</a>
          <a href="https://api.whatsapp.com/send?phone=919905700600&text=Hi+Sajeesh,+I+saw+your+website+offer+and+I+am+interested" style="display:inline-flex;align-items:center;gap:8px;background:#25D366;color:#fff;border-radius:100px;padding:15px 24px;font-size:15px;font-weight:700;text-decoration:none" target="_blank" rel="noopener">💬 WhatsApp Us</a>
        </div>

        <!-- Trust signals -->
        <div style="display:flex;gap:20px;flex-wrap:wrap">
          <?php foreach(['5 Pages Included','Hosting & Domain Included','Delivered in 2 Weeks','Free SEO Setup'] as $t): ?>
          <div style="display:flex;align-items:center;gap:6px;font-size:13px;color:#555;font-weight:500">
            <span style="color:#22c55e;font-size:15px">✓</span><?php echo $t; ?>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Right — Scores card -->
      <div style="background:#0a0a0a;border-radius:24px;padding:36px;position:relative;overflow:hidden">
        <div style="position:absolute;top:-60px;right:-60px;width:200px;height:200px;background:radial-gradient(circle,rgba(227,30,36,0.2) 0%,transparent 70%);pointer-events:none"></div>
        <div style="font-size:12px;font-weight:700;color:rgba(255,255,255,0.4);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:20px">Google Lighthouse Scores</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:28px">
          <?php
          $scores = [['97','Performance','#E31E24'],['100','SEO','#22c55e'],['100','Best Practices','#3b82f6'],['96','Accessibility','#f59e0b']];
          foreach($scores as $sc): ?>
          <div style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:14px;padding:16px;text-align:center;border-top:3px solid <?php echo $sc[2]; ?>">
            <div style="font-size:32px;font-weight:900;color:<?php echo $sc[2]; ?>;letter-spacing:-0.03em;line-height:1"><?php echo $sc[0]; ?></div>
            <div style="font-size:11px;color:rgba(255,255,255,0.5);font-weight:600;margin-top:4px"><?php echo $sc[1]; ?></div>
          </div>
          <?php endforeach; ?>
        </div>
        <div style="background:rgba(227,30,36,0.1);border:1px solid rgba(227,30,36,0.2);border-radius:12px;padding:14px;text-align:center">
          <div style="font-size:13px;color:rgba(255,255,255,0.7);line-height:1.5">This is what we build for every client.<br><strong style="color:#fff">Your website will score the same.</strong></div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- WHAT'S INCLUDED -->
<section style="padding:72px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ What You Get</div>
      <h2 class="section-title" style="text-align:center">Everything Included at ₹10,000</h2>
      <p class="section-desc" style="text-align:center;margin:10px auto 0">No hidden charges. No monthly fees. One price — complete website.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:40px">
      <?php
      $included = [
        ['📄','5 Custom Pages','Home, About, Services, Contact + 1 page of your choice — designed specifically for your business.'],
        ['🌐','Hosting & Domain Included','Free .in or .com domain + 1 year hosting included. Other domains priced by availability. Annual renewal charges apply.'],
        ['⚡','PageSpeed 90+ Guaranteed','Optimized images, caching and CDN setup. Your website loads in under 2 seconds — guaranteed or we fix it.'],
        ['🔍','Basic SEO Setup','Meta titles, descriptions, sitemap, schema markup and Google Search Console connection from day one.'],
        ['📱','Mobile-First Design','Built for mobile screens first. Looks perfect on every device — phone, tablet and desktop.'],
        ['📍','Google Business Profile','Setup or optimization of your Google Maps listing — so customers can find and call you directly.'],
      ];
      foreach($included as $inc): ?>
      <div style="background:#fff;border:1px solid #e8e8e4;border-radius:20px;padding:24px;border-top:3px solid #E31E24;transition:box-shadow 0.2s" onmouseover="this.style.boxShadow='0 12px 40px rgba(0,0,0,0.08)'" onmouseout="this.style.boxShadow='none'">
        <div style="font-size:28px;margin-bottom:12px"><?php echo $inc[0]; ?></div>
        <h3 style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:8px"><?php echo $inc[1]; ?></h3>
        <p style="font-size:13px;color:#666;line-height:1.65;margin:0"><?php echo $inc[2]; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center"><a href="#get-quote" class="btn-primary">Get Started for ₹10,000 →</a></div>
  </div>
</section>

<!-- PROBLEM / SOLUTION -->
<section style="padding:72px 0;background:#0a0a0a">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:40px">
      <div class="section-tag" style="display:table;margin:0 auto 14px;background:rgba(227,30,36,0.15);border-color:rgba(227,30,36,0.3);color:#E31E24">✦ Does This Sound Familiar?</div>
      <h2 style="font-size:clamp(26px,3.5vw,40px);font-weight:900;color:#fff;letter-spacing:-0.025em;line-height:1.15">Most Small Business Websites<br>Are Losing Customers Every Day</h2>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0;border-radius:24px;overflow:hidden;border:1px solid rgba(255,255,255,0.08)">
      <!-- Problem -->
      <div style="background:rgba(239,68,68,0.07);padding:40px 36px;border-right:1px solid rgba(255,255,255,0.08)">
        <div style="display:inline-flex;align-items:center;gap:6px;background:rgba(239,68,68,0.15);border:1px solid rgba(239,68,68,0.3);color:#f87171;font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;padding:5px 14px;border-radius:100px;margin-bottom:20px">❌ The Problem</div>
        <h3 style="font-size:17px;font-weight:800;color:#fff;margin-bottom:20px;line-height:1.3">Your website is working against you</h3>
        <?php
        $problems = ['Your website is slow — visitors leave before it loads','It doesn\'t work properly on mobile phones','Google can\'t find you — you\'re invisible in search','It looks outdated and unprofessional','You paid a lot for it and it\'s still not working'];
        foreach($problems as $p): ?>
        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:12px">
          <span style="font-size:15px;flex-shrink:0">😤</span>
          <span style="font-size:14px;color:rgba(255,255,255,0.65);line-height:1.5"><?php echo esc_html($p); ?></span>
        </div>
        <?php endforeach; ?>
      </div>
      <!-- Solution -->
      <div style="background:rgba(255,255,255,0.03);padding:40px 36px">
        <div style="display:inline-flex;align-items:center;gap:6px;background:rgba(34,197,94,0.15);border:1px solid rgba(34,197,94,0.3);color:#4ade80;font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;padding:5px 14px;border-radius:100px;margin-bottom:20px">✅ Our Solution</div>
        <h3 style="font-size:17px;font-weight:800;color:#fff;margin-bottom:20px;line-height:1.3">A website that actually works for your business</h3>
        <?php
        $solutions = ['Loads in under 2 seconds — 97/100 performance score','Mobile-first design — perfect on every device','SEO setup from day one — Google finds you immediately','Clean, modern design that builds customer trust','Complete package — just ₹10,000, no hidden costs'];
        foreach($solutions as $s): ?>
        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:12px">
          <span style="font-size:15px;flex-shrink:0">✅</span>
          <span style="font-size:14px;color:rgba(255,255,255,0.65);line-height:1.5"><?php echo esc_html($s); ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section style="padding:72px 0;background:#fff">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ Real Results</div>
      <h2 class="section-title" style="text-align:center">What Our Clients Say</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px">
      <?php
      $testimonials = [
        ['RK','Rajesh Kumar','Interior Design, Kochi','★★★★★','Qrenzy built our website in just 10 days. It loads incredibly fast and we started getting enquiries from Google within weeks. Best investment we made.'],
        ['AS','Anisha Sharma','Boutique Owner, Calicut','★★★★★','Finally a website that looks as good as our services. Sajeesh understood exactly what we needed. The Google Business Profile setup alone doubled our calls.'],
        ['MF','Mohammed Farhan','Trading Company, Muscat','★★★★★','We were paying ₹25,000 to another agency and getting nothing. Qrenzy delivered a better website at ₹10,000 that actually ranks on Google. Highly recommended.'],
      ];
      foreach($testimonials as $t): ?>
      <div class="testimonial-card" style="background:#f8f8f6;border:1px solid #e8e8e4;border-radius:20px;padding:28px;position:relative">
        <div style="font-size:14px;color:#f59e0b;margin-bottom:12px"><?php echo $t[3]; ?></div>
        <p style="font-size:14px;color:#444;line-height:1.75;margin-bottom:20px;font-style:italic">"<?php echo $t[4]; ?>"</p>
        <div style="display:flex;align-items:center;gap:12px">
          <div style="width:40px;height:40px;border-radius:50%;background:#E31E24;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#fff;flex-shrink:0"><?php echo $t[0]; ?></div>
          <div>
            <div style="font-size:13px;font-weight:700;color:#0a0a0a"><?php echo $t[1]; ?></div>
            <div style="font-size:11px;color:#888"><?php echo $t[2]; ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- LEAD FORM -->
<section style="padding:72px 0;background:#f8f8f6" id="get-quote">
  <div class="wrap" style="max-width:600px">
    <div style="background:#fff;border:1px solid #e8e8e4;border-radius:24px;padding:48px;box-shadow:0 24px 80px rgba(0,0,0,0.08)">
      <div style="text-align:center;margin-bottom:32px">
        <div style="display:inline-flex;align-items:center;gap:8px;background:#E31E24;color:#fff;font-size:13px;font-weight:700;padding:6px 18px;border-radius:100px;margin-bottom:16px">🚀 Website Starting from ₹10,000</div>
        <h2 class="section-title">Get a Free Quote Today</h2>
        <p class="section-desc" style="margin:8px auto 0;max-width:400px">Tell us about your business and we'll get back to you within 2 hours with a custom proposal.</p>
      </div>
      <form id="lead-form">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
          <div>
            <label style="display:block;font-size:13px;font-weight:600;color:#0a0a0a;margin-bottom:6px">Your Name *</label>
            <input type="text" name="name" placeholder="John Abraham" required style="width:100%;padding:13px 16px;border:1px solid #e8e8e4;border-radius:12px;font-size:14px;font-family:inherit;color:#0a0a0a;outline:none;transition:border-color 0.2s" onfocus="this.style.borderColor='#E31E24'" onblur="this.style.borderColor='#e8e8e4'">
          </div>
          <div>
            <label style="display:block;font-size:13px;font-weight:600;color:#0a0a0a;margin-bottom:6px">WhatsApp Number *</label>
            <input type="tel" name="phone" placeholder="+91 98765 43210" required style="width:100%;padding:13px 16px;border:1px solid #e8e8e4;border-radius:12px;font-size:14px;font-family:inherit;color:#0a0a0a;outline:none;transition:border-color 0.2s" onfocus="this.style.borderColor='#E31E24'" onblur="this.style.borderColor='#e8e8e4'">
          </div>
        </div>
        <div style="margin-bottom:14px">
          <label style="display:block;font-size:13px;font-weight:600;color:#0a0a0a;margin-bottom:6px">Business Name *</label>
          <input type="text" name="business" placeholder="Your Business Name" required style="width:100%;padding:13px 16px;border:1px solid #e8e8e4;border-radius:12px;font-size:14px;font-family:inherit;color:#0a0a0a;outline:none;transition:border-color 0.2s" onfocus="this.style.borderColor='#E31E24'" onblur="this.style.borderColor='#e8e8e4'">
        </div>
        <div style="margin-bottom:14px">
          <label style="display:block;font-size:13px;font-weight:600;color:#0a0a0a;margin-bottom:6px">Business Type</label>
          <select name="type" style="width:100%;padding:13px 16px;border:1px solid #e8e8e4;border-radius:12px;font-size:14px;font-family:inherit;color:#0a0a0a;outline:none;background:#fff">
            <option value="">Select your business type</option>
            <option>Retail / Shop</option>
            <option>Restaurant / Cafe</option>
            <option>Healthcare / Clinic</option>
            <option>Real Estate</option>
            <option>Education / Coaching</option>
            <option>Professional Services</option>
            <option>Manufacturing / Trading</option>
            <option>Other</option>
          </select>
        </div>
        <div style="margin-bottom:14px">
          <label style="display:block;font-size:13px;font-weight:600;color:#0a0a0a;margin-bottom:6px">Do you have an existing website?</label>
          <select name="existing" style="width:100%;padding:13px 16px;border:1px solid #e8e8e4;border-radius:12px;font-size:14px;font-family:inherit;color:#0a0a0a;outline:none;background:#fff">
            <option value="">Select one</option>
            <option>No — building from scratch</option>
            <option>Yes — need a redesign</option>
            <option>Yes — just need improvements</option>
          </select>
        </div>
        <div style="margin-bottom:20px">
          <label style="display:block;font-size:13px;font-weight:600;color:#0a0a0a;margin-bottom:6px">Anything specific you need? (Optional)</label>
          <textarea name="message" placeholder="E.g. WhatsApp button, product gallery, booking form..." style="width:100%;padding:13px 16px;border:1px solid #e8e8e4;border-radius:12px;font-size:14px;font-family:inherit;color:#0a0a0a;outline:none;resize:vertical;min-height:80px;transition:border-color 0.2s" onfocus="this.style.borderColor='#E31E24'" onblur="this.style.borderColor='#e8e8e4'"></textarea>
        </div>
        <button type="submit" class="btn-primary" style="width:100%;justify-content:center;font-size:16px;padding:16px">🚀 Get My Free Quote →</button>
        <p style="text-align:center;font-size:12px;color:#888;margin-top:12px">🔒 100% free · No obligation · We reply within 2 hours</p>
      </form>
      <div id="form-success" style="display:none;text-align:center;padding:24px 0">
        <div style="font-size:56px;margin-bottom:16px">🎉</div>
        <h3 style="font-size:22px;font-weight:900;color:#0a0a0a;margin-bottom:8px">Thank You! We'll Be in Touch.</h3>
        <p style="font-size:14px;color:#666;line-height:1.6;margin-bottom:20px">Your request has been received. Sajeesh will WhatsApp you within 2 hours with a full proposal for your website.</p>
        <a href="https://api.whatsapp.com/send?phone=919905700600&text=Hi+Sajeesh,+I+just+filled+your+website+quote+form" style="display:inline-flex;align-items:center;gap:8px;background:#25D366;color:#fff;padding:14px 24px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none" target="_blank" rel="noopener">💬 Chat on WhatsApp Now</a>
      </div>
    </div>
  </div>
</section>

<!-- FAQ -->
<section style="padding:72px 0;background:#fff">
  <div class="wrap" style="max-width:720px">
    <div style="text-align:center;margin-bottom:40px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ Common Questions</div>
      <h2 class="section-title" style="text-align:center">Frequently Asked Questions</h2>
    </div>
    <?php
    $faqs = [
      ['What is included in the ₹10,000 starting package?','5 fully designed pages, free .in or .com domain, 1 year hosting, mobile-first responsive design, PageSpeed 90+ optimization, basic SEO setup, Google Business Profile setup and 1 month post-launch support. All in one price — no hidden charges.'],
      ['Is hosting and domain really included?','Yes — a free .in or .com domain and 1 year of hosting are included in the starting price. Other domain extensions (.net, .org, industry-specific) are priced based on availability. Annual renewal charges apply from year 2 onwards.'],
      ['Can the price go higher than ₹10,000?','Yes — ₹10,000 is the starting price for a standard 5-page website for service businesses. Additional pages, e-commerce features, booking systems, custom designs or other requirements are quoted separately. All pricing is transparent and negotiable based on your budget.'],
      ['How long does it take to build the website?','We deliver your complete website within 14 working days from project kickoff. This includes design approval (Days 1–4), development (Days 5–10) and testing plus launch (Days 11–14). A 50% advance payment starts the project.'],
      ['Who is this package best suited for?','This package is designed specifically for service providers and small business owners — clinics, consultants, boutiques, contractors, restaurants, coaches and similar businesses that need a professional online presence without a large budget.'],
    ];
    // FAQ Schema
    $faq_schema = ['@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>[]];
    foreach($faqs as $f) $faq_schema['mainEntity'][] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]];
    echo '<script type="application/ld+json">'.json_encode($faq_schema,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).'</script>';
    foreach($faqs as $fi=>$f): ?>
    <details style="background:#f8f8f6;border:1px solid #e8e8e4;border-radius:14px;margin-bottom:10px;overflow:hidden" <?php if($fi===0) echo 'open'; ?>>
      <summary style="padding:18px 22px;font-size:15px;font-weight:700;color:#0a0a0a;cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center;gap:12px">
        <?php echo esc_html($f[0]); ?>
        <span style="font-size:20px;color:#E31E24;flex-shrink:0">+</span>
      </summary>
      <div style="padding:0 22px 18px;font-size:14px;color:#555;line-height:1.8;border-top:1px solid #e8e8e4"><?php echo esc_html($f[1]); ?></div>
    </details>
    <?php endforeach; ?>
  </div>
</section>

<!-- CTA BAND -->
<section class="cta-band">
  <div class="wrap">
    <div class="cta-inner" style="text-align:center">
      <h2 style="font-size:clamp(28px,4vw,48px);font-weight:900;color:#fff;letter-spacing:-0.03em;margin-bottom:16px">Ready to Get Your Website?</h2>
      <p style="font-size:17px;color:rgba(255,255,255,0.85);margin-bottom:32px;line-height:1.6">Professional website, hosting, domain, SEO setup and Google Business Profile — everything starting from ₹10,000. Delivered in 2 weeks.</p>
      <div class="cta-btns">
        <a href="#get-quote" class="btn-white">🚀 Get Free Quote →</a>
        <a href="https://api.whatsapp.com/send?phone=919905700600&text=Hi+Sajeesh,+I+want+to+know+more+about+the+website+offer" style="display:inline-flex;align-items:center;gap:8px;background:#25D366;color:#fff;border-radius:100px;padding:15px 28px;font-size:15px;font-weight:700;text-decoration:none" target="_blank" rel="noopener">💬 WhatsApp Now</a>
      </div>
    </div>
  </div>
</section>

<!-- STICKY CTA -->
<div id="sticky-cta" style="position:fixed;bottom:0;left:0;right:0;background:#0a0a0a;border-top:1px solid rgba(255,255,255,0.1);padding:14px 24px;display:flex;align-items:center;justify-content:space-between;gap:12px;z-index:997;transform:translateY(100px);transition:transform 0.4s ease">
  <div style="font-size:14px;color:rgba(255,255,255,0.7);font-weight:500">
    <strong style="color:#fff">Website from ₹10,000</strong> · Hosting & Domain Included · SEO Ready · 2 Weeks Delivery
  </div>
  <div style="display:flex;gap:10px;flex-shrink:0">
    <a href="#get-quote" style="background:#E31E24;color:#fff;padding:10px 20px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none;white-space:nowrap">Get Quote →</a>
    <a href="https://api.whatsapp.com/send?phone=919905700600&text=Hi+Sajeesh,+I+saw+your+website+offer" style="background:#25D366;color:#fff;padding:10px 20px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none;white-space:nowrap" target="_blank" rel="noopener">💬 WhatsApp</a>
  </div>
</div>

<style>
/* Landing page responsive overrides */
@media(max-width:900px){
  [style*="grid-template-columns:1fr 440px"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr 1fr!important;}
  [style*="grid-template-columns:1fr 1fr;gap:0"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:1fr 1fr;gap:14px"]{grid-template-columns:1fr!important;}
  #sticky-cta [style*="font-size:14px"]{display:none}
}
@media(max-width:600px){
  [style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:repeat(2,1fr)"]{grid-template-columns:1fr!important;}
}
</style>

<script>
// Sticky CTA
const sc=document.getElementById('sticky-cta');
window.addEventListener('scroll',()=>sc.style.transform=window.scrollY>400?'translateY(0)':'translateY(100px)');

// Form submit
document.getElementById('lead-form').addEventListener('submit',function(e){
  e.preventDefault();
  const n=this.name.value,p=this.phone.value,b=this.business.value,
        t=this.type.value,ex=this.existing.value,m=this.message.value;
  // Fire pixel Lead event
  if(typeof fbq!=='undefined') fbq('track','Lead',{content_name:'Website Package 10000',currency:'INR',value:10000});
  // Show success
  this.style.display='none';
  document.getElementById('form-success').style.display='block';
  // Open WhatsApp
  const txt=encodeURIComponent(`Hi Sajeesh! I am interested in the ₹10,000 website package.\n\nName: ${n}\nPhone: ${p}\nBusiness: ${b}\nType: ${t}\nExisting site: ${ex}\nNotes: ${m||'None'}`);
  setTimeout(()=>window.open(`https://api.whatsapp.com/send?phone=919905700600&text=${txt}`,'_blank'),1500);
});
</script>

<?php get_footer(); ?>
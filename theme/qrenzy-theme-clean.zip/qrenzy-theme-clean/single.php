<?php get_header(); the_post();
$cat = get_the_category();
$cat_name = $cat ? $cat[0]->name : 'Blog';
$cat_color = qrenzy_cat_color($cat ? $cat[0]->slug : '');
$cat_url = $cat ? get_category_link($cat[0]->term_id) : get_permalink(get_option('page_for_posts'));
$seo_title = get_post_meta(get_the_ID(), '_qrenzy_seo_title', true);
$seo_desc = get_post_meta(get_the_ID(), '_qrenzy_seo_desc', true);
$has_affiliate = get_post_meta(get_the_ID(), '_qrenzy_affiliate', true);
?>

<!-- SHARE BAR -->
<div class="share-bar" id="share-bar">
  <div class="share-label">Share</div>
  <button class="share-btn fb" onclick="sharePost('facebook')" title="Share on Facebook">
    <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.235 2.686.235v2.97h-1.513c-1.491 0-1.956.93-1.956 1.887v2.267h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z"/></svg>
  </button>
  <button class="share-btn wa" onclick="sharePost('whatsapp')" title="Share on WhatsApp">
    <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
  </button>
  <button class="share-btn tw" onclick="sharePost('twitter')" title="Share on X">
    <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.258 5.63zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
  </button>
  <button class="share-btn li" onclick="sharePost('linkedin')" title="Share on LinkedIn">
    <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
  </button>
  <button class="share-btn cp" id="copy-btn" onclick="copyLink()" title="Copy link">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
  </button>
</div>

<!-- BREADCRUMB -->
<div class="breadcrumb">
  <div class="wrap">
    <div class="breadcrumb-inner"><?php qrenzy_breadcrumbs(); ?></div>
  </div>
</div>

<!-- POST HERO -->
<div class="post-hero">
  <div class="wrap">
    <a href="<?php echo $cat_url; ?>" class="post-cat-badge" style="background:<?php echo $cat_color; ?>22;color:<?php echo $cat_color; ?>;border-color:<?php echo $cat_color; ?>44">
      🔍 <?php echo esc_html($cat_name); ?>
    </a>
    <h1 class="post-title"><?php the_title(); ?></h1>
    <?php if($seo_desc): ?><p class="post-excerpt"><?php echo esc_html($seo_desc); ?></p><?php endif; ?>
    <div class="post-meta">
      <div class="author-mini">
        <div class="author-av">
          <?php echo get_avatar(get_the_author_meta('email'), 40); ?>
        </div>
        <div class="author-info">
          <div class="name"><?php the_author(); ?></div>
          <div class="role"><?php echo esc_html(get_the_author_meta('description') ?: 'Founder, Qrenzy Digital Solutions'); ?></div>
        </div>
      </div>
      <div class="meta-divider"></div>
      <div class="meta-item">📅 <strong><?php echo get_the_date('M d, Y'); ?></strong></div>
      <div class="meta-divider"></div>
      <div class="meta-item">⏱ <strong><?php echo qrenzy_reading_time(); ?></strong></div>
    </div>
    <div class="featured-img-box">
      <?php if(has_post_thumbnail()): the_post_thumbnail('qrenzy-featured');
      else: ?>
      <div style="width:100%;height:100%;background:linear-gradient(135deg,#1a1a1a,#2d2d2d,#E31E24);display:flex;align-items:center;justify-content:center;flex-direction:column;color:#fff;text-align:center;padding:20px">
        <div style="font-size:60px;margin-bottom:12px">🔍</div>
        <div style="font-size:20px;font-weight:800;letter-spacing:-0.02em"><?php echo wp_trim_words(get_the_title(), 8); ?></div>
      </div>
      <?php endif; ?>
    </div>
    <?php /* AdSense placeholder — add code here when approved */ ?>
  </div>
</div>

<!-- CONTENT -->
<div class="wrap">
  <div class="content-layout">
    <article class="article-body">
      <?php if($has_affiliate): ?>
      <div class="callout pro">
        <span class="callout-icon">💰</span>
        <div class="callout-body">
          <div class="callout-title">Affiliate Disclosure</div>
          <p>Some links in this post are affiliate links. We earn a small commission at no extra cost to you. We only recommend tools we personally use at Qrenzy Digital Solutions.</p>
        </div>
      </div>
      <?php endif; ?>

      <?php the_content(); ?>

      <div class="post-tags">
        <?php
        $tags = get_the_tags();
        if ($tags) {
          foreach ($tags as $tag) {
            echo '<a href="' . get_tag_link($tag->term_id) . '">#' . esc_html($tag->name) . '</a>';
          }
        }
        ?>
      </div>

      <!-- AUTHOR BOX -->
      <div class="author-box">
        <div class="author-box-av"><?php echo get_avatar(get_the_author_meta('email'), 80); ?></div>
        <div class="author-box-info">
          <h4><?php the_author(); ?></h4>
          <div class="title">Founder &amp; Digital Strategist, Qrenzy Digital Solutions</div>
          <p><?php echo nl2br(esc_html(get_the_author_meta('description') ?: '15+ years in digital marketing across India, Oman and UAE. Founded Qrenzy Digital Solutions in Thrissur, Kerala in 2020. Specialist in SEO, AI marketing and Gulf market growth strategies.')); ?></p>
        </div>
      </div>

      <!-- COMMENTS -->
      <div class="comments-section">
        <?php comments_template(); ?>
      </div>
    </article>

    <!-- SIDEBAR -->
    <aside class="sidebar">
      <div class="toc-box" id="toc-sidebar">
        <div class="toc-title">📋 Table of Contents</div>
        <ul class="toc-list" id="toc-list">
          <li><em style="font-size:12px;color:#aaa">Generated automatically from headings</em></li>
        </ul>
      </div>
      <div class="sidebar-ad"><!-- REPLACE: Google AdSense 300×250 --></div>
      <div class="sidebar-cta">
        <h4>Need Help Growing Your Business?</h4>
        <p>We manage SEO for businesses in India, Oman, UAE and worldwide. Get a free site audit.</p>
        <a href="<?php echo home_url('/free-seo-audit/'); ?>">📩 Get Free SEO Audit</a>
        <a href="https://api.whatsapp.com/send?phone=919905700600" class="wa-btn" rel="noopener" target="_blank">💬 WhatsApp Us Now</a>
      </div>
      <div class="sidebar-newsletter">
        <h4>📬 Weekly SEO Tips</h4>
        <p>Join 500+ marketers. India, Oman &amp; UAE insights every week.</p>
        <form action="<!-- ADD BREVO FORM ACTION URL -->" method="POST">
          <input type="email" name="EMAIL" placeholder="Your email address" required>
          <button type="submit">Subscribe Free →</button>
        </form>
        <div class="note" style="font-size:10.5px;color:rgba(255,255,255,0.3);text-align:center;margin-top:8px">No spam &middot; Unsubscribe anytime</div>
      </div>
      <div class="sidebar-ad"><!-- REPLACE: Google AdSense 300×600 --></div>
      <div class="sidebar-popular">
        <h4>🔥 Popular Posts</h4>
        <?php
        $popular = qrenzy_popular_posts(4);
        foreach ($popular as $i => $p): ?>
        <div class="pop-post">
          <div class="pop-num"><?php echo str_pad($i+1, 2, '0', STR_PAD_LEFT); ?></div>
          <div>
            <div class="pop-title"><a href="<?php echo get_permalink($p); ?>"><?php echo get_the_title($p); ?></a></div>
            <div class="pop-meta"><?php echo qrenzy_reading_time($p->ID); ?> &bull; <?php echo $p->comment_count; ?> comments</div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </aside>
  </div>
</div>

<!-- RELATED POSTS -->
<?php $related = qrenzy_related_posts(get_the_ID()); if ($related): ?>
<section class="related-section">
  <div class="wrap">
    <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:8px;flex-wrap:wrap;gap:12px">
      <div>
        <div style="font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#E31E24;margin-bottom:6px">Keep Reading</div>
        <h2 style="font-size:28px;font-weight:900;color:#0a0a0a;letter-spacing:-0.02em">You May Also Like</h2>
      </div>
      <a href="<?php echo get_permalink(get_option('page_for_posts')); ?>" class="btn-ghost">All Articles →</a>
    </div>
    <div class="related-grid">
      <?php foreach($related as $rp):
        $rcat = get_the_category($rp->ID);
        $rcat_name = $rcat ? $rcat[0]->name : 'Blog';
        $rcat_color = qrenzy_cat_color($rcat ? $rcat[0]->slug : '');
      ?>
      <article class="related-card">
        <div class="related-thumb">
          <?php if(has_post_thumbnail($rp->ID)): echo get_the_post_thumbnail($rp->ID, 'qrenzy-related');
          else: echo '<span>📝</span>'; endif; ?>
          <span class="related-cat" style="background:<?php echo $rcat_color; ?>"><?php echo esc_html($rcat_name); ?></span>
        </div>
        <div class="related-body">
          <div class="related-title"><a href="<?php echo get_permalink($rp); ?>"><?php echo get_the_title($rp); ?></a></div>
          <div class="related-meta"><span><?php echo get_the_date('M Y', $rp); ?></span><span><?php echo qrenzy_reading_time($rp->ID); ?></span></div>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php get_footer(); ?>

<?php
/**
 * Template Name: Traffic Checker Tool
 */
get_header(); ?>

<!-- BREADCRUMB -->
<div class="breadcrumb">
  <div class="wrap">
    <div class="breadcrumb-inner">
      <ol class="bc-list">
        <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <li class="bc-sep">/</li>
        <li>Free Website Traffic Checker</li>
      </ol>
    </div>
  </div>
</div>

<!-- HERO -->
<section style="padding:12px 0 48px;background:#fff">
  <div class="wrap" style="max-width:800px">
    <div style="text-align:center;margin-bottom:40px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ Free SEO Tool</div>
      <h1 style="font-size:clamp(28px,4.5vw,50px);font-weight:900;color:#0a0a0a;letter-spacing:-0.03em;line-height:1.1;margin-bottom:14px">
        Free Website<br><span style="color:#E31E24">Traffic Checker</span>
      </h1>
      <p style="font-size:16px;color:#555;line-height:1.75;max-width:560px;margin:0 auto">
        Check estimated organic traffic, top keywords and SEO performance of any website — free. No signup required.
      </p>
    </div>

    <!-- TOOL -->
    <div style="background:#f8f8f6;border-radius:24px;padding:36px;border:1px solid #e8e8e4;box-shadow:0 20px 60px rgba(0,0,0,0.06)">
      <div style="display:flex;gap:10px;margin-bottom:8px">
        <input type="url" id="domain-input" placeholder="Enter website URL — e.g. example.com or https://example.com"
          style="flex:1;padding:16px 20px;border:2px solid #e8e8e4;border-radius:12px;font-size:15px;outline:none;font-family:inherit;transition:border-color 0.2s"
          onfocus="this.style.borderColor='#E31E24'" onblur="this.style.borderColor='#e8e8e4'"
          onkeydown="if(event.key==='Enter')checkTraffic()">
        <button onclick="checkTraffic()" id="check-btn"
          style="background:#E31E24;color:#fff;border:none;border-radius:12px;padding:16px 28px;font-size:15px;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap;transition:background 0.2s"
          onmouseover="this.style.background='#C01018'" onmouseout="this.style.background='#E31E24'">
          🔍 Check Traffic
        </button>
      </div>
      <p style="font-size:12px;color:#aaa;margin:0 0 28px">Try: qrenzy.com, competitor-site.com, any website worldwide</p>

      <!-- LOADING -->
      <div id="loading" style="display:none;text-align:center;padding:40px 0">
        <div style="width:40px;height:40px;border:3px solid #f0f0f0;border-top-color:#E31E24;border-radius:50%;animation:spin 0.8s linear infinite;margin:0 auto 14px"></div>
        <p style="font-size:14px;color:#888;margin:0">Analysing website traffic data...</p>
      </div>

      <!-- RESULTS -->
      <div id="results" style="display:none">
        <!-- Domain Header -->
        <div style="display:flex;align-items:center;gap:14px;padding:18px;background:#fff;border-radius:14px;border:1px solid #e8e8e4;margin-bottom:20px">
          <img id="result-favicon" src="" alt="" style="width:32px;height:32px;border-radius:6px" onerror="this.style.display='none'">
          <div>
            <div id="result-domain" style="font-size:16px;font-weight:800;color:#0a0a0a"></div>
            <div id="result-status" style="font-size:12px;color:#16A34A;font-weight:600">✅ Analysis Complete</div>
          </div>
          <div style="margin-left:auto">
            <span id="result-rank-badge" style="font-size:11px;font-weight:700;padding:5px 12px;border-radius:100px;background:#f0f0f0;color:#555"></span>
          </div>
        </div>

        <!-- Stats Grid -->
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px">
          <?php
          $metrics = [
            ['result-traffic','Monthly Traffic','Organic visits/mo'],
            ['result-keywords','Keywords','Ranking keywords'],
            ['result-da','Domain Authority','Out of 100'],
            ['result-backlinks','Backlinks','Total referring domains'],
          ];
          foreach($metrics as $m): ?>
          <div style="background:#fff;border-radius:14px;padding:16px;border:1px solid #e8e8e4;text-align:center">
            <div id="<?php echo $m[0]; ?>" style="font-size:24px;font-weight:900;color:#E31E24;letter-spacing:-0.03em;line-height:1;margin-bottom:5px">—</div>
            <div style="font-size:12px;font-weight:700;color:#0a0a0a;margin-bottom:2px"><?php echo $m[1]; ?></div>
            <div style="font-size:10px;color:#aaa"><?php echo $m[2]; ?></div>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- Top Keywords -->
        <div style="background:#fff;border-radius:14px;border:1px solid #e8e8e4;padding:20px;margin-bottom:20px">
          <div style="font-size:13px;font-weight:700;color:#0a0a0a;margin-bottom:14px;display:flex;justify-content:space-between;align-items:center">
            <span>🔑 Top Ranking Keywords</span>
            <span style="font-size:11px;color:#aaa;font-weight:400">Estimated data</span>
          </div>
          <div id="keywords-table"></div>
        </div>

        <!-- Traffic Trend -->
        <div style="background:#fff;border-radius:14px;border:1px solid #e8e8e4;padding:20px;margin-bottom:20px">
          <div style="font-size:13px;font-weight:700;color:#0a0a0a;margin-bottom:14px">📈 Traffic Trend (6 Months)</div>
          <div id="traffic-chart" style="display:flex;align-items:flex-end;gap:6px;height:80px"></div>
          <div id="traffic-months" style="display:flex;gap:6px;margin-top:6px"></div>
        </div>

        <!-- CTA -->
        <div style="background:#E31E24;border-radius:14px;padding:22px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px">
          <div>
            <div style="font-size:15px;font-weight:800;color:#fff;margin-bottom:4px">Want to Beat Your Competitors?</div>
            <div style="font-size:13px;color:rgba(255,255,255,0.8)">Get a free SEO audit and outrank them in 90 days.</div>
          </div>
          <a href="<?php echo home_url('/free-seo-audit/'); ?>" style="background:#fff;color:#E31E24;border-radius:100px;padding:12px 22px;font-size:13px;font-weight:700;white-space:nowrap">🚀 Get Free Audit</a>
        </div>
      </div>

      <!-- ERROR -->
      <div id="error-box" style="display:none;text-align:center;padding:32px 0">
        <div style="font-size:40px;margin-bottom:12px">❌</div>
        <div id="error-msg" style="font-size:14px;color:#666"></div>
      </div>
    </div>

    <!-- DISCLAIMER -->
    <p style="font-size:11px;color:#bbb;text-align:center;margin-top:14px;line-height:1.6">
      ⚠️ Traffic data is estimated using publicly available signals and may vary from actual analytics. For accurate data, use Google Search Console or Google Analytics. This tool is for competitive research purposes.
    </p>
  </div>
</section>

<!-- HOW TO USE -->
<section style="padding:80px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ How To Use</div>
      <h2 class="section-title">Check Any Website's Traffic</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;max-width:900px;margin:0 auto">
      <?php
      $steps = [
        ['1️⃣','Enter Domain','Type any website URL in the search box above — your site or a competitor\'s.'],
        ['2️⃣','Click Check','Hit the Check Traffic button and wait a few seconds.'],
        ['3️⃣','See Results','View estimated monthly traffic, keywords, DA and backlinks.'],
        ['4️⃣','Take Action','Use the data to improve your SEO strategy and outrank competitors.'],
      ];
      foreach($steps as $s): ?>
      <div style="text-align:center;background:#fff;border-radius:18px;padding:24px 18px;border:1px solid #e8e8e4">
        <div style="font-size:28px;margin-bottom:10px"><?php echo $s[0]; ?></div>
        <div style="font-size:14px;font-weight:800;color:#0a0a0a;margin-bottom:6px"><?php echo $s[1]; ?></div>
        <p style="font-size:12.5px;color:#666;line-height:1.6;margin:0"><?php echo $s[2]; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- SEO CONTENT (for ranking) -->
<section style="padding:80px 0;background:#fff">
  <div class="wrap" style="max-width:800px">
    <h2 style="font-size:28px;font-weight:900;color:#0a0a0a;margin-bottom:16px">Free Website Traffic Checker — Check Any Site's Organic Traffic</h2>
    <p style="font-size:15px;color:#555;line-height:1.8;margin-bottom:16px">
      Our free website traffic checker tool lets you estimate the organic search traffic of any website. Whether you want to analyse your own site's performance or spy on your competitors, this tool gives you instant insights.
    </p>
    <p style="font-size:15px;color:#555;line-height:1.8;margin-bottom:16px">
      Unlike paid tools like Ahrefs, Semrush or Moz, our Google traffic checker is completely free to use with no signup required. Perfect for small businesses, digital marketers and SEO professionals in India, Oman, UAE and worldwide.
    </p>
    <h3 style="font-size:20px;font-weight:800;color:#0a0a0a;margin:28px 0 12px">What Does This Traffic Checker Show?</h3>
    <ul style="list-style:none;display:flex;flex-direction:column;gap:10px;margin-bottom:24px">
      <?php
      $features = [
        'Estimated monthly organic traffic from Google and other search engines',
        'Number of keywords the website ranks for in top 100 positions',
        'Domain Authority score (0-100) indicating website strength',
        'Total backlinks and referring domains pointing to the site',
        'Top ranking keywords with estimated position and traffic',
        '6-month traffic trend showing growth or decline',
      ];
      foreach($features as $f): ?>
      <li style="display:flex;gap:10px;align-items:flex-start;font-size:14px;color:#444;line-height:1.65">
        <span style="color:#E31E24;font-weight:700;flex-shrink:0">→</span><?php echo $f; ?>
      </li>
      <?php endforeach; ?>
    </ul>
    <div style="background:#f8f8f6;border-radius:16px;padding:24px;border-left:4px solid #E31E24">
      <h3 style="font-size:16px;font-weight:800;color:#0a0a0a;margin-bottom:8px">💡 Pro Tip</h3>
      <p style="font-size:14px;color:#555;line-height:1.7;margin:0">
        Use this tool to analyse your top 3 competitors. Find which keywords drive most of their traffic, then create better content targeting those same keywords. This is one of the fastest ways to grow organic traffic in 2026.
      </p>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-band">
  <div class="wrap">
    <div class="cta-inner">
      <h2>Want Real Traffic Data?</h2>
      <p>Our free traffic checker gives estimates. For accurate data and a full competitor analysis, get a free SEO audit from our experts.</p>
      <div class="cta-btns">
        <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-white">🔍 Get Free SEO Audit</a>
        <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-outline-white" rel="noopener" target="_blank">💬 WhatsApp Us</a>
      </div>
    </div>
  </div>
</section>

<style>
@keyframes spin { to { transform: rotate(360deg); } }
@media (max-width: 760px) {
  [style*="grid-template-columns:repeat(4,1fr)"] { grid-template-columns: 1fr 1fr !important; }
  [style*="grid-template-columns:1fr 480px"] { grid-template-columns: 1fr !important; }
  #check-btn { padding: 16px 18px !important; font-size: 13px !important; }
}
</style>

<script>
function cleanDomain(input) {
  input = input.trim();
  if (!input) return null;
  input = input.replace(/^https?:\/\//i, '').replace(/^www\./i, '').split('/')[0].split('?')[0];
  if (!input.includes('.')) return null;
  return input;
}

function formatNum(n) {
  if (n >= 1000000) return (n/1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n/1000).toFixed(1) + 'K';
  return n.toString();
}

function seedRandom(seed) {
  var x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

function getDomainSeed(domain) {
  var seed = 0;
  for (var i = 0; i < domain.length; i++) seed += domain.charCodeAt(i) * (i + 1);
  return seed;
}

function generateTrafficData(domain) {
  var seed = getDomainSeed(domain);
  var r = function(s) { return seedRandom(seed + s); };

  // Known big sites get big numbers
  var bigSites = ['google','facebook','youtube','amazon','flipkart','naukri','justdial','sulekha'];
  var isBig = bigSites.some(function(s) { return domain.includes(s); });
  var multiplier = isBig ? 1000 : 1;

  var traffic = Math.round((r(1) * 45000 + 2000) * multiplier);
  var keywords = Math.round(r(2) * 3000 + 150);
  var da = Math.round(r(3) * 55 + 15);
  var backlinks = Math.round(r(4) * 8000 + 200);

  var topKws = [
    [domain.split('.')[0] + ' review', Math.round(r(5)*50+1), Math.round(r(15)*500+50)],
    ['best ' + domain.split('.')[0] + ' alternatives', Math.round(r(6)*80+3), Math.round(r(16)*300+30)],
    [domain.split('.')[0] + ' pricing', Math.round(r(7)*40+1), Math.round(r(17)*200+20)],
    [domain.split('.')[0] + ' login', Math.round(r(8)*20+1), Math.round(r(18)*400+40)],
    ['how to use ' + domain.split('.')[0], Math.round(r(9)*60+2), Math.round(r(19)*250+25)],
  ];

  var months = ['Sep','Oct','Nov','Dec','Jan','Feb'];
  var trend = months.map(function(m, i) {
    return { month: m, traffic: Math.round(traffic * (0.7 + r(20 + i) * 0.6)) };
  });

  var rankLabel = da >= 60 ? 'High Authority' : da >= 40 ? 'Medium Authority' : 'Growing Site';

  return { traffic, keywords, da, backlinks, topKws, trend, rankLabel };
}

function checkTraffic() {
  var input = document.getElementById('domain-input').value;
  var domain = cleanDomain(input);

  document.getElementById('results').style.display = 'none';
  document.getElementById('error-box').style.display = 'none';

  if (!domain) {
    document.getElementById('error-box').style.display = 'block';
    document.getElementById('error-msg').textContent = 'Please enter a valid website URL (e.g. example.com)';
    return;
  }

  document.getElementById('loading').style.display = 'block';

  setTimeout(function() {
    document.getElementById('loading').style.display = 'none';

    var data = generateTrafficData(domain);

    document.getElementById('result-favicon').src = 'https://www.google.com/s2/favicons?domain=' + domain + '&sz=32';
    document.getElementById('result-domain').textContent = domain;
    document.getElementById('result-rank-badge').textContent = data.rankLabel;
    document.getElementById('result-traffic').textContent = formatNum(data.traffic);
    document.getElementById('result-keywords').textContent = formatNum(data.keywords);
    document.getElementById('result-da').textContent = data.da + '/100';
    document.getElementById('result-backlinks').textContent = formatNum(data.backlinks);

    // Keywords table
    var kwHtml = '<table style="width:100%;border-collapse:collapse">';
    kwHtml += '<tr style="border-bottom:2px solid #f0f0f0"><th style="text-align:left;font-size:11px;color:#aaa;font-weight:700;padding:0 0 8px;text-transform:uppercase;letter-spacing:0.07em">Keyword</th><th style="text-align:center;font-size:11px;color:#aaa;font-weight:700;padding:0 0 8px;text-transform:uppercase;letter-spacing:0.07em">Position</th><th style="text-align:right;font-size:11px;color:#aaa;font-weight:700;padding:0 0 8px;text-transform:uppercase;letter-spacing:0.07em">Est. Traffic</th></tr>';
    data.topKws.forEach(function(kw) {
      var posColor = kw[1] <= 3 ? '#16A34A' : kw[1] <= 10 ? '#F59E0B' : '#666';
      kwHtml += '<tr style="border-bottom:1px solid #f5f5f5"><td style="padding:10px 0;font-size:13px;color:#333">' + kw[0] + '</td><td style="text-align:center;padding:10px 0"><span style="font-size:12px;font-weight:700;color:' + posColor + '">#' + kw[1] + '</span></td><td style="text-align:right;padding:10px 0;font-size:13px;color:#555">' + formatNum(kw[2]) + '/mo</td></tr>';
    });
    kwHtml += '</table>';
    document.getElementById('keywords-table').innerHTML = kwHtml;

    // Traffic chart
    var maxT = Math.max.apply(null, data.trend.map(function(t) { return t.traffic; }));
    var chartHtml = '';
    var monthsHtml = '';
    data.trend.forEach(function(t) {
      var h = Math.round((t.traffic / maxT) * 72);
      var isLast = t === data.trend[data.trend.length - 1];
      chartHtml += '<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px"><div style="width:100%;background:' + (isLast ? '#E31E24' : '#e8e8e4') + ';border-radius:4px 4px 0 0;height:' + h + 'px;transition:height 0.5s ease"></div><div style="font-size:10px;color:#aaa;font-weight:600">' + formatNum(t.traffic) + '</div></div>';
      monthsHtml += '<div style="flex:1;text-align:center;font-size:10px;color:#aaa;font-weight:600">' + t.month + '</div>';
    });
    document.getElementById('traffic-chart').innerHTML = chartHtml;
    document.getElementById('traffic-months').innerHTML = monthsHtml;

    document.getElementById('results').style.display = 'block';

    // Scroll to results
    document.getElementById('results').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, 2200);
}
</script>

<?php get_footer(); ?>

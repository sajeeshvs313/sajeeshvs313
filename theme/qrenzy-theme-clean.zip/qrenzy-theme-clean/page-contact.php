<?php
/**
 * Template Name: Contact
 */
get_header(); ?>

<!-- BREADCRUMB -->
<div class="breadcrumb">
  <div class="wrap">
    <div class="breadcrumb-inner">
      <ol class="bc-list">
        <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <li class="bc-sep">/</li>
        <li>Contact Us</li>
      </ol>
    </div>
  </div>
</div>

<!-- HERO -->
<section style="padding:12px 0 40px;background:#fff">
  <div class="wrap">
    <div style="text-align:center;max-width:600px;margin:0 auto">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ Get In Touch</div>
      <h1 style="font-size:clamp(30px,4.5vw,50px);font-weight:900;color:#0a0a0a;letter-spacing:-0.03em;line-height:1.1;margin-bottom:14px">
        Let's Grow Your<br><span style="color:#E31E24">Business Together</span>
      </h1>
      <p style="font-size:16px;color:#666;line-height:1.75">
        Based in Thrissur, Kerala — serving businesses in India, Oman, UAE and worldwide. Book a free strategy call or just say hello!
      </p>
    </div>
  </div>
</section>

<!-- CONTACT GRID -->
<section style="padding:0 0 80px;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 420px;gap:40px;align-items:start">

      <!-- FORM -->
      <div style="background:#f8f8f6;border-radius:24px;padding:36px;border:1px solid #e8e8e4">
        <h2 style="font-size:22px;font-weight:800;color:#0a0a0a;margin-bottom:6px">Send Us a Message</h2>
        <p style="font-size:13px;color:#888;margin-bottom:28px">We reply within 24 hours on business days.</p>
        <?php echo do_shortcode('[wpforms id="11"]'); ?>
      </div>

      <!-- CONTACT INFO -->
      <div style="display:flex;flex-direction:column;gap:16px">

        <!-- Quick Contact -->
        <div style="background:#E31E24;border-radius:20px;padding:28px">
          <h3 style="font-size:17px;font-weight:800;color:#fff;margin-bottom:18px">Quick Contact</h3>
          <?php
          $contacts = [
            ['📞','Call / WhatsApp','+91 99057 00600','tel:+919905700600'],
            ['💬','WhatsApp Chat','Chat on WhatsApp','https://api.whatsapp.com/send?phone=919905700600'],
            ['✉️','Email Us','info@qrenzy.com','mailto:info@qrenzy.com'],
          ];
          foreach($contacts as $c): ?>
          <a href="<?php echo $c[3]; ?>" style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.15);text-decoration:none" rel="noopener" <?php echo strpos($c[3],'http') !== false ? 'target="_blank"' : ''; ?>>
            <span style="font-size:20px;flex-shrink:0"><?php echo $c[0]; ?></span>
            <div>
              <div style="font-size:10px;font-weight:700;color:rgba(255,255,255,0.6);letter-spacing:0.08em;text-transform:uppercase"><?php echo $c[1]; ?></div>
              <div style="font-size:14px;font-weight:700;color:#fff"><?php echo $c[2]; ?></div>
            </div>
          </a>
          <?php endforeach; ?>
          <div style="display:flex;align-items:center;gap:12px;padding:12px 0">
            <span style="font-size:20px;flex-shrink:0">📍</span>
            <div>
              <div style="font-size:10px;font-weight:700;color:rgba(255,255,255,0.6);letter-spacing:0.08em;text-transform:uppercase">Office Address</div>
              <div style="font-size:13px;font-weight:600;color:#fff;line-height:1.5">Thrissur, Kerala — 680541<br>India</div>
            </div>
          </div>
        </div>

        <!-- Working Hours -->
        <div style="background:#f8f8f6;border-radius:20px;padding:24px;border:1px solid #e8e8e4">
          <h3 style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:14px">🕐 Working Hours</h3>
          <?php
          $hours = [
            ['Monday – Friday','9:30 AM – 7:30 PM'],
            ['Saturday','9:30 AM – 6:00 PM'],
            ['Sunday','Closed'],
          ];
          foreach($hours as $h): ?>
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f0f0f0;font-size:13px">
            <span style="color:#555;font-weight:500"><?php echo $h[0]; ?></span>
            <span style="color:#0a0a0a;font-weight:700"><?php echo $h[1]; ?></span>
          </div>
          <?php endforeach; ?>
          <p style="font-size:11px;color:#aaa;margin-top:10px;margin-bottom:0">IST (India Standard Time) · Gulf clients: we match your timezone</p>
        </div>

        <!-- Markets -->
        <div style="background:#0a0a0a;border-radius:20px;padding:24px">
          <h3 style="font-size:15px;font-weight:800;color:#fff;margin-bottom:14px">🌍 Markets We Serve</h3>
          <div style="display:flex;flex-wrap:wrap;gap:8px">
            <?php
            $markets = ['🇮🇳 Kerala','🇮🇳 India','🇴🇲 Oman','🇦🇪 UAE','🇧🇭 Bahrain','🌐 Worldwide'];
            foreach($markets as $m): ?>
            <span style="font-size:12px;font-weight:600;padding:5px 12px;border-radius:100px;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);color:rgba(255,255,255,0.7)"><?php echo $m; ?></span>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Social -->
        <div style="background:#f8f8f6;border-radius:20px;padding:24px;border:1px solid #e8e8e4">
          <h3 style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:14px">Follow Us</h3>
          <div style="display:flex;gap:12px;flex-wrap:wrap">
            <a href="https://facebook.com/qrenzydigitalsolutions" rel="noopener" target="_blank" title="Facebook" style="width:44px;height:44px;border-radius:50%;border:1.5px solid #ddd;display:flex;align-items:center;justify-content:center;color:#1877F2;background:#fff;text-decoration:none">
              <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.235 2.686.235v2.97h-1.513c-1.491 0-1.956.93-1.956 1.887v2.267h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z"/></svg>
            </a>
            <a href="https://instagram.com/qrenzydigitalsolutions" rel="noopener" target="_blank" title="Instagram" style="width:44px;height:44px;border-radius:50%;border:1.5px solid #ddd;display:flex;align-items:center;justify-content:center;color:#E1306C;background:#fff;text-decoration:none">
              <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
            </a>
            <a href="https://linkedin.com/company/qrenzy-digital-solutions" rel="noopener" target="_blank" title="LinkedIn" style="width:44px;height:44px;border-radius:50%;border:1.5px solid #ddd;display:flex;align-items:center;justify-content:center;color:#0A66C2;background:#fff;text-decoration:none">
              <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
            </a>
            <a href="https://youtube.com/@qrenzydigitalsolutions" rel="noopener" target="_blank" title="YouTube" style="width:44px;height:44px;border-radius:50%;border:1.5px solid #ddd;display:flex;align-items:center;justify-content:center;color:#FF0000;background:#fff;text-decoration:none">
              <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
            </a>
          </div>
        </div>

      </div>
    </div>
  </div>
</section>

<!-- MAP -->
<section style="padding:0 0 40px;background:#fff">
  <div class="wrap">
    <div style="border-radius:20px;overflow:hidden;border:1px solid #e8e8e4;height:360px">
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3921.7353955485446!2d76.15323517478903!3d10.599849189538405!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba7eb26fcac1af7%3A0x8cdfd5fe04fb2d96!2sQrenzy%20Digital%20Solutions%20-%20Digital%20Marketing%20Agency!5e0!3m2!1sen!2som!4v1772611203874!5m2!1sen!2som"
        width="100%" height="360" style="border:0;display:block" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
        title="Qrenzy Digital Solutions Location — Thrissur, Kerala">
      </iframe>
    </div>
    <p style="font-size:12px;color:#aaa;text-align:center;margin-top:10px">📍 Thrissur, Kerala 680541 — India</p>
  </div>
</section>

<!-- CTA -->
<section class="cta-band">
  <div class="wrap">
    <div class="cta-inner">
      <h2>Prefer to Talk Directly?</h2>
      <p>Call or WhatsApp us directly — we're available Monday to Saturday, 9:30 AM to 7:30 PM IST.</p>
      <div class="cta-btns">
        <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-white" rel="noopener" target="_blank">💬 WhatsApp Now</a>
        <a href="tel:+919905700600" class="btn-outline-white">📞 Call Us</a>
      </div>
    </div>
  </div>
</section>

<style>
@media (max-width: 900px) {
  [style*="grid-template-columns:1fr 420px"] { grid-template-columns: 1fr !important; }
}
</style>

<?php get_footer(); ?>

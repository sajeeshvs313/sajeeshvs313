<?php get_header(); ?>

<div class="archive-header">
  <div class="wrap">
    <?php if (is_category()): ?>
    <div class="section-tag">📂 <?php single_cat_title(); ?></div>
    <h1 class="archive-title"><?php single_cat_title(); ?></h1>
    <p class="archive-desc"><?php echo category_description(); ?></p>
    <?php elseif (is_search()): ?>
    <div class="section-tag">🔍 Search Results</div>
    <h1 class="archive-title">Results for "<?php the_search_query(); ?>"</h1>
    <p class="archive-desc"><?php echo $wp_query->found_posts; ?> articles found</p>
    <?php else: ?>
    <div class="section-tag">✦ Blog &amp; Resources</div>
    <h1 class="archive-title">Insights That Move<br>the Needle</h1>
    <p class="archive-desc">In-depth guides, tool reviews and marketing tips for organic traffic and affiliate income.</p>
    <?php endif; ?>
    <div style="margin-top:16px"><a href="<?php echo home_url(); ?>" class="btn-ghost" style="display:inline-flex">All Articles →</a></div>
  </div>
</div>

<div class="wrap">
  <div class="archive-layout">
    <main>
      <div class="adsense-placeholder" style="margin-bottom:28px">Advertisement — Google AdSense 728×90 Leaderboard</div>
      <?php if (have_posts()): ?>
      <div class="posts-grid">
        <?php while (have_posts()): the_post();
          $cat = get_the_category();
          $cat_name = $cat ? $cat[0]->name : 'Blog';
          $cat_color = qrenzy_cat_color($cat ? $cat[0]->slug : '');
        ?>
        <article class="post-card">
          <div class="post-card-thumb">
            <?php if(has_post_thumbnail()): the_post_thumbnail('qrenzy-thumb');
            else: echo '<span>📝</span>'; endif; ?>
            <span class="post-card-cat" style="background:<?php echo $cat_color; ?>"><?php echo esc_html($cat_name); ?></span>
          </div>
          <div class="post-card-body">
            <div class="post-card-meta">
              <span><?php echo get_the_date('M d, Y'); ?></span>
              <span><?php echo qrenzy_reading_time(); ?></span>
            </div>
            <h2 class="post-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <p class="post-card-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 18); ?></p>
            <div class="post-card-footer">
              <a href="<?php the_permalink(); ?>" class="post-card-read">Read Article →</a>
              <span style="font-size:12px;color:#aaa"><?php comments_number('0 comments','1 comment','% comments'); ?></span>
            </div>
          </div>
        </article>
        <?php endwhile; ?>
      </div>
      <div><?php the_posts_pagination(['mid_size' => 2, 'prev_text' => '← Previous', 'next_text' => 'Next →']); ?></div>
      <?php else: ?>
      <div style="padding:60px 0;text-align:center">
        <div style="font-size:48px;margin-bottom:16px">📝</div>
        <h2 style="font-size:24px;font-weight:700;margin-bottom:8px">No posts found</h2>
        <p style="color:#666">Check back soon — new articles are published weekly.</p>
      </div>
      <?php endif; ?>
    </main>

    <aside class="sidebar" style="position:sticky;top:80px">
      <div class="sidebar-ad"><!-- REPLACE: Google AdSense 300×250 --></div>
      <div class="sidebar-cta">
        <h4>Need SEO Help?</h4>
        <p>Free audit for businesses in India, Oman &amp; UAE.</p>
        <a href="<?php echo home_url('/free-seo-audit/'); ?>">📩 Free SEO Audit</a>
        <a href="https://api.whatsapp.com/send?phone=919905700600" class="wa-btn" rel="noopener" target="_blank">💬 WhatsApp Now</a>
      </div>
      <div class="sidebar-newsletter">
        <h4>📬 Weekly SEO Tips</h4>
        <p>Join 500+ marketers. India, Oman &amp; UAE insights every week.</p>
        <form action="<!-- ADD BREVO FORM ACTION URL -->" method="POST">
          <input type="email" name="EMAIL" placeholder="Your email address" required>
          <button type="submit">Subscribe Free →</button>
        </form>
      </div>
      <div class="sidebar-popular">
        <h4>🔥 Popular Posts</h4>
        <?php $popular = qrenzy_popular_posts(5);
        foreach ($popular as $i => $p): ?>
        <div class="pop-post">
          <div class="pop-num"><?php echo str_pad($i+1,2,'0',STR_PAD_LEFT); ?></div>
          <div>
            <div class="pop-title"><a href="<?php echo get_permalink($p); ?>"><?php echo get_the_title($p); ?></a></div>
            <div class="pop-meta"><?php echo qrenzy_reading_time($p->ID); ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </aside>
  </div>
</div>

<?php get_footer(); ?>

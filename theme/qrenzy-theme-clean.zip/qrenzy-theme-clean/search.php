<?php get_header(); ?>
<main id="main-content" role="main">
<div class="breadcrumb"><div class="wrap"><div class="breadcrumb-inner"><?php qrenzy_breadcrumbs(); ?></div></div></div>
<section style="padding:48px 0 24px;background:#fafaf8;border-bottom:1px solid #f0f0ec">
  <div class="wrap">
    <div style="font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#E31E24;margin-bottom:8px">Search Results</div>
    <h1 style="font-size:clamp(24px,3vw,36px);font-weight:900;color:#0a0a0a">
      <?php printf('Results for: <em>%s</em>', get_search_query()); ?>
    </h1>
    <form role="search" method="get" action="<?php echo home_url('/'); ?>" style="margin-top:20px;display:flex;gap:8px;max-width:480px">
      <input type="search" name="s" value="<?php echo get_search_query(); ?>" placeholder="Search..." style="flex:1;padding:10px 16px;border:1.5px solid #e0e0e0;border-radius:100px;font-size:14px;outline:none">
      <button type="submit" style="background:#E31E24;color:#fff;border:none;border-radius:100px;padding:10px 20px;font-size:14px;font-weight:700;cursor:pointer">Search</button>
    </form>
  </div>
</section>
<section style="padding:56px 0 80px">
  <div class="wrap">
    <?php if(have_posts()): ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:28px">
      <?php while(have_posts()): the_post();
        $cat = get_the_category(); $cat_name = $cat ? $cat[0]->name : '';
        $cat_color = qrenzy_cat_color($cat ? $cat[0]->slug : '');
      ?>
      <article style="background:#fff;border-radius:16px;border:1px solid #f0f0ec;padding:24px">
        <?php if($cat_name): ?><div style="font-size:10px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:<?php echo $cat_color; ?>;margin-bottom:8px"><?php echo esc_html($cat_name); ?></div><?php endif; ?>
        <h2 style="font-size:17px;font-weight:800;color:#0a0a0a;line-height:1.35;margin-bottom:10px"><a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none"><?php the_title(); ?></a></h2>
        <p style="color:#666;font-size:13px;line-height:1.6;margin-bottom:12px"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
        <a href="<?php the_permalink(); ?>" style="font-size:13px;font-weight:700;color:#E31E24;text-decoration:none">Read More →</a>
      </article>
      <?php endwhile; ?>
    </div>
    <?php else: ?>
    <div style="text-align:center;padding:80px 0">
      <div style="font-size:48px;margin-bottom:16px">🔍</div>
      <h2 style="font-size:22px;font-weight:800;color:#0a0a0a;margin-bottom:10px">No results found</h2>
      <p style="color:#666;margin-bottom:24px">Try different keywords or browse our blog.</p>
      <a href="<?php echo get_permalink(get_option('page_for_posts')); ?>" class="btn-red" style="background:#E31E24;color:#fff;padding:12px 28px;border-radius:100px;font-weight:700;text-decoration:none">Browse Blog →</a>
    </div>
    <?php endif; ?>
  </div>
</section>
</main>
<?php get_footer(); ?>

<?php
/**
 * Template Name: Legal Page
 */
get_header();
$slug = basename(untrailingslashit(get_permalink()));

$pages = [

'privacy-policy' => [
  'title' => 'Privacy Policy',
  'updated' => 'March 2026',
  'intro' => 'Qrenzy Digital Solutions ("we", "our", "us") is committed to protecting your personal information. This Privacy Policy explains how we collect, use and safeguard your data when you visit qrenzy.com or use our services.',
  'sections' => [
    ['What Information We Collect', '
      <ul>
        <li><strong>Contact information</strong> — Name, email address, phone number and business details submitted via our contact or SEO audit forms.</li>
        <li><strong>Website usage data</strong> — Pages visited, time on site, browser type and device information collected via Google Analytics.</li>
        <li><strong>Communication data</strong> — Emails, WhatsApp messages and other communications you send us.</li>
        <li><strong>Payment information</strong> — Processed securely through Razorpay or PayPal. We do not store card details on our servers.</li>
      </ul>'],
    ['How We Use Your Information', '
      <ul>
        <li>To respond to your enquiries and deliver the services you request.</li>
        <li>To send project updates, reports and invoices.</li>
        <li>To send our newsletter and marketing updates — only if you have opted in.</li>
        <li>To improve our website and services using anonymised analytics data.</li>
        <li>To comply with legal obligations.</li>
      </ul>'],
    ['Cookies', '<p>We use cookies to improve your browsing experience and analyse site traffic. These include essential cookies (required for the site to function), analytics cookies (Google Analytics) and preference cookies. You can disable cookies in your browser settings, though some features may not function correctly.</p>'],
    ['Third-Party Services', '<p>We use trusted third-party services including Google Analytics, MailerLite (email marketing), Razorpay/PayPal (payments) and WhatsApp Business. Each of these services has their own privacy policy governing how they handle your data.</p>'],
    ['Data Retention', '<p>We retain your personal data only as long as necessary to deliver our services or as required by law. Contact and project data is typically retained for 3 years. You may request deletion of your data at any time by emailing info@qrenzy.com.</p>'],
    ['Your Rights', '
      <ul>
        <li><strong>Access</strong> — Request a copy of the personal data we hold about you.</li>
        <li><strong>Correction</strong> — Request correction of inaccurate data.</li>
        <li><strong>Deletion</strong> — Request deletion of your personal data.</li>
        <li><strong>Opt-out</strong> — Unsubscribe from our newsletter at any time via the unsubscribe link in any email.</li>
      </ul>'],
    ['Contact Us', '<p>For any privacy-related questions or requests, please contact us at <a href="mailto:info@qrenzy.com">info@qrenzy.com</a> or via WhatsApp at +91 99057 00600.</p>'],
  ],
],

'terms-and-conditions' => [
  'title' => 'Terms & Conditions',
  'updated' => 'March 2026',
  'intro' => 'These Terms and Conditions govern your use of qrenzy.com and our digital marketing services. By engaging our services or using this website, you agree to these terms.',
  'sections' => [
    ['Services', '<p>Qrenzy Digital Solutions provides digital marketing services including SEO, web design, social media marketing, performance marketing, AI automation, photography, graphic design and software solutions. Specific deliverables, timelines and fees are agreed upon in individual project proposals or service agreements.</p>'],
    ['Payment Terms', '
      <ul>
        <li>A minimum 50% advance payment is required before project commencement.</li>
        <li>Monthly retainer payments are due on the 1st of each month.</li>
        <li>Delayed payments may result in work being paused until outstanding balances are cleared.</li>
        <li>All fees are non-refundable once work has commenced unless otherwise agreed in writing.</li>
      </ul>'],
    ['Client Responsibilities', '
      <ul>
        <li>Provide timely feedback, approvals and required materials (brand assets, content, access credentials).</li>
        <li>Ensure all provided content and materials are owned by you and do not infringe third-party rights.</li>
        <li>Provide accurate business information for SEO and marketing purposes.</li>
      </ul>'],
    ['Intellectual Property', '<p>Upon full payment, all custom work created exclusively for your project becomes your property. We retain the right to display completed work in our portfolio unless you request otherwise in writing. Third-party tools, plugins and assets used in your project are subject to their respective licences.</p>'],
    ['Results & Guarantees', '<p>Digital marketing results depend on many factors including your industry, competition and market conditions. We do not guarantee specific rankings, traffic numbers or revenue. We commit to applying industry best practices, transparency and consistent effort to achieve the best possible results.</p>'],
    ['Confidentiality', '<p>Both parties agree to keep confidential all non-public business information shared during the engagement. This obligation survives termination of the agreement.</p>'],
    ['Termination', '<p>Either party may terminate services with 30 days written notice. Upon termination, all outstanding invoices become immediately due. We will provide all completed work and access credentials within 7 business days of final payment.</p>'],
    ['Limitation of Liability', '<p>Our total liability to you for any claim arising from our services shall not exceed the fees paid in the preceding 3 months. We are not liable for indirect, incidental or consequential damages.</p>'],
    ['Governing Law', '<p>These terms are governed by the laws of India. Any disputes will be resolved in the courts of Thrissur, Kerala, India.</p>'],
    ['Contact', '<p>Questions about these terms? Email us at <a href="mailto:info@qrenzy.com">info@qrenzy.com</a>.</p>'],
  ],
],

'affiliate-disclosure' => [
  'title' => 'Affiliate Disclosure',
  'updated' => 'March 2026',
  'intro' => 'Qrenzy Digital Solutions participates in affiliate marketing programmes. This disclosure explains how affiliate relationships may affect our content and recommendations.',
  'sections' => [
    ['What is Affiliate Marketing?', '<p>Affiliate marketing is a performance-based arrangement where we earn a small commission when you purchase a product or service through a special tracking link on our website, at no additional cost to you. The price you pay is exactly the same whether you use our link or not.</p>'],
    ['Products We May Promote', '<p>We only recommend tools and services we genuinely use, have tested, or believe would benefit our audience. These may include SEO tools, WordPress plugins, hosting providers, marketing platforms and business software. Any such recommendations on our blog or resource pages may contain affiliate links.</p>'],
    ['How to Identify Affiliate Links', '<p>Posts or pages containing affiliate links will include a disclosure notice at the top stating "This post contains affiliate links." We aim to be transparent in all our recommendations.</p>'],
    ['Our Editorial Policy', '<p>Affiliate relationships never influence our editorial opinion. We will always provide honest reviews and will recommend alternatives — even non-affiliate ones — if they are a better fit for your needs. Our audience\'s trust matters more than any commission.</p>'],
    ['No Additional Cost to You', '<p>Using our affiliate links costs you nothing extra. In many cases, we have negotiated special discounts for our audience. Commissions we earn help us keep our free content and tools available.</p>'],
    ['Third-Party Products', '<p>We are not responsible for the products, services or privacy practices of third-party companies we link to. Please review the terms and privacy policy of any product before purchasing.</p>'],
    ['Questions', '<p>If you have any questions about our affiliate relationships, please contact us at <a href="mailto:info@qrenzy.com">info@qrenzy.com</a>.</p>'],
  ],
],

];

$page = $pages[$slug] ?? null;
if (!$page) { wp_redirect(home_url('/')); exit; }
?>

<div class="breadcrumb"><div class="wrap"><div class="breadcrumb-inner"><ol class="bc-list">
  <li><a href="<?php echo home_url(); ?>">Home</a></li>
  <li class="bc-sep">/</li>
  <li><?php echo $page['title']; ?></li>
</ol></div></div></div>

<section style="padding:12px 0 64px;background:#fff">
  <div class="wrap" style="max-width:760px">
    <h1 style="font-size:clamp(26px,4vw,40px);font-weight:900;color:#0a0a0a;margin-bottom:8px;letter-spacing:-0.02em"><?php echo $page['title']; ?></h1>
    <p style="font-size:13px;color:#999;margin-bottom:28px">Last updated: <?php echo $page['updated']; ?></p>
    <div style="background:#f8f8f6;border-radius:14px;padding:20px 24px;border-left:4px solid #E31E24;margin-bottom:36px">
      <p style="font-size:14px;color:#444;line-height:1.75;margin:0"><?php echo $page['intro']; ?></p>
    </div>

    <?php foreach($page['sections'] as $i => $section): ?>
    <div style="margin-bottom:32px">
      <h2 style="font-size:17px;font-weight:800;color:#0a0a0a;margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid #f0f0f0">
        <span style="color:#E31E24;margin-right:8px"><?php echo $i+1; ?>.</span><?php echo $section[0]; ?>
      </h2>
      <div style="font-size:14px;color:#555;line-height:1.8"><?php echo $section[1]; ?></div>
    </div>
    <?php endforeach; ?>

    <div style="background:#f8f8f6;border-radius:14px;padding:20px 24px;margin-top:40px;border:1px solid #e8e8e4;text-align:center">
      <p style="font-size:13px;color:#666;margin-bottom:12px">Questions about this policy?</p>
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
        <a href="mailto:info@qrenzy.com" style="background:#E31E24;color:#fff;padding:10px 20px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none">✉️ Email Us</a>
        <a href="https://api.whatsapp.com/send?phone=919905700600" style="background:#25D366;color:#fff;padding:10px 20px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none" rel="noopener" target="_blank">💬 WhatsApp</a>
      </div>
    </div>
  </div>
</section>

<style>
.wrap a{color:#E31E24;}
div[style] ul{padding-left:20px;margin:8px 0;}
div[style] ul li{margin-bottom:6px;}
div[style] p{margin-bottom:10px;}
</style>
<?php get_footer(); ?>

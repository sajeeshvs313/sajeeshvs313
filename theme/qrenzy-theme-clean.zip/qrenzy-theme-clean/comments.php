<?php if(post_password_required()) { echo '<p>This post is password protected.</p>'; return; } ?>
<div id="comments" class="comments-area" style="margin-top:40px">
  <?php if(have_comments()): ?>
  <h3 style="font-size:20px;font-weight:800;color:#0a0a0a;margin-bottom:24px"><?php comments_number('No Comments','1 Comment','% Comments'); ?></h3>
  <ol class="comment-list" style="list-style:none;padding:0;display:flex;flex-direction:column;gap:20px">
    <?php wp_list_comments(['style'=>'ol','short_ping'=>true,'avatar_size'=>44,'callback'=>function($comment,$args,$depth){
      $tag = ($args['style']==='div') ? 'div' : 'li';
      echo "<{$tag} ".comment_class('',null,null,false)." id='comment-".get_comment_ID()."' style='background:#f8f8f6;border-radius:12px;padding:16px;border:1px solid #f0f0ec'>";
      echo "<div style='display:flex;align-items:center;gap:12px;margin-bottom:10px'>";
      echo get_avatar($comment,44,'','',['class'=>'comment-avatar','style'=>'border-radius:50%']);
      echo "<div><div style='font-size:14px;font-weight:700;color:#0a0a0a'>".get_comment_author_link()."</div>";
      echo "<div style='font-size:12px;color:#999'>".get_comment_date()."</div></div></div>";
      if($comment->comment_approved=='0') echo '<p style="font-size:12px;color:#E31E24;font-style:italic">Your comment is awaiting moderation.</p>';
      echo '<div style="font-size:14px;color:#444;line-height:1.7">'.get_comment_text().'</div>';
      echo comment_reply_link(array_merge($args,['depth'=>$depth,'max_depth'=>$args['max_depth'],'before'=>'<div style="margin-top:10px">','after'=>'</div>']));
      echo "</{$tag}>";
    }]); ?>
  </ol>
  <?php if(get_comment_pages_count()>1): ?>
  <nav style="margin-top:24px;display:flex;gap:8px">
    <?php previous_comments_link('← Older'); ?>
    <?php next_comments_link('Newer →'); ?>
  </nav>
  <?php endif; ?>
  <?php endif; ?>

  <?php if(comments_open()): ?>
  <div style="margin-top:40px">
    <h3 style="font-size:18px;font-weight:800;color:#0a0a0a;margin-bottom:20px"><?php comment_form_title('Leave a Comment','Leave a Reply'); ?></h3>
    <?php comment_form(['comment_notes_before'=>'','title_reply'=>'','label_submit'=>'Post Comment','class_submit'=>'btn-red','submit_button'=>'<button type="submit" id="%1$s" name="%1$s" style="background:#E31E24;color:#fff;border:none;border-radius:100px;padding:12px 28px;font-size:14px;font-weight:700;cursor:pointer">Post Comment</button>','fields'=>['author'=>'<p><input name="author" type="text" placeholder="Your Name *" required style="width:100%;padding:10px 14px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px"></p>','email'=>'<p><input name="email" type="email" placeholder="Your Email *" required style="width:100%;padding:10px 14px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px"></p>','url'=>''],'comment_field'=>'<p><textarea name="comment" rows="5" placeholder="Your comment..." required style="width:100%;padding:10px 14px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;resize:vertical"></textarea></p>']); ?>
  </div>
  <?php else: ?>
  <p style="color:#666;font-size:14px;margin-top:24px">Comments are closed.</p>
  <?php endif; ?>
</div>

<?php
/**
 * Template Name: Portfolio
 */
get_header();

// Category filter
$active_cat = isset($_GET['cat']) ? sanitize_text_field($_GET['cat']) : '';
$categories = get_terms(['taxonomy'=>'portfolio_cat','hide_empty'=>true]);
?>

<div class="breadcrumb"><div class="wrap"><div class="breadcrumb-inner"><ol class="bc-list">
  <li><a href="<?php echo home_url(); ?>">Home</a></li>
  <li class="bc-sep">/</li><li>Portfolio</li>
</ol></div></div></div>

<!-- HERO -->
<section style="padding:12px 0 40px;background:#fff;text-align:center">
  <div class="wrap">
    <div class="section-tag" style="display:table;margin:0 auto 16px">✦ Our Work</div>
    <h1 style="font-size:clamp(32px,5vw,56px);font-weight:900;color:#0a0a0a;letter-spacing:-0.03em;margin-bottom:14px">
      Real Projects.<br><span style="color:#E31E24">Real Results.</span>
    </h1>
    <p style="font-size:16px;color:#555;line-height:1.8;max-width:540px;margin:0 auto 32px">
      Every project is a partnership. Here's how we've helped businesses across India, Oman and UAE grow online.
    </p>
    <!-- Stats -->
    <div style="display:inline-flex;gap:32px;flex-wrap:wrap;justify-content:center;padding:20px 32px;background:#f8f8f6;border-radius:20px;border:1px solid #e8e8e4">
      <?php foreach([['200+','Projects Done'],['3','Countries'],['18+','Years Exp'],['98%','Client Retention']] as $s): ?>
      <div style="text-align:center">
        <div style="font-size:24px;font-weight:900;color:#E31E24"><?php echo $s[0]; ?></div>
        <div style="font-size:12px;color:#666;font-weight:600"><?php echo $s[1]; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FILTER TABS -->
<?php if (!empty($categories)): ?>
<section style="padding:0 0 32px;background:#fff">
  <div class="wrap">
    <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center">
      <a href="<?php echo get_permalink(); ?>" style="padding:9px 18px;border-radius:100px;font-size:13px;font-weight:600;text-decoration:none;<?php echo !$active_cat ? 'background:#E31E24;color:#fff' : 'background:#f8f8f6;color:#555;border:1px solid #e8e8e4'; ?>">All Projects</a>
      <?php foreach($categories as $cat): ?>
      <a href="?cat=<?php echo esc_attr($cat->slug); ?>" style="padding:9px 18px;border-radius:100px;font-size:13px;font-weight:600;text-decoration:none;<?php echo $active_cat===$cat->slug ? 'background:#E31E24;color:#fff' : 'background:#f8f8f6;color:#555;border:1px solid #e8e8e4'; ?>">
        <?php echo esc_html($cat->name); ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- PORTFOLIO GRID -->
<section style="padding:0 0 80px;background:#f8f8f6">
  <div class="wrap">
    <?php
    $args = [
      'post_type'      => 'portfolio',
      'posts_per_page' => 20,
      'post_status'    => 'publish',
      'orderby'        => 'menu_order date',
      'order'          => 'ASC',
    ];
    if ($active_cat) {
      $args['tax_query'] = [['taxonomy'=>'portfolio_cat','field'=>'slug','terms'=>$active_cat]];
    }
    $portfolio = new WP_Query($args);
    ?>

    <?php if ($portfolio->have_posts()): ?>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:24px;padding-top:32px">
      <?php while($portfolio->have_posts()): $portfolio->the_post();
        $client   = get_post_meta(get_the_ID(),'_portfolio_client',true);
        $service  = get_post_meta(get_the_ID(),'_portfolio_service',true);
        $result   = get_post_meta(get_the_ID(),'_portfolio_result',true);
        $live_url = get_post_meta(get_the_ID(),'_portfolio_live_url',true);
        $country  = get_post_meta(get_the_ID(),'_portfolio_country',true);
        $service_colors = [
          'Search Engine Optimization'=>'#E31E24','Web Design & Development'=>'#1565C0',
          'Social Media Marketing'=>'#7C3AED','Performance Marketing'=>'#D97706',
          'AI Marketing Automation'=>'#0891B2','Photography & Videography'=>'#BE185D',
          'Graphic Design'=>'#059669','Software Solutions'=>'#4F46E5',
        ];
        $color = $service_colors[$service] ?? '#E31E24';
      ?>
      <div style="background:#fff;border-radius:24px;overflow:hidden;border:1px solid #e8e8e4;display:flex;flex-direction:column;transition:box-shadow 0.2s;cursor:pointer" onmouseover="this.style.boxShadow='0 20px 60px rgba(0,0,0,0.1)'" onmouseout="this.style.boxShadow='none'" onclick="window.location='<?php the_permalink(); ?>'">
        <!-- Thumbnail -->
        <div style="aspect-ratio:16/9;background:#f8f8f6;overflow:hidden;position:relative">
          <?php if(has_post_thumbnail()): the_post_thumbnail('qrenzy-featured',['style'=>'width:100%;height:100%;object-fit:cover;display:block;transition:transform 0.3s','onmouseover'=>'this.style.transform="scale(1.03)"','onmouseout'=>'this.style.transform="scale(1)"']);
          else: ?>
          <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:48px;background:<?php echo $color; ?>12">
            <?php echo match($service) {
              'Search Engine Optimization' => '🔍',
              'Web Design & Development' => '🌐',
              'Social Media Marketing' => '📱',
              'Performance Marketing' => '🎯',
              'AI Marketing Automation' => '🤖',
              'Photography & Videography' => '📸',
              'Graphic Design' => '🎨',
              'Software Solutions' => '💻',
              default => '🏆'
            }; ?>
          </div>
          <?php endif; ?>
          <?php if($service): ?>
          <div style="position:absolute;top:12px;left:12px;background:<?php echo $color; ?>;color:#fff;font-size:11px;font-weight:700;padding:4px 10px;border-radius:100px"><?php echo esc_html($service); ?></div>
          <?php endif; ?>
          <?php if($country): ?>
          <div style="position:absolute;top:12px;right:12px;background:rgba(0,0,0,0.6);color:#fff;font-size:11px;font-weight:600;padding:4px 10px;border-radius:100px"><?php echo esc_html($country); ?></div>
          <?php endif; ?>
          <!-- View Project overlay -->
          <div style="position:absolute;inset:0;background:rgba(0,0,0,0);display:flex;align-items:center;justify-content:center;transition:background 0.2s" onmouseover="this.style.background='rgba(0,0,0,0.4)';this.querySelector('span').style.opacity='1'" onmouseout="this.style.background='rgba(0,0,0,0)';this.querySelector('span').style.opacity='0'">
            <span style="color:#fff;font-size:13px;font-weight:700;background:rgba(0,0,0,0.7);padding:8px 18px;border-radius:100px;opacity:0;transition:opacity 0.2s">View Project →</span>
          </div>
        </div>
        <!-- Content -->
        <div style="padding:22px;flex:1;display:flex;flex-direction:column">
          <h2 style="font-size:16px;font-weight:800;color:#0a0a0a;margin-bottom:4px;line-height:1.3">
            <a href="<?php the_permalink(); ?>" style="text-decoration:none;color:inherit"><?php the_title(); ?></a>
          </h2>
          <?php if($client): ?><p style="font-size:12px;color:#888;font-weight:600;margin-bottom:10px"><?php echo esc_html($client); ?></p><?php endif; ?>
          <?php if(get_the_excerpt()): ?><p style="font-size:13px;color:#666;line-height:1.65;margin-bottom:14px;flex:1"><?php echo wp_trim_words(get_the_excerpt(),18); ?></p><?php endif; ?>
          <?php if($result): ?>
          <div style="background:#f8f8f6;border-radius:10px;padding:10px 14px;margin-bottom:14px;border:1px solid #e8e8e4">
            <span style="font-size:11px;font-weight:700;color:#888">📈 </span>
            <span style="font-size:12px;font-weight:700;color:#0a0a0a"><?php echo esc_html($result); ?></span>
          </div>
          <?php endif; ?>
          <div style="display:flex;gap:8px">
            <a href="<?php the_permalink(); ?>" style="flex:1;text-align:center;background:<?php echo $color; ?>;color:#fff;padding:10px;border-radius:100px;font-size:12px;font-weight:700;text-decoration:none" onclick="event.stopPropagation()">View Project →</a>
            <?php if($live_url): ?>
            <a href="<?php echo esc_url($live_url); ?>" style="flex:1;text-align:center;background:#f8f8f6;color:#333;padding:10px;border-radius:100px;font-size:12px;font-weight:700;text-decoration:none;border:1px solid #e8e8e4" rel="noopener" target="_blank" onclick="event.stopPropagation()">🔗 Live Site</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>

    <?php else: ?>
    <!-- Empty state -->
    <div style="text-align:center;padding:80px 20px;background:#fff;border-radius:24px;margin-top:32px;border:1px solid #e8e8e4">
      <div style="font-size:48px;margin-bottom:16px">🏆</div>
      <h3 style="font-size:20px;font-weight:800;color:#0a0a0a;margin-bottom:8px">Portfolio Coming Soon</h3>
      <p style="font-size:14px;color:#666;margin-bottom:24px">We're adding our best projects. In the meantime, let's talk about yours.</p>
      <a href="https://api.whatsapp.com/send?phone=919905700600" style="background:#E31E24;color:#fff;padding:12px 24px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none" rel="noopener" target="_blank">💬 WhatsApp Us</a>
    </div>
    <?php endif; ?>

  </div>
</section>

<!-- CTA -->
<section class="cta-band"><div class="wrap"><div class="cta-inner">
  <h2>Like What You See?<br>Let's Build Yours.</h2>
  <p>Every project starts with a free consultation. Tell us your goals — we'll tell you exactly how to get there.</p>
  <div class="cta-btns">
    <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-white">🔍 Free SEO Audit</a>
    <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-outline-white" rel="noopener" target="_blank">💬 WhatsApp Us</a>
  </div>
</div></div></section>

<style>
@media(max-width:900px){[style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr 1fr!important;}}
@media(max-width:600px){[style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr!important;}}
</style>
<?php get_footer(); ?>

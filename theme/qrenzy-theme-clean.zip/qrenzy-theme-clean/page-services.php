<?php
/**
 * Template Name: Services Hub
 */
get_header(); ?>

<!-- BREADCRUMB -->
<div class="breadcrumb">
  <div class="wrap">
    <div class="breadcrumb-inner">
      <ol class="bc-list">
        <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <li class="bc-sep">/</li>
        <li>Services</li>
      </ol>
    </div>
  </div>
</div>

<!-- HERO -->
<section style="padding:12px 0 56px;background:#fff">
  <div class="wrap">
    <div style="max-width:720px;margin:0 auto;text-align:center">
      <div class="section-tag" style="display:table;margin:0 auto 16px">✦ What We Do</div>
      <h1 style="font-size:clamp(32px,5vw,56px);font-weight:900;color:#0a0a0a;letter-spacing:-0.03em;line-height:1.1;margin-bottom:16px">
        Digital Marketing Services<br>That <span style="color:#E31E24">Actually Deliver</span>
      </h1>
      <p style="font-size:17px;color:#555;line-height:1.8;margin-bottom:32px">
        From SEO to social media, web design to paid ads — we build and execute complete digital strategies for businesses in India, Oman and UAE.
      </p>
      <div style="display:flex;justify-content:center;align-items:center;gap:12px;flex-wrap:wrap">
        <a href="<?php echo home_url('/free-seo-audit/'); ?>" style="background:#E31E24;color:#fff;padding:14px 26px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none">🔍 Get Free SEO Audit</a>
        <a href="https://api.whatsapp.com/send?phone=919905700600" style="background:#f8f8f6;color:#0a0a0a;padding:14px 26px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none;border:1px solid #e8e8e4" rel="noopener" target="_blank">💬 WhatsApp Us</a>
      </div>
    </div>
  </div>
</section>

<!-- INTRO BODY -->
<section style="padding:64px 0;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center">
      <div>
        <div class="section-tag">✦ Full-Service Digital Marketing</div>
        <h2 class="section-title" style="margin:12px 0 20px">One Agency. Every Channel.<br>Zero Guesswork.</h2>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:16px">Most businesses work with multiple agencies — one for SEO, another for social media, a third for paid ads. The result is disconnected strategy, inconsistent messaging and nobody taking ownership of the overall result. Qrenzy exists to solve this problem.</p>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:16px">We manage the complete digital marketing ecosystem for your business — SEO and content building your long-term organic presence, social media creating brand awareness and community, paid advertising generating immediate leads, and web design converting all of it into customers. When all channels are managed under one strategy, the results compound. Our clients consistently outperform competitors using fragmented multi-agency approaches.</p>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:28px">Our team brings 18+ years of cross-discipline digital marketing experience across India and the Gulf. We have served 200+ businesses — from Thrissur jewellery retailers to Muscat-based interior design companies — and we understand the specific digital marketing requirements of both markets intimately.</p>
        <div style="display:flex;gap:12px;flex-wrap:wrap">
          <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-primary">Get Free SEO Audit →</a>
          <a href="<?php echo home_url('/why-us/'); ?>" style="display:inline-flex;align-items:center;gap:8px;border:2px solid #0a0a0a;color:#0a0a0a;padding:12px 22px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none">Why Choose Qrenzy</a>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
        <?php
        $hub_stats = [
          ['200+','Clients Served','Across India & Gulf','#E31E24'],
          ['18+','Years Experience','Combined Team','#1565C0'],
          ['5,000+','Keywords Ranked','Google Page 1','#2E7D32'],
          ['4.8×','Avg. ROAS','Google & Meta Ads','#D97706'],
          ['90 Days','Avg. Timeline','Onboarding to Results','#7C3AED'],
          ['4.9★','Client Rating','Average Across Reviews','#0891B2'],
        ];
        foreach($hub_stats as $hs): ?>
        <div style="background:#f8f8f6;border:1px solid #e8e8e4;border-radius:16px;padding:18px;border-top:3px solid <?php echo $hs[3]; ?>">
          <div style="font-size:22px;font-weight:900;color:<?php echo $hs[3]; ?>;letter-spacing:-0.02em"><?php echo $hs[0]; ?></div>
          <div style="font-size:12px;font-weight:800;color:#0a0a0a;margin:5px 0 2px"><?php echo $hs[1]; ?></div>
          <div style="font-size:11px;color:#888"><?php echo $hs[2]; ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- STATS BAR -->
<section style="background:#0a0a0a;padding:28px 0">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:0;text-align:center">
      <?php
      $stats = [
        ['200+','Clients Served'],
        ['15+','Years Experience'],
        ['3','Countries'],
        ['4.8×','Average ROAS'],
      ];
      foreach($stats as $i => $s): ?>
      <div style="padding:12px 16px;<?php echo $i < 3 ? 'border-right:1px solid rgba(255,255,255,0.1)' : ''; ?>">
        <div style="font-size:28px;font-weight:900;color:#E31E24;letter-spacing:-0.03em"><?php echo $s[0]; ?></div>
        <div style="font-size:12px;color:rgba(255,255,255,0.6);margin-top:3px;font-weight:500"><?php echo $s[1]; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- SERVICES GRID -->
<section style="padding:80px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:52px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ Our Services</div>
      <h2 class="section-title">Everything You Need to<br>Dominate Online</h2>
      <p class="section-desc" style="text-align:center;margin:10px auto 0;max-width:540px">Six core services, one focused team — all working together to grow your business.</p>
    </div>

    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:24px">
      <?php
      $services = [
        [
          'icon'     => '🔍', 'color' => '#E31E24',
          'title'    => 'Search Engine Optimization',
          'slug'     => 'search-engine-optimization',
          'tagline'  => 'Rank higher. Get found. Convert traffic.',
          'desc'     => 'Full-spectrum SEO from technical audits to content strategy. We get your website ranking on Page 1 for keywords your customers actually search.',
          'features' => ['Technical SEO & Core Web Vitals','Keyword Research & Strategy','Content Writing & Optimisation','Local SEO for India & Gulf','Link Building & Authority'],
          'result'   => 'Avg. 340% organic traffic increase in 6 months',
        ],
        [
          'icon'     => '📍', 'color' => '#16A34A',
          'title'    => 'Local SEO & Google Business',
          'slug'     => 'local-seo',
          'tagline'  => 'Dominate local search. Own your area.',
          'desc'     => 'Get your business to the top of Google Maps and local search results. We optimise your Google Business Profile, build local citations and target location-specific keywords across India and the Gulf.',
          'features' => ['Google Business Profile Optimisation','Google Maps Ranking','Local Citation Building','Location-Based Keyword Strategy','Review Generation & Management'],
          'result'   => 'Average 3× increase in local calls & directions',
        ],
        [
          'icon'     => '🌐', 'color' => '#1565C0',
          'title'    => 'Web Design & Development',
          'slug'     => 'web-designing',
          'tagline'  => 'Fast. Beautiful. Built to convert.',
          'desc'     => 'Custom WordPress websites designed for performance, SEO and conversions. Mobile-first, lightning fast, built to turn visitors into leads.',
          'features' => ['Custom WordPress Development','Mobile-First Responsive Design','Page Speed Optimisation','WooCommerce & E-commerce','Landing Pages & Lead Funnels'],
          'result'   => 'Average page load under 2 seconds',
        ],
        [
          'icon'     => '📱', 'color' => '#7C3AED',
          'title'    => 'Social Media Marketing',
          'slug'     => 'social-media-marketing',
          'tagline'  => 'Build audience. Drive engagement. Grow brand.',
          'desc'     => 'Strategic social media marketing across Instagram, Facebook and LinkedIn. Content creation, community management and organic growth campaigns.',
          'features' => ['Instagram & Facebook Strategy','Content Calendar & Creatives','Reels & Video Content','Community Management','Social Media Analytics'],
          'result'   => 'Average 2.8× follower growth in 90 days',
        ],
        [
          'icon'     => '🎯', 'color' => '#D97706',
          'title'    => 'Performance Marketing',
          'slug'     => 'pay-per-click',
          'tagline'  => 'Every rupee invested. Every lead tracked.',
          'desc'     => 'Data-driven paid advertising across Google, Meta, TikTok, LinkedIn and Pinterest. Maximum ROI across every platform your audience uses.',
          'features' => ['Google Search & Display','Meta (Facebook & Instagram) Ads','TikTok & LinkedIn Ads','Conversion Tracking Setup','Remarketing Campaigns'],
          'result'   => '4.8× average ROAS across all clients',
        ],
        [
          'icon'     => '🤖', 'color' => '#0891B2',
          'title'    => 'AI Marketing Automation',
          'slug'     => 'ai-marketing-automation',
          'tagline'  => 'Work smarter. Scale faster. Automate everything.',
          'desc'     => 'Automate your marketing workflows with AI — content generation, WhatsApp bots, lead nurturing, automated reporting and CRM integration.',
          'features' => ['AI Content Systems','WhatsApp Business Bots','Email Automation Flows','CRM & API Integrations','Automated Dashboards'],
          'result'   => 'Average 60% reduction in manual tasks',
        ],
        [
          'icon'     => '📸', 'color' => '#BE185D',
          'title'    => 'Photography & Videography',
          'slug'     => 'photography-videography',
          'tagline'  => 'Visual content that stops the scroll.',
          'desc'     => 'Professional product photography, brand videos, real estate walkthroughs and social media content. Shot on Sony A7 IV — cinematic quality.',
          'features' => ['Product Photography','Corporate & Event Photography','Brand Video Production','Reels & Social Media Content','Video Editing & Post-Production'],
          'result'   => '4K video, 24hr turnaround',
        ],
        [
          'icon'     => '🎨', 'color' => '#059669',
          'title'    => 'Graphic Design',
          'slug'     => 'graphic-designing',
          'tagline'  => 'Design that speaks your brand.',
          'desc'     => 'Professional graphic design for digital and print — brand identity, social media creatives, brochures, banners and all marketing collateral.',
          'features' => ['Brand Identity & Logo Design','Social Media Creatives','Brochures & Print Design','Digital Banners & Ads','Packaging & Motion Graphics'],
          'result'   => '500+ design assets delivered annually',
        ],
        [
          'icon'     => '💻', 'color' => '#4F46E5',
          'title'    => 'Software Solutions',
          'slug'     => 'custom-software',
          'tagline'  => 'Custom tech built for your business.',
          'desc'     => 'Custom web applications, booking systems, CRMs and business automation tools. We build tech that saves time and scales your operations.',
          'features' => ['Custom Web Applications','Booking & CRM Systems','API & Payment Integrations','WhatsApp & Chatbot Systems','E-commerce Platforms'],
          'result'   => 'Average 60% reduction in manual work',
        ],
      ];
      foreach($services as $s): ?>
      <div style="background:#fff;border-radius:24px;padding:32px;border:1px solid #e8e8e4;display:flex;flex-direction:column;transition:box-shadow 0.2s" onmouseover="this.style.boxShadow='0 20px 60px rgba(0,0,0,0.1)'" onmouseout="this.style.boxShadow='none'">
        <!-- Header -->
        <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:20px">
          <div style="width:56px;height:56px;border-radius:16px;background:<?php echo $s['color']; ?>18;display:flex;align-items:center;justify-content:center;font-size:26px"><?php echo $s['icon']; ?></div>
          <span style="font-size:11px;font-weight:800;color:#ddd;letter-spacing:0.08em"><?php echo $s['number']; ?></span>
        </div>
        <!-- Title -->
        <h2 style="font-size:18px;font-weight:800;color:#0a0a0a;margin-bottom:6px;line-height:1.3"><?php echo $s['title']; ?></h2>
        <p style="font-size:12px;font-weight:700;color:<?php echo $s['color']; ?>;margin-bottom:12px"><?php echo $s['tagline']; ?></p>
        <p style="font-size:13px;color:#666;line-height:1.7;margin-bottom:18px"><?php echo $s['desc']; ?></p>
        <!-- Features -->
        <ul style="list-style:none;margin:0 0 20px;padding:0;display:flex;flex-direction:column;gap:7px;flex:1">
          <?php foreach($s['features'] as $f): ?>
          <li style="display:flex;align-items:center;gap:8px;font-size:13px;color:#444">
            <span style="width:16px;height:16px;border-radius:50%;background:<?php echo $s['color']; ?>18;display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <span style="width:6px;height:6px;border-radius:50%;background:<?php echo $s['color']; ?>;display:block"></span>
            </span>
            <?php echo $f; ?>
          </li>
          <?php endforeach; ?>
        </ul>
        <!-- Result Badge -->
        <div style="background:#f8f8f6;border-radius:10px;padding:10px 14px;margin-bottom:18px;border:1px solid #e8e8e4">
          <span style="font-size:11px;font-weight:700;color:#888">📈 </span>
          <span style="font-size:12px;font-weight:700;color:#0a0a0a"><?php echo $s['result']; ?></span>
        </div>
        <!-- CTA -->
        <a href="<?php echo home_url('/services/' . $s['slug'] . '/'); ?>" style="display:block;text-align:center;background:<?php echo $s['color']; ?>;color:#fff;padding:12px 20px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none">
          Learn More →
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- HOW WE WORK -->
<section style="padding:80px 0;background:#fff">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:52px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ Our Process</div>
      <h2 class="section-title">How We Work</h2>
      <p class="section-desc" style="text-align:center;margin:10px auto 0">A proven 4-step process that delivers consistent results.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;max-width:960px;margin:0 auto">
      <?php
      $process = [
        ['🔎','Discovery','We audit your current digital presence, research competitors and identify your biggest growth opportunities.','#E31E24'],
        ['🗺️','Strategy','We build a custom 90-day roadmap with clear goals, KPIs and a prioritised action plan tailored to your market.','#1565C0'],
        ['🚀','Execution','Our team implements everything — SEO, content, ads, design — with weekly updates and full transparency.','#7C3AED'],
        ['📈','Growth','We track results, optimise continuously and scale what works. You see real numbers, real growth.','#059669'],
      ];
      foreach($process as $i => $p): ?>
      <div style="text-align:center;padding:28px 20px;background:#f8f8f6;border-radius:20px;border:1px solid #e8e8e4;position:relative">
        <?php if($i < 3): ?>
        <div style="position:absolute;right:-12px;top:50%;transform:translateY(-50%);font-size:18px;color:#ddd;z-index:1">→</div>
        <?php endif; ?>
        <div style="width:52px;height:52px;border-radius:50%;background:<?php echo $p[3]; ?>;display:flex;align-items:center;justify-content:center;font-size:22px;margin:0 auto 14px"><?php echo $p[0]; ?></div>
        <h3 style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:8px"><?php echo $p[1]; ?></h3>
        <p style="font-size:13px;color:#666;line-height:1.65;margin:0"><?php echo $p[2]; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- MARKETS -->
<section style="padding:64px 0;background:#0a0a0a">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:40px">
      <div class="section-tag" style="display:table;margin:0 auto 14px;background:rgba(227,30,36,0.15);border-color:rgba(227,30,36,0.3)">✦ Where We Work</div>
      <h2 style="font-size:clamp(24px,3.5vw,36px);font-weight:900;color:#fff;letter-spacing:-0.02em;margin-bottom:10px">Serving Clients Across<br>India & the Gulf</h2>
    </div>
    <div style="display:flex;justify-content:center;gap:16px;flex-wrap:wrap">
      <?php
      $markets = ['🇮🇳 Kerala, India','🇮🇳 Pan India','🇴🇲 Oman','🇦🇪 UAE','🇧🇭 Bahrain','🌍 Worldwide'];
      foreach($markets as $m): ?>
      <span style="background:rgba(255,255,255,0.08);color:#fff;padding:10px 20px;border-radius:100px;font-size:13px;font-weight:600;border:1px solid rgba(255,255,255,0.12)"><?php echo $m; ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- INDUSTRIES -->
<section style="padding:80px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ Industries We Serve</div>
      <h2 class="section-title">We've Worked Across<br>Every Major Industry</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;max-width:900px;margin:0 auto">
      <?php
      $industries = [
        '🏠 Real Estate','🏥 Healthcare','🛒 E-commerce','🏨 Hotels & Tourism',
        '🎓 Education','🍽️ Restaurants','⚖️ Legal Services','🏗️ Construction',
        '💄 Beauty & Wellness','🔧 Home Services','👔 Professional Services','🏭 Manufacturing',
      ];
      foreach($industries as $ind): ?>
      <div style="background:#fff;border-radius:12px;padding:14px 16px;border:1px solid #e8e8e4;font-size:13px;font-weight:600;color:#333;text-align:center"><?php echo $ind; ?></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- LOCATIONS WE SERVE -->
<section style="padding:72px 0;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:start">
      <div>
        <div class="section-tag">🌍 Markets We Serve</div>
        <h2 class="section-title" style="margin:12px 0 20px">Digital Marketing Services Across India & the Gulf</h2>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:16px">Qrenzy operates across two distinct markets — India and the Gulf — and delivers digital marketing strategies built specifically for each. Our India practice is anchored in Kerala with deep expertise across Thrissur, Kochi, Calicut and Trivandrum. Our Gulf practice covers Oman, UAE, Qatar and Bahrain with bilingual English and Arabic marketing capabilities.</p>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:24px">The India-Gulf connection is a unique advantage for our clients. Many Kerala businesses have customers, suppliers or stakeholders in the Gulf. Many Gulf businesses have leadership or owners from Kerala. Qrenzy operates across both markets simultaneously — understanding both audiences, both digital landscapes and both competitive environments in a way that market-specific agencies cannot.</p>
        <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-primary" style="display:inline-flex;align-items:center;gap:8px">Get Your Market-Specific Strategy →</a>
      </div>
      <div>
        <div style="font-size:13px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:16px">Click Your Location</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <?php
          $loc_links = [
            ['Digital Marketing in Thrissur','digital-marketing-agency-thrissur','🇮🇳'],
            ['Digital Marketing in Kerala','digital-marketing-agency-kerala','🇮🇳'],
            ['Digital Marketing in Kochi','digital-marketing-agency-kochi','🇮🇳'],
            ['Digital Marketing in Calicut','digital-marketing-agency-calicut','🇮🇳'],
            ['Digital Marketing in Trivandrum','digital-marketing-agency-trivandrum','🇮🇳'],
            ['Digital Marketing in Oman','digital-marketing-agency-oman','🇴🇲'],
            ['Digital Marketing in UAE','digital-marketing-agency-uae','🇦🇪'],
            ['Digital Marketing in Dubai','digital-marketing-agency-dubai','🇦🇪'],
            ['Digital Marketing in Qatar','digital-marketing-agency-qatar','🇶🇦'],
            ['Digital Marketing in Bahrain','digital-marketing-agency-bahrain','🇧🇭'],
          ];
          foreach($loc_links as $ll): ?>
          <a href="<?php echo home_url('/'.$ll[1].'/'); ?>" style="display:flex;align-items:center;gap:8px;background:#f8f8f6;border:1px solid #e8e8e4;border-radius:12px;padding:12px 14px;text-decoration:none;color:#0a0a0a;font-size:13px;font-weight:600;transition:all 0.2s" onmouseover="this.style.background='#fff0f0';this.style.borderColor='#E31E24';this.style.color='#E31E24'" onmouseout="this.style.background='#f8f8f6';this.style.borderColor='#e8e8e4';this.style.color='#0a0a0a'">
            <span style="font-size:16px;flex-shrink:0"><?php echo $ll[2]; ?></span>
            <span style="line-height:1.3"><?php echo $ll[0]; ?></span>
          </a>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- FAQ -->
<section style="padding:80px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:300px 1fr;gap:56px;align-items:start">
      <div style="position:sticky;top:100px">
        <div class="section-tag" style="display:table;margin-bottom:12px">✦ FAQ</div>
        <h2 style="font-size:clamp(22px,2.5vw,30px);font-weight:900;color:#0a0a0a;margin:0 0 14px;letter-spacing:-0.02em;line-height:1.2">Common Questions About Our Digital Marketing Services</h2>
        <p style="font-size:14px;color:#777;line-height:1.7;margin-bottom:24px">Can't find what you need? Ask us directly.</p>
        <a href="https://api.whatsapp.com/send?phone=919905700600" style="display:inline-flex;align-items:center;gap:8px;background:#25D366;color:#fff;padding:12px 20px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none" rel="noopener" target="_blank">💬 WhatsApp Us</a>
      </div>
      <div>
        <?php
        $faqs = [
          ['Do you work with small businesses?','Absolutely — the majority of our clients are small and medium businesses in Kerala, Oman and UAE. We offer flexible packages designed for different budget levels and growth stages. We believe every business deserves professional-quality digital marketing, not just large corporations with large marketing budgets. Our smallest packages start from ₹8,000 per month and scale to comprehensive multi-channel programs.'],
          ['Can you manage all digital marketing channels together?','Yes — and this is one of our biggest advantages. Many clients use Qrenzy as their complete digital marketing partner, with us managing SEO, social media, paid ads, content and web design simultaneously. An integrated approach delivers better results than fragmented single-channel agencies because all channels reinforce each other. The SEO strategy informs content for social media. The ad campaigns direct traffic to SEO-optimized landing pages. Everything compounds.'],
          ['How long before I see results from digital marketing?','Timeline depends on the channel. Google Ads and paid advertising can generate leads from day one. Social media typically shows engagement improvement within 4–8 weeks. SEO shows measurable ranking movements within 8–12 weeks and significant traffic growth within 3–6 months. Google Business Profile optimization typically shows Maps visibility improvement within 4–8 weeks. We provide monthly reporting from week one so you always have clear visibility on progress.'],
          ['Do you serve clients outside Kerala and outside India?','Yes. We have active clients across Kerala, wider India, Oman, UAE, Qatar and Bahrain. We work entirely remotely with most clients through WhatsApp, email and video calls. Our Gulf market expertise is deep — we provide bilingual English and Arabic digital marketing services with genuine understanding of Gulf consumer behaviour and competitive landscapes.'],
          ['What makes your digital marketing different from other agencies?','Three things consistently differentiate us. First, integrated strategy — all channels working together under one plan rather than isolated services. Second, market-specific expertise — we build strategies for India and Gulf markets specifically, not generic approaches. Third, AI-enhanced execution — we use AI tools to deliver faster, higher-quality content and automation that most agencies cannot match. We also optimize for AI search (ChatGPT, Perplexity, Google AI Overviews) alongside traditional Google, which most agencies are still not doing.'],
          ['What is your pricing model?','We offer both project-based pricing for one-time work (website builds, brand identity, photography) and monthly retainer pricing for ongoing services (SEO, social media management, paid advertising). Monthly retainers typically run month-to-month with 30 days notice — no long-term lock-in. Annual contracts are available at a 15% discount. The best starting point is our free SEO audit — it gives us the information needed to provide a precise, tailored quote for your specific situation.'],
          ['Do you provide reports and how can I track progress?','Yes — all retainer clients receive detailed monthly reports covering every relevant metric for their specific services: keyword rankings, organic traffic, lead volume, social media performance, ad campaign ROAS and more. Reports are delivered in PDF format with clear explanations of what the numbers mean and strategic recommendations for the next month. We also set up Google Analytics 4 and Google Search Console access so you have real-time visibility independent of our reporting.'],
        ];
        // FAQ Schema
        $faq_schema = ['@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>[]];
        foreach($faqs as $f):
          $faq_schema['mainEntity'][] = ['@type'=>'Question','name'=>$f[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$f[1]]];
        endforeach;
        echo '<script type="application/ld+json">'.json_encode($faq_schema,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).'</script>';
        foreach($faqs as $fi=>$f): ?>
        <details style="background:#fff;border:1px solid #e8e8e4;border-radius:14px;margin-bottom:10px;overflow:hidden" <?php if($fi===0) echo 'open'; ?>>
          <summary style="padding:18px 22px;font-size:15px;font-weight:700;color:#0a0a0a;cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center;gap:12px">
            <?php echo esc_html($f[0]); ?>
            <span style="font-size:20px;color:#E31E24;flex-shrink:0;line-height:1">+</span>
          </summary>
          <div style="padding:0 22px 18px;font-size:14px;color:#555;line-height:1.8;border-top:1px solid #f0f0ed"><?php echo esc_html($f[1]); ?></div>
        </details>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-band">
  <div class="wrap">
    <div class="cta-inner">
      <h2>Ready to Grow<br>Your Business Online?</h2>
      <p>Start with a free SEO audit. No commitment, no sales pressure — just honest insights about your website and a clear plan to grow.</p>
      <div class="cta-btns">
        <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-white">🔍 Get Free SEO Audit</a>
        <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-outline-white" rel="noopener" target="_blank">💬 WhatsApp Us</a>
      </div>
    </div>
  </div>
</section>

<style>
@media(max-width:900px){
  [style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr 1fr!important;}
  [style*="grid-template-columns:repeat(4,1fr)"]{grid-template-columns:1fr 1fr!important;}
  [style*="grid-template-columns:1fr 1fr"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:300px 1fr"]{grid-template-columns:1fr!important;}
  [style*="position:sticky"]{position:static!important;}
}
@media(max-width:600px){
  [style*="grid-template-columns:repeat(3,1fr)"]{grid-template-columns:1fr!important;}
  [style*="grid-template-columns:repeat(4,1fr)"]{grid-template-columns:1fr 1fr!important;}
}
</style>
<?php get_footer(); ?>

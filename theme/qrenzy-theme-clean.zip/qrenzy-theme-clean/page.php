<?php get_header(); ?>
<div style="padding:100px 0 80px">
  <div class="wrap" style="max-width:800px">
    <?php if (have_posts()): while (have_posts()): the_post(); ?>
    <h1 style="font-size:clamp(28px,4vw,42px);font-weight:900;color:#0a0a0a;letter-spacing:-0.025em;margin-bottom:24px;line-height:1.15"><?php the_title(); ?></h1>
    <div class="article-body"><?php the_content(); ?></div>
    <?php endwhile; endif; ?>
  </div>
</div>
<?php get_footer(); ?>

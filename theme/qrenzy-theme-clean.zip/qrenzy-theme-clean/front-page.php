<?php get_header(); ?>
<?php if(is_front_page()):
$org_schema = json_encode([
  '@context'        => 'https://schema.org',
  '@type'           => ['LocalBusiness','ProfessionalService'],
  '@id'             => 'https://www.qrenzy.com/#organization',
  'name'            => 'Qrenzy Digital Solutions',
  'alternateName'   => ['Qrenzy','Qrenzy Digital'],
  'url'             => 'https://www.qrenzy.com',
  'logo'            => ['@type'=>'ImageObject','url'=>'https://www.qrenzy.com/wp-content/uploads/2026/03/qrenzy-digital-solutions-logo-v1.png','width'=>280,'height'=>80],
  'image'           => 'https://www.qrenzy.com/wp-content/uploads/2026/03/qrenzy-digital-solutions-logo-v1.png',
  'description'     => "Qrenzy Digital Solutions is a full-service digital marketing agency founded in Thrissur, Kerala in 2020. We specialize in SEO, web design, social media marketing, Google Ads, AI marketing automation and photography & videography for businesses across India, Oman, UAE, Qatar and Bahrain.",
  'telephone'       => '+919905700600',
  'email'           => 'info@qrenzy.com',
  'foundingDate'    => '2020',
  'numberOfEmployees' => ['@type'=>'QuantitativeValue','minValue'=>5,'maxValue'=>20],
  'founder'         => ['@type'=>'Person','@id'=>'https://www.qrenzy.com/#founder','name'=>'Sajeesh V S','jobTitle'=>'Founder & Digital Marketing Strategist','url'=>'https://www.qrenzy.com/about/'],
  'address'         => ['@type'=>'PostalAddress','streetAddress'=>'5/427, Sankarmandam, Mundur P.O','addressLocality'=>'Thrissur','addressRegion'=>'Kerala','postalCode'=>'680541','addressCountry'=>'IN'],
  'geo'             => ['@type'=>'GeoCoordinates','latitude'=>10.5276,'longitude'=>76.2144],
  'openingHours'    => 'Mo-Sa 09:00-18:00',
  'priceRange'      => '₹₹',
  'currenciesAccepted' => 'INR, OMR, AED, QAR, BHD',
  'areaServed'      => [
    ['@type'=>'Country','name'=>'India','sameAs'=>'https://www.wikidata.org/wiki/Q668'],
    ['@type'=>'Country','name'=>'Oman','sameAs'=>'https://www.wikidata.org/wiki/Q842'],
    ['@type'=>'Country','name'=>'United Arab Emirates','sameAs'=>'https://www.wikidata.org/wiki/Q878'],
    ['@type'=>'Country','name'=>'Qatar','sameAs'=>'https://www.wikidata.org/wiki/Q846'],
    ['@type'=>'Country','name'=>'Bahrain','sameAs'=>'https://www.wikidata.org/wiki/Q398'],
    ['@type'=>'City','name'=>'Thrissur','sameAs'=>'https://www.wikidata.org/wiki/Q200263'],
    ['@type'=>'City','name'=>'Kochi','sameAs'=>'https://www.wikidata.org/wiki/Q42941'],
    ['@type'=>'City','name'=>'Muscat','sameAs'=>'https://www.wikidata.org/wiki/Q25211'],
    ['@type'=>'City','name'=>'Dubai','sameAs'=>'https://www.wikidata.org/wiki/Q612'],
  ],
  'sameAs'          => [
    'https://www.facebook.com/qrenzydigitalsolutions',
    'https://www.instagram.com/qrenzydigitalsolutions',
    'https://www.linkedin.com/company/qrenzy-digital-solutions',
    'https://www.youtube.com/@qrenzy',
    'https://clutch.co/profile/qrenzy-digital-solutions',
    'https://twitter.com/qrenzydigital',
    'https://www.crunchbase.com/organization/qrenzy-digital-solutions',
  ],
  'knowsAbout' => ['Search Engine Optimization','Local SEO','Google Business Profile','Social Media Marketing','Performance Marketing','AI Marketing Automation','Web Design','Digital Marketing','Content Marketing'],
  'hasOfferCatalog' => ['@type'=>'OfferCatalog','name'=>'Digital Marketing Services','itemListElement'=>[
    ['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'Search Engine Optimization','url'=>'https://www.qrenzy.com/search-engine-optimization/']],
    ['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'Local SEO & Google Business Profile','url'=>'https://www.qrenzy.com/local-seo/']],
    ['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'Web Design & Development','url'=>'https://www.qrenzy.com/web-designing/']],
    ['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'Social Media Marketing','url'=>'https://www.qrenzy.com/social-media-marketing/']],
    ['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'Performance Marketing','url'=>'https://www.qrenzy.com/pay-per-click/']],
    ['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'AI Marketing Automation','url'=>'https://www.qrenzy.com/ai-marketing-automation/']],
    ['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'Photography & Videography','url'=>'https://www.qrenzy.com/photography-videography/']],
    ['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'Graphic Design','url'=>'https://www.qrenzy.com/graphic-designing/']],
    ['@type'=>'Offer','itemOffered'=>['@type'=>'Service','name'=>'Software Solutions','url'=>'https://www.qrenzy.com/custom-software/']],
  ]],
  'aggregateRating' => ['@type'=>'AggregateRating','ratingValue'=>'4.9','reviewCount'=>'87','bestRating'=>'5','worstRating'=>'1'],
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);

// CaseStudy schema for homepage case studies
$casestudy_schema = json_encode([
  '@context' => 'https://schema.org',
  '@type'    => 'ItemList',
  'name'     => 'Qrenzy Digital Solutions — Client Results',
  'description' => 'Real digital marketing results delivered by Qrenzy Digital Solutions for clients across India and the Gulf.',
  'itemListElement' => [
    [
      '@type'       => 'ListItem',
      'position'    => 1,
      'item'        => [
        '@type'       => 'Article',
        '@id'         => 'https://www.qrenzy.com/#case-alfanar',
        'name'        => 'Al Fanar Group Oman — SEO & GBP Case Study',
        'description' => 'Monthly website traffic grew from 18 to 155+ organic clicks within 3 months. Brand now appears in AI-generated answers on ChatGPT and Google AI Overviews for key Oman product searches. Google Maps ranking improved from zero to Top 3.',
        'about'       => ['@type'=>'Organization','name'=>'Al Fanar Group','location'=>'Muscat, Oman'],
        'author'      => ['@type'=>'Organization','name'=>'Qrenzy Digital Solutions'],
        'publisher'   => ['@type'=>'Organization','name'=>'Qrenzy Digital Solutions','url'=>'https://www.qrenzy.com'],
      ],
    ],
    [
      '@type'       => 'ListItem',
      'position'    => 2,
      'item'        => [
        '@type'       => 'Article',
        '@id'         => 'https://www.qrenzy.com/#case-realestate',
        'name'        => 'Kerala Real Estate Developer — SEO & Google Ads Case Study',
        'description' => 'Achieved Page 1 rankings for 12 high-intent real estate keywords in Thrissur and Kochi within 4 months. Google Ads campaign delivered 4.2x ROAS generating qualified buyer leads.',
        'about'       => ['@type'=>'Organization','location'=>'Kerala, India'],
        'author'      => ['@type'=>'Organization','name'=>'Qrenzy Digital Solutions'],
        'publisher'   => ['@type'=>'Organization','name'=>'Qrenzy Digital Solutions','url'=>'https://www.qrenzy.com'],
      ],
    ],
    [
      '@type'       => 'ListItem',
      'position'    => 3,
      'item'        => [
        '@type'       => 'Article',
        '@id'         => 'https://www.qrenzy.com/#case-restaurant',
        'name'        => 'Calicut Restaurant Chain — Google Maps & Instagram Case Study',
        'description' => 'Moved from position 8 to position 2 in Google Maps for restaurants in Calicut. Instagram grew from 1,200 to 8,400 followers in 5 months. Monthly footfall increased 40% attributed to digital marketing.',
        'about'       => ['@type'=>'FoodEstablishment','location'=>'Calicut, Kerala, India'],
        'author'      => ['@type'=>'Organization','name'=>'Qrenzy Digital Solutions'],
        'publisher'   => ['@type'=>'Organization','name'=>'Qrenzy Digital Solutions','url'=>'https://www.qrenzy.com'],
      ],
    ],
  ],
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
?>
<script type="application/ld+json"><?php echo $org_schema; ?></script>
<script type="application/ld+json"><?php echo $casestudy_schema; ?></script>

<?php
// ── WEBSITE + SEARCH ACTION (enables Google Sitelinks Search Box) ─────
$website_schema = json_encode([
  '@context' => 'https://schema.org',
  '@type'    => 'WebSite',
  '@id'      => 'https://www.qrenzy.com/#website',
  'url'      => 'https://www.qrenzy.com',
  'name'     => 'Qrenzy Digital Solutions',
  'description' => 'AI-powered digital marketing agency in Thrissur, Kerala — SEO, web design, social media & performance ads for India, Oman and UAE.',
  'publisher' => ['@id' => 'https://www.qrenzy.com/#organization'],
  'inLanguage' => 'en-US',
  'potentialAction' => [
    '@type'       => 'SearchAction',
    'target'      => ['@type'=>'EntryPoint','urlTemplate'=>'https://www.qrenzy.com/?s={search_term_string}'],
    'query-input' => 'required name=search_term_string',
  ],
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);

// ── SITE NAVIGATION ELEMENT (signals sitelinks to Google) ────────────
$nav_schema = json_encode([
  '@context' => 'https://schema.org',
  '@type'    => 'ItemList',
  'name'     => 'Qrenzy Digital Solutions — Main Navigation',
  'itemListElement' => [
    ['@type'=>'SiteLinksSearchBox','target'=>['@type'=>'EntryPoint','urlTemplate'=>'https://www.qrenzy.com/?s={search_term_string}']],
  ],
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);

// ── SITE NAVIGATION LINKS (sitelinks signal) ─────────────────────────
$sitelinks_schema = json_encode([
  '@context' => 'https://schema.org',
  '@graph'   => [
    ['@type'=>'SiteNavigationElement','@id'=>'https://www.qrenzy.com/#nav-seo','name'=>'Search Engine Optimization','url'=>'https://www.qrenzy.com/search-engine-optimization/','description'=>'Data-driven SEO services for businesses in India, Oman and UAE'],
    ['@type'=>'SiteNavigationElement','@id'=>'https://www.qrenzy.com/#nav-web','name'=>'Web Design & Development','url'=>'https://www.qrenzy.com/web-designing/','description'=>'Fast-loading, SEO-ready WordPress websites that convert visitors into customers'],
    ['@type'=>'SiteNavigationElement','@id'=>'https://www.qrenzy.com/#nav-smm','name'=>'Social Media Marketing','url'=>'https://www.qrenzy.com/social-media-marketing/','description'=>'Strategic social media management across Instagram, Facebook and LinkedIn'],
    ['@type'=>'SiteNavigationElement','@id'=>'https://www.qrenzy.com/#nav-ppc','name'=>'Performance Marketing','url'=>'https://www.qrenzy.com/pay-per-click/','description'=>'Google Ads and Meta Ads with precision targeting for maximum ROI'],
    ['@type'=>'SiteNavigationElement','@id'=>'https://www.qrenzy.com/#nav-ai','name'=>'AI Marketing Automation','url'=>'https://www.qrenzy.com/ai-marketing-automation/','description'=>'AI-powered marketing workflows, chatbots and content automation'],
    ['@type'=>'SiteNavigationElement','@id'=>'https://www.qrenzy.com/#nav-local','name'=>'Local SEO & Google Business','url'=>'https://www.qrenzy.com/local-seo/','description'=>'Google Business Profile optimisation and local SEO for Google Maps'],
    ['@type'=>'SiteNavigationElement','@id'=>'https://www.qrenzy.com/#nav-photo','name'=>'Photography & Videography','url'=>'https://www.qrenzy.com/photography-videography/','description'=>'Professional product, corporate and real estate photography and video'],
    ['@type'=>'SiteNavigationElement','@id'=>'https://www.qrenzy.com/#nav-design','name'=>'Graphic Design','url'=>'https://www.qrenzy.com/graphic-designing/','description'=>'Logos, branding, social media creatives and print design'],
    ['@type'=>'SiteNavigationElement','@id'=>'https://www.qrenzy.com/#nav-software','name'=>'Software Solutions','url'=>'https://www.qrenzy.com/custom-software/','description'=>'Custom web apps, CRMs and business automation tools'],
    ['@type'=>'SiteNavigationElement','@id'=>'https://www.qrenzy.com/#nav-contact','name'=>'Contact Us','url'=>'https://www.qrenzy.com/contact/','description'=>'Get in touch with Qrenzy Digital Solutions'],
    ['@type'=>'SiteNavigationElement','@id'=>'https://www.qrenzy.com/#nav-audit','name'=>'Free SEO Audit','url'=>'https://www.qrenzy.com/free-seo-audit/','description'=>'Get a comprehensive free SEO audit for your website'],
  ],
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);

// ── CONTACT POINT (phone number in search results) ────────────────────
$contact_schema = json_encode([
  '@context' => 'https://schema.org',
  '@type'    => 'Organization',
  '@id'      => 'https://www.qrenzy.com/#organization',
  'name'     => 'Qrenzy Digital Solutions',
  'url'      => 'https://www.qrenzy.com',
  'contactPoint' => [
    [
      '@type'             => 'ContactPoint',
      'telephone'         => '+91-99057-00600',
      'contactType'       => 'customer service',
      'areaServed'        => ['IN','OM','AE','QA','BH'],
      'availableLanguage' => ['English','Malayalam'],
      'contactOption'     => 'TollFree',
      'hoursAvailable'    => ['@type'=>'OpeningHoursSpecification','dayOfWeek'=>['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],'opens'=>'09:00','closes'=>'18:00'],
    ],
    [
      '@type'       => 'ContactPoint',
      'telephone'   => '+91-99057-00600',
      'contactType' => 'sales',
      'areaServed'  => ['IN','OM','AE','QA','BH'],
      'availableLanguage' => ['English','Malayalam'],
    ],
  ],
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);

// ── FOUNDER / PERSON SCHEMA (AI citation & Knowledge Panel) ──────────
$person_schema = json_encode([
  '@context'    => 'https://schema.org',
  '@type'       => 'Person',
  '@id'         => 'https://www.qrenzy.com/#founder',
  'name'        => 'Sajeesh Vaderiyattil Sahadevan',
  'givenName'   => 'Sajeesh Vaderiyattil',
  'familyName'  => 'Sahadevan',
  'jobTitle'    => 'Founder & Digital Marketing Strategist',
  'description' => 'Sajeesh V S is a digital marketing strategist and the founder of Qrenzy Digital Solutions, based in Thrissur, Kerala. With 18+ years of experience in IT infrastructure, SEO, web development and AI marketing automation, he serves clients across India, Oman, UAE, Qatar and Bahrain.',
  'url'         => 'https://www.qrenzy.com/about/',
  'worksFor'    => ['@id'=>'https://www.qrenzy.com/#organization'],
  'alumniOf'    => ['@type'=>'Organization','name'=>'Al Fanar Group','url'=>'https://alfanar.om'],
  'knowsAbout'  => ['Search Engine Optimization','Generative Engine Optimization','Answer Engine Optimization','Web Development','WordPress','Social Media Marketing','Google Ads','Meta Ads','AI Marketing Automation','Digital Marketing'],
  'sameAs'      => [
    'https://www.linkedin.com/in/sajeeshvs',
    'https://www.qrenzy.com/about/',
  ],
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);

// ── FAQ SCHEMA FOR HOMEPAGE (AI citations) ────────────────────────────
$faq_schema = json_encode([
  '@context'   => 'https://schema.org',
  '@type'      => 'FAQPage',
  'mainEntity' => [
    ['@type'=>'Question','name'=>'What is Qrenzy Digital Solutions?','acceptedAnswer'=>['@type'=>'Answer','text'=>'Qrenzy Digital Solutions is a full-service digital marketing agency based in Thrissur, Kerala, India. Founded in 2020 by Sajeesh V S, we provide SEO, web design, social media marketing, performance advertising, AI marketing automation and graphic design to businesses across India, Oman, UAE, Qatar and Bahrain.']],
    ['@type'=>'Question','name'=>'Where is Qrenzy Digital Solutions located?','acceptedAnswer'=>['@type'=>'Answer','text'=>'Qrenzy Digital Solutions is headquartered at 5/427, Sankarmandam, Mundur P.O, Thrissur, Kerala, India — 680541. We serve clients remotely across India, Oman, UAE, Qatar and Bahrain.']],
    ['@type'=>'Question','name'=>'What digital marketing services does Qrenzy offer?','acceptedAnswer'=>['@type'=>'Answer','text'=>'Qrenzy offers Search Engine Optimization (SEO), Local SEO and Google Business Profile management, Web Design and Development, Social Media Marketing, Performance Marketing (Google Ads and Meta Ads), AI Marketing Automation, Photography and Videography, Graphic Design, and Software Solutions.']],
    ['@type'=>'Question','name'=>'How much does digital marketing cost in Kerala?','acceptedAnswer'=>['@type'=>'Answer','text'=>'Digital marketing costs at Qrenzy start from ₹8,000 per month for SEO and social media management. Website development packages start from ₹10,000 including hosting and domain. Pricing varies based on scope and requirements.']],
    ['@type'=>'Question','name'=>'Does Qrenzy serve businesses in Oman and UAE?','acceptedAnswer'=>['@type'=>'Answer','text'=>'Yes. Qrenzy Digital Solutions has been serving businesses in Oman, UAE, Qatar and Bahrain since 2020. We provide bilingual digital marketing in English and Arabic with deep understanding of Gulf consumer behaviour.']],
    ['@type'=>'Question','name'=>'How long does SEO take to show results?','acceptedAnswer'=>['@type'=>'Answer','text'=>'Most businesses see measurable improvements in Google rankings within 8 to 12 weeks. Significant organic traffic growth typically happens within 3 to 6 months of consistent SEO work.']],
    ['@type'=>'Question','name'=>'Who is the founder of Qrenzy Digital Solutions?','acceptedAnswer'=>['@type'=>'Answer','text'=>'Qrenzy Digital Solutions was founded by Sajeesh V S, a digital marketing strategist with 18+ years of experience in IT infrastructure, SEO, web development and AI marketing automation based in Thrissur, Kerala.']],
  ],
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);

// ── BREADCRUMB FOR HOMEPAGE ───────────────────────────────────────────
$breadcrumb_schema = json_encode([
  '@context'        => 'https://schema.org',
  '@type'           => 'BreadcrumbList',
  'itemListElement' => [
    ['@type'=>'ListItem','position'=>1,'name'=>'Home','item'=>'https://www.qrenzy.com/'],
  ],
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);

// ── SPEAKABLE SCHEMA (voice search / AI) ─────────────────────────────
$speakable_schema = json_encode([
  '@context'  => 'https://schema.org',
  '@type'     => 'WebPage',
  '@id'       => 'https://www.qrenzy.com/#webpage',
  'url'       => 'https://www.qrenzy.com',
  'name'      => 'Qrenzy Digital Solutions — Digital Marketing Agency in Kerala',
  'speakable' => [
    '@type'    => 'SpeakableSpecification',
    'cssSelector' => ['.hero-title','.hero-desc','.section-title'],
  ],
  'about'     => ['@id'=>'https://www.qrenzy.com/#organization'],
  'isPartOf'  => ['@id'=>'https://www.qrenzy.com/#website'],
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
?>
<script type="application/ld+json"><?php echo $website_schema; ?></script>
<script type="application/ld+json"><?php echo $sitelinks_schema; ?></script>
<script type="application/ld+json"><?php echo $contact_schema; ?></script>
<script type="application/ld+json"><?php echo $person_schema; ?></script>
<script type="application/ld+json"><?php echo $faq_schema; ?></script>
<script type="application/ld+json"><?php echo $breadcrumb_schema; ?></script>
<script type="application/ld+json"><?php echo $speakable_schema; ?></script>
<?php endif; ?>


<!-- HERO -->
<section class="hero-section">
  <div class="wrap">
    <div class="hero-grid">
      <div class="hero-content">
        <div class="hero-location">Thrissur, Kerala, India &mdash; Est. 2020</div>
        <h1 class="hero-title">Digital Marketing Agency<br><span class="red">in Kerala &amp; Thrissur</span></h1>
        <p class="hero-desc">AI-powered SEO, social media marketing &amp; performance ads — for businesses in <strong>Thrissur, Kerala, India, Oman &amp; UAE</strong> and clients worldwide.</p>
        <div class="hero-geo">
          <span class="geo-badge">🇮🇳 India</span>
          <span class="geo-badge">🇴🇲 Oman</span>
          <span class="geo-badge">🇦🇪 UAE</span>
          <span class="geo-badge">🇧🇭 Bahrain</span>
          <span class="geo-badge">🌐 Worldwide</span>
        </div>
        <div class="hero-btns">
          <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-primary">🚀 Get Free Strategy Call</a>
          <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-wa" rel="noopener" target="_blank">💬 WhatsApp Us</a>
        </div>
        <div class="hero-trust">
          <div class="trust-avatars">
            <span style="background:#E31E24">AK</span>
            <span style="background:#1565C0">RM</span>
            <span style="background:#2E7D32">PS</span>
            <span style="background:#E65100">JM</span>
          </div>
          <div>
            <div class="trust-stars">★★★★★</div>
            <div class="trust-text"><strong>200+ businesses</strong> trust Qrenzy<br><span style="font-size:11px">India &bull; Oman &bull; UAE &bull; Worldwide</span></div>
          </div>
        </div>
      </div>
      <div class="hero-card-wrap">
        <div class="dashboard-card">
          <div class="dash-header">
            <span class="dash-title">Campaign Performance</span>
            <span class="dash-live">Live</span>
          </div>
          <div class="dash-grid">
            <div class="dash-cell"><div class="dash-label">Organic Traffic</div><div class="dash-num"><span class="counter" data-target="284" data-prefix="+">0</span>% <span class="up">↑ vs last quarter</span></div></div>
            <div class="dash-cell"><div class="dash-label">Keywords Ranked</div><div class="dash-num"><span class="counter" data-target="5200" data-suffix="+">0</span> <span class="up">↑ +340 this month</span></div></div>
            <div class="dash-cell"><div class="dash-label">Leads Generated</div><div class="dash-num"><span class="counter" data-target="1840">0</span> <span class="up">↑ +22% MoM</span></div></div>
            <div class="dash-cell"><div class="dash-label">Avg. ROAS</div><div class="dash-num"><span class="counter" data-target="4.8" data-decimal="1" data-suffix="x">0</span> <span class="up">↑ Google &amp; Meta</span></div></div>
          </div>
          <?php
          $bars = [['SEO Performance','92','#E31E24'],['Social Engagement','78','#1565C0'],['Paid Ads ROI','86','#16A34A'],['Content Reach','71','#F59E0B']];
          foreach($bars as $b): ?>
          <div class="dash-bar-row">
            <div class="dash-bar-label"><span><?php echo $b[0]; ?></span><span><?php echo $b[1]; ?>%</span></div>
            <div class="dash-bar-track"><div class="dash-bar-fill" style="width:0%;background:<?php echo $b[2]; ?>" data-width="<?php echo $b[1]; ?>"></div></div>
          </div>
          <?php endforeach; ?>
          <div class="dash-footer">🇮🇳 🇴🇲 🇦🇪 Active: India • Oman • UAE</div>
        </div>
      </div>
    </div>
  </div>
</section>


<script>
(function(){
  // ── Intersection Observer — triggers when card enters viewport ──
  var card = document.querySelector('.dashboard-card');
  if(!card) return;
  var animated = false;

  function runAnimations(){
    if(animated) return;
    animated = true;

    // Counter animation
    document.querySelectorAll('.counter').forEach(function(el){
      var target   = parseFloat(el.dataset.target);
      var prefix   = el.dataset.prefix  || '';
      var suffix   = el.dataset.suffix  || '';
      var decimal  = parseInt(el.dataset.decimal || 0);
      var duration = 1800;
      var start    = null;

      function step(ts){
        if(!start) start = ts;
        var progress = Math.min((ts - start) / duration, 1);
        // Ease out cubic
        var ease = 1 - Math.pow(1 - progress, 3);
        var val  = target * ease;
        var display = decimal ? val.toFixed(decimal) : Math.floor(val).toLocaleString();
        el.textContent = prefix + display + suffix;
        if(progress < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
    });

    // Progress bar animation
    document.querySelectorAll('.dash-bar-fill').forEach(function(bar){
      var w = bar.dataset.width;
      bar.style.transition = 'width 1.4s cubic-bezier(0.4,0,0.2,1)';
      setTimeout(function(){ bar.style.width = w + '%'; }, 200);
    });
  }

  // Use IntersectionObserver to trigger when visible
  if('IntersectionObserver' in window){
    var obs = new IntersectionObserver(function(entries){
      entries.forEach(function(e){ if(e.isIntersecting) runAnimations(); });
    }, { threshold: 0.3 });
    obs.observe(card);
  } else {
    runAnimations(); // fallback
  }
})();
</script>

<!-- TICKER -->
<div class="ticker-wrap" aria-hidden="true">
  <div class="ticker-inner">
    <?php $items = ['AI Marketing 2026 Ready','200+ Happy Clients','Thrissur • Oman • UAE','5,000+ Keywords Ranked','Google Ads 4.8x ROAS','SEO Agency','Social Media Growth','Web Design','Performance Marketing']; ?>
    <?php for($r=0;$r<4;$r++): foreach($items as $item): ?>
    <span class="ticker-item"><?php echo $item; ?></span>
    <?php endforeach; endfor; ?>
  </div>
</div>

<!-- STATS -->
<div class="stats-bar">
  <div class="wrap">
    <div class="stats-grid">
      <div class="stat-cell"><div class="stat-num">200+</div><div class="stat-label">Happy Clients</div><div class="stat-sub">India, Gulf &amp; Beyond</div></div>
      <div class="stat-cell"><div class="stat-num">15+</div><div class="stat-label">Years Experience</div><div class="stat-sub">Since 2012</div></div>
      <div class="stat-cell"><div class="stat-num">5K+</div><div class="stat-label">Keywords Ranked</div><div class="stat-sub">India &amp; Gulf</div></div>
      <div class="stat-cell"><div class="stat-num red">4.8x</div><div class="stat-label">Average ROAS</div><div class="stat-sub">Google &amp; Meta</div></div>
    </div>
  </div>
</div>

<!-- ABOUT QRENZY -->
<section style="padding:72px 0;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center">
      <div>
        <div class="section-tag">✦ About Qrenzy Digital Solutions</div>
        <h2 class="section-title" style="margin:12px 0 20px">Kerala's Most Trusted Digital Marketing Agency</h2>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:16px">Qrenzy Digital Solutions is a full-service digital marketing agency founded in Thrissur, Kerala in 2020. Over the past five years, we have grown from a boutique local agency into a multi-market digital marketing partner serving businesses across India, Oman, UAE, Qatar and Bahrain.</p>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:16px">We were founded on a simple belief: that small and medium businesses in India and the Gulf deserve the same quality of digital marketing strategy that large corporations receive. Too many SMEs are sold generic SEO packages, templated social media posts and ad campaigns built without any real understanding of their market. Qrenzy exists to change that.</p>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:28px">Our team brings 18+ years of combined experience across IT infrastructure, SEO, web development, social media marketing, performance advertising and AI marketing automation. Every client — from a Thrissur jewellery retailer to an Oman-based interior design company — receives a strategy built specifically for their market, their audience and their business goals.</p>
        <div style="display:flex;gap:12px;flex-wrap:wrap">
          <a href="<?php echo home_url('/why-us/'); ?>" class="btn-primary">Why Choose Qrenzy →</a>
          <a href="<?php echo home_url('/free-seo-audit/'); ?>" style="display:inline-flex;align-items:center;gap:8px;border:2px solid #0a0a0a;color:#0a0a0a;padding:12px 22px;border-radius:100px;font-size:14px;font-weight:700;text-decoration:none">Get Free SEO Audit</a>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
        <?php
        $about_stats = [
          ['200+','Businesses Served','Across India & the Gulf','#E31E24'],
          ['18+','Years Experience','In Digital Marketing','#1565C0'],
          ['5,000+','Keywords Ranked','On Google Page 1','#2E7D32'],
          ['4.9★','Client Rating','Average Across All Reviews','#D97706'],
          ['5','Countries','India, Oman, UAE, Qatar, Bahrain','#7C3AED'],
          ['90 Days','Avg. Results Timeline','From Onboarding to ROI','#0891B2'],
        ];
        foreach($about_stats as $as): ?>
        <div style="background:#f8f8f6;border:1px solid #e8e8e4;border-radius:16px;padding:20px;border-top:3px solid <?php echo $as[3]; ?>">
          <div style="font-size:24px;font-weight:900;color:<?php echo $as[3]; ?>;letter-spacing:-0.02em;line-height:1"><?php echo $as[0]; ?></div>
          <div style="font-size:13px;font-weight:800;color:#0a0a0a;margin:6px 0 3px"><?php echo $as[1]; ?></div>
          <div style="font-size:11px;color:#888"><?php echo $as[2]; ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section class="services-section" id="services">
  <div class="wrap">
    <div class="section-row">
      <div class="section-header">
        <div class="section-tag">✦ What We Do</div>
        <h2 class="section-title">Services Built to Grow<br>Your Business</h2>
        <p class="section-desc">Every service laser-focused on measurable ROI for clients in Thrissur, Kerala, India, Oman, UAE and globally.</p>
      </div>
      <a href="<?php echo home_url('/services/'); ?>" class="btn-ghost">All Services →</a>
    </div>
    <div class="services-grid">
      <?php
      $services = [
        ['🔍','Search Engine Optimization','Data-driven keyword strategy and content that dominates Google across India, Oman and UAE.','/search-engine-optimization/'],
        ['🌐','Web Design & Development','Fast-loading, SEO-ready WordPress sites and landing pages designed to convert visitors.','/web-designing/'],
        ['📱','Social Media Marketing','Strategic content, audience growth and campaigns across Facebook, Instagram, LinkedIn and YouTube.','/social-media-marketing/'],
        ['🎯','Performance Marketing','Google Ads and Meta Ads with precision targeting for maximum ROI on every rupee invested.','/pay-per-click/'],
        ['🤖','AI Marketing Automation','Automate your marketing workflows with AI — content, scheduling, reporting and lead nurturing.','/ai-marketing-automation/'],
        ['📸','Photography & Videography','Professional product, corporate and real estate photography and video production.','/photography-videography/'],
        ['🎨','Graphic Design','Logos, branding, social media creatives and print — designs that tell your brand story.','/graphic-designing/'],
        ['💻','Software Solutions','Custom web apps, CRMs, booking systems and business automation tools built in India.','/ai-marketing-automation/'],
      ];
      foreach($services as $s): ?>
      <div class="service-card">
        <span class="service-icon"><?php echo $s[0]; ?></span>
        <h3 class="service-name"><?php echo $s[1]; ?></h3>
        <p class="service-desc"><?php echo $s[2]; ?></p>
        <a href="<?php echo home_url($s[3]); ?>" class="service-link">Explore →</a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- SERVICES DEEP DIVE -->
<section style="padding:80px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:56px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ What We Actually Do</div>
      <h2 class="section-title">Full-Service Digital Marketing<br>Built for Results</h2>
      <p class="section-desc" style="max-width:580px;margin:12px auto 0">Every service works together as a system — SEO drives traffic, social builds awareness, paid ads accelerate growth, and great design converts it all into customers.</p>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
      <?php
      $deep_services = [
        ['🔍','Search Engine Optimization (SEO)','#E31E24','/search-engine-optimization/','Our SEO service covers the complete spectrum — technical audits fixing crawl errors, page speed and Core Web Vitals; on-page optimization with keyword-rich content and schema markup; local SEO for Google Maps dominance; and off-page link building from relevant, authoritative websites. We have ranked 5,000+ keywords for clients across India, Oman and UAE, delivering sustained organic traffic growth without ongoing ad spend.'],
        ['🌐','Web Design & Development','#1565C0','/web-designing/','We build WordPress websites that are fast, secure and designed to convert visitors into enquiries. Every site we build scores 90+ on Google PageSpeed, is fully mobile-responsive and includes technical SEO built in from day one — not bolted on afterwards. Our web design process combines strategic UX thinking with clean, professional visual design that positions your brand credibly in your market.'],
        ['📱','Social Media Marketing','#7C3AED','/social-media-marketing/','Strategic social media management across Instagram, Facebook, LinkedIn and YouTube. We create content calendars tuned to your audience, produce scroll-stopping graphics and videos, manage community engagement and run targeted organic growth campaigns. Our social media strategies are built around real business outcomes — leads, website traffic and brand authority — not vanity metrics like follower counts.'],
        ['🎯','Performance Marketing','#D97706','/pay-per-click/','Data-driven paid advertising across Google Ads, Meta Ads (Facebook & Instagram), and other platforms. We manage campaigns from keyword research and audience setup through to ad creative, landing page optimization and continuous bid management. Our average ROAS across active campaigns is 4.8× — meaning for every ₹1 invested in ads, our clients generate ₹4.80 in revenue on average.'],
        ['🤖','AI Marketing Automation','#0891B2','/ai-marketing-automation/','We automate your marketing workflows using AI — from WhatsApp chatbots that capture and qualify leads 24/7, to AI-assisted content pipelines that produce blog posts, social captions and email newsletters at scale. AI automation reduces your team\'s manual workload, improves response speed to leads, and ensures your marketing runs consistently even outside business hours.'],
        ['🎨','Graphic Design & Branding','#059669','/graphic-designing/','Professional brand identity and visual design — logos, brand guidelines, social media templates, brochures, presentations and all marketing collateral. Our design work is built around your brand positioning and target audience, ensuring every visual asset reinforces your credibility and communicates your value proposition clearly. Consistent, professional design is one of the most undervalued conversion drivers in digital marketing.'],
      ];
      foreach($deep_services as $ds): ?>
      <div style="background:#fff;border:1px solid #e8e8e4;border-radius:20px;padding:28px;position:relative;overflow:hidden;transition:box-shadow 0.2s"
           onmouseover="this.style.boxShadow='0 16px 48px rgba(0,0,0,0.08)'"
           onmouseout="this.style.boxShadow='none'">
        <div style="position:absolute;top:0;left:0;right:0;height:3px;background:<?php echo $ds[2]; ?>"></div>
        <div style="display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;background:<?php echo $ds[2]; ?>15;border-radius:14px;font-size:22px;margin-bottom:16px"><?php echo $ds[0]; ?></div>
        <h3 style="font-size:17px;font-weight:800;color:#0a0a0a;margin-bottom:10px"><?php echo $ds[1]; ?></h3>
        <p style="font-size:14px;color:#555;line-height:1.8;margin-bottom:18px"><?php echo $ds[4]; ?></p>
        <a href="<?php echo home_url($ds[3]); ?>" style="display:inline-flex;align-items:center;gap:6px;font-size:13px;font-weight:700;color:<?php echo $ds[2]; ?>;text-decoration:none">Learn more →</a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- WHY US -->
<section class="why-section" id="why">
  <div class="wrap">
    <div class="why-grid">
      <div>
        <div class="section-tag">✦ Why Choose Us</div>
        <h2 class="section-title" style="margin-bottom:32px">Results-Driven Agency<br>You Can Trust</h2>
        <div class="why-cards">
          <?php
          $cards = [
            ['🌍','India + Gulf Expertise','We operate across Kerala, Oman and UAE — we understand both markets deeply.'],
            ['📊','Data-Driven Strategy','Every decision backed by real data. No guesswork, no vanity metrics.'],
            ['🤖','AI-Powered Tools','We use cutting-edge AI tools to deliver faster, smarter results.'],
            ['🏆','Proven Track Record','200+ clients, 5K+ keywords ranked, 4.8× average ROAS across campaigns.'],
          ];
          foreach($cards as $c): ?>
          <div class="why-card">
            <div class="why-card-icon"><?php echo $c[0]; ?></div>
            <div class="why-card-title"><?php echo $c[1]; ?></div>
            <p class="why-card-desc"><?php echo $c[2]; ?></p>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="process-panel">
        <h3>How We Work</h3>
        <?php
        $steps = [
          ['01','Free Strategy Call','We understand your business, goals and target markets.'],
          ['02','Custom Plan','We build a tailored strategy with clear KPIs and timelines.'],
          ['03','Execute & Optimise','We launch campaigns and continuously optimise for results.'],
          ['04','Report & Scale','Monthly reports, insights and scaling what works.'],
        ];
        foreach($steps as $s): ?>
        <div class="process-step">
          <div class="step-num"><?php echo $s[0]; ?></div>
          <div class="step-info"><h4><?php echo $s[1]; ?></h4><p><?php echo $s[2]; ?></p></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- WHY DIGITAL MARKETING -->
<section style="padding:72px 0;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center">
      <div>
        <div class="section-tag">✦ The Opportunity</div>
        <h2 class="section-title" style="margin:12px 0 20px">Why Digital Marketing Is the Smartest Investment for Your Business</h2>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:16px">India has over 850 million internet users — and that number grows every year. In Kerala alone, internet penetration exceeds 75%, with most users accessing the web primarily through smartphones. In Oman and the UAE, internet penetration exceeds 95%. Your potential customers are online, searching for your products and services every day.</p>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:16px">The businesses that capture this demand — by appearing on the first page of Google, maintaining an active and credible social media presence, and running well-targeted paid campaigns — consistently outgrow their competitors who rely on traditional marketing alone. Digital marketing delivers measurable, trackable ROI that traditional advertising cannot match.</p>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:28px">SEO alone delivers an average ROI of 700% over 12 months for businesses that invest consistently. Google Ads delivers immediate visibility to customers with purchase intent. Social media builds the brand trust that converts curious visitors into loyal customers. When these channels work together under a unified strategy — which is exactly what Qrenzy delivers — the results compound significantly.</p>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
        <?php
        $dm_stats = [
          ['850M+','Internet users in India actively searching for businesses online','#E31E24','🌐'],
          ['46%','Of all Google searches have local intent — people looking for nearby businesses','#1565C0','📍'],
          ['700%','Average ROI from SEO investment over 12 months for consistent practitioners','#2E7D32','📈'],
          ['4.8×','Qrenzy\'s average ROAS across Google Ads and Meta Ads campaigns','#D97706','🎯'],
          ['76%','Of people who search locally on mobile visit a business within 24 hours','#7C3AED','📱'],
          ['95%+','Internet penetration in Oman and UAE — your Gulf customers are fully online','#0891B2','🌍'],
        ];
        foreach($dm_stats as $st): ?>
        <div style="background:#f8f8f6;border:1px solid #e8e8e4;border-radius:16px;padding:20px;transition:box-shadow 0.2s"
             onmouseover="this.style.boxShadow='0 8px 24px rgba(0,0,0,0.06)'"
             onmouseout="this.style.boxShadow='none'">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
            <div style="width:36px;height:36px;border-radius:10px;background:<?php echo $st[2]; ?>15;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0"><?php echo $st[3]; ?></div>
            <div style="font-size:22px;font-weight:900;color:<?php echo $st[2]; ?>;letter-spacing:-0.02em;line-height:1"><?php echo $st[0]; ?></div>
          </div>
          <p style="font-size:12px;color:#666;line-height:1.55;margin:0"><?php echo $st[1]; ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- INDUSTRIES -->
<section style="padding:80px 0;background:#0a0a0a;overflow:hidden">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:56px">
      <div class="section-tag" style="display:table;margin:0 auto 14px;background:rgba(227,30,36,0.15);border-color:rgba(227,30,36,0.3);color:#E31E24">✦ Industries We Serve</div>
      <h2 class="section-title" style="color:#fff">We've Grown Businesses Across<br>Every Major Industry</h2>
      <p class="section-desc" style="color:rgba(255,255,255,0.5);max-width:520px;margin:12px auto 0">From Kerala's gold jewellery sector to Oman's hospitality industry — deep expertise across 15 business verticals.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:14px">
      <?php
      $industries = [
        ['💎','Jewellery & Retail',   '#F59E0B'],
        ['🏥','Healthcare & Clinics', '#E31E24'],
        ['🏫','Education & Coaching', '#1565C0'],
        ['🏗️','Real Estate',          '#2E7D32'],
        ['🍽️','Restaurants & F&B',   '#BE185D'],
        ['✈️','Tourism & Hospitality','#0891B2'],
        ['🏭','Manufacturing',        '#7C3AED'],
        ['💻','IT & Software',        '#4F46E5'],
        ['👗','Fashion & Lifestyle',  '#D97706'],
        ['🔧','Professional Services','#059669'],
        ['🛒','E-commerce',           '#E31E24'],
        ['🏢','Corporate & B2B',      '#1565C0'],
        ['🚗','Automotive',           '#374151'],
        ['🏋️','Fitness & Wellness',   '#BE185D'],
        ['🏦','Finance & Insurance',  '#2E7D32'],
      ];
      foreach($industries as $ind): ?>
      <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:18px;padding:22px 16px;text-align:center;transition:all 0.25s;cursor:default"
           onmouseover="this.style.background='rgba(255,255,255,0.09)';this.style.borderColor='<?php echo $ind[2]; ?>55';this.style.transform='translateY(-3px)'"
           onmouseout="this.style.background='rgba(255,255,255,0.04)';this.style.borderColor='rgba(255,255,255,0.08)';this.style.transform='translateY(0)'">
        <!-- Icon frame with color -->
        <div style="width:52px;height:52px;border-radius:14px;background:<?php echo $ind[2]; ?>20;border:1px solid <?php echo $ind[2]; ?>40;display:flex;align-items:center;justify-content:center;font-size:22px;margin:0 auto 12px">
          <?php echo $ind[0]; ?>
        </div>
        <h3 style="font-size:12px;font-weight:700;color:#fff;line-height:1.3;margin:0"><?php echo $ind[1]; ?></h3>
        <div style="width:20px;height:2px;background:<?php echo $ind[2]; ?>;border-radius:2px;margin:8px auto 0"></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CASE STUDIES -->
<section style="padding:72px 0;background:#fff">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 12px">✦ Client Results</div>
      <h2 class="section-title">Real Results for Real Businesses</h2>
      <p class="section-desc" style="max-width:560px;margin:10px auto 0">Not promises — proof. Here's what Qrenzy's digital marketing strategies have delivered for businesses like yours.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:24px">
      <?php
      $cases = [
        ['🏪','Oman Retail Brand — Al Fanar Group','SEO + GBP + Content Marketing','Monthly website traffic grew from 18 to 155+ clicks within 3 months of consistent SEO and Google Business Profile optimization. The brand now appears in AI-generated answers on ChatGPT and Google AI Overviews for key Oman product searches.','155+','Monthly Organic Clicks','0 → 3','Google Maps Pack Ranking','#E31E24'],
        ['🏠','Kerala Real Estate Developer','SEO + Google Ads + Landing Pages','Achieved Page 1 rankings for 12 high-intent real estate keywords in Thrissur and Kochi within 4 months. Google Ads campaign delivered 4.2× ROAS, generating qualified buyer leads at a significantly lower cost than previous agency.','Page 1','12 Keywords Ranked','4.2×','Google Ads ROAS','#1565C0'],
        ['🍽️','Calicut Restaurant Chain','Google Business Profile + Instagram + Meta Ads','Moved from position 8 to position 2 in Google Maps for "restaurants in Calicut". Instagram grew from 1,200 to 8,400 followers in 5 months. Monthly footfall increased by 40% attributed to digital marketing.','#2 Rank','Google Maps Calicut','8,400','Instagram Followers','#2E7D32'],
      ];
      foreach($cases as $case): ?>
      <div style="border:1px solid #e8e8e4;border-radius:20px;overflow:hidden">
        <div style="background:<?php echo $case[8]; ?>;padding:20px 24px">
          <div style="font-size:28px;margin-bottom:8px"><?php echo $case[0]; ?></div>
          <h3 style="font-size:16px;font-weight:800;color:#fff;margin-bottom:4px"><?php echo $case[1]; ?></h3>
          <div style="font-size:12px;color:rgba(255,255,255,0.7)"><?php echo $case[2]; ?></div>
        </div>
        <div style="padding:24px">
          <p style="font-size:13px;color:#555;line-height:1.7;margin-bottom:20px"><?php echo $case[3]; ?></p>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div style="background:#f8f8f6;border-radius:12px;padding:14px;text-align:center">
              <div style="font-size:18px;font-weight:900;color:<?php echo $case[8]; ?>"><?php echo $case[4]; ?></div>
              <div style="font-size:11px;color:#888;margin-top:3px"><?php echo $case[5]; ?></div>
            </div>
            <div style="background:#f8f8f6;border-radius:12px;padding:14px;text-align:center">
              <div style="font-size:18px;font-weight:900;color:<?php echo $case[8]; ?>"><?php echo $case[6]; ?></div>
              <div style="font-size:11px;color:#888;margin-top:3px"><?php echo $case[7]; ?></div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- BLOG -->
<section class="blog-section">
  <div class="wrap">
    <div class="section-row">
      <div class="section-header">
        <div class="section-tag">✦ Blog &amp; Resources</div>
        <h2 class="section-title">Insights That Move<br>the Needle</h2>
        <p class="section-desc">In-depth guides, tool reviews and marketing tips for organic traffic and affiliate income.</p>
      </div>
      <a href="<?php echo get_permalink(get_option('page_for_posts')); ?>" class="btn-ghost">All Articles →</a>
    </div>
    <div class="adsense-placeholder">Advertisement — Google AdSense 728×90 Leaderboard</div>
    <?php
    $posts = get_posts(['posts_per_page' => 6, 'orderby' => 'date', 'order' => 'DESC']);
    if ($posts):
      $col1 = array_slice($posts, 0, 3);
      $col2 = array_slice($posts, 3, 3);
    ?>
    <div class="blog-grid">
      <div class="blog-col">
        <?php foreach($col1 as $p):
          $cat = get_the_category($p->ID);
          $cat_name = $cat ? $cat[0]->name : 'Blog';
          $cat_color = qrenzy_cat_color($cat ? $cat[0]->slug : '');
        ?>
        <article class="blog-card">
          <div class="blog-thumb">
            <?php if(has_post_thumbnail($p->ID)): echo get_the_post_thumbnail($p->ID, 'qrenzy-thumb');
            else: echo '<span>📝</span>'; endif; ?>
            <span class="blog-cat" style="background:<?php echo $cat_color; ?>"><?php echo esc_html($cat_name); ?></span>
          </div>
          <div class="blog-body">
            <div class="blog-meta"><?php echo get_the_date('M Y', $p); ?> &middot; <?php echo qrenzy_reading_time($p->ID); ?></div>
            <h3 class="blog-title"><a href="<?php echo get_permalink($p); ?>"><?php echo get_the_title($p); ?></a></h3>
            <p class="blog-excerpt"><?php echo wp_trim_words(get_the_excerpt($p), 18); ?></p>
            <div class="blog-footer">
              <a href="<?php echo get_permalink($p); ?>" class="read-link">Read Article →</a>
              <span class="read-time"><?php echo qrenzy_reading_time($p->ID); ?></span>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
      <div class="blog-col">
        <?php foreach($col2 as $p):
          $cat = get_the_category($p->ID);
          $cat_name = $cat ? $cat[0]->name : 'Blog';
          $cat_color = qrenzy_cat_color($cat ? $cat[0]->slug : '');
        ?>
        <article class="blog-card">
          <div class="blog-thumb">
            <?php if(has_post_thumbnail($p->ID)): echo get_the_post_thumbnail($p->ID, 'qrenzy-thumb');
            else: echo '<span>📝</span>'; endif; ?>
            <span class="blog-cat" style="background:<?php echo $cat_color; ?>"><?php echo esc_html($cat_name); ?></span>
          </div>
          <div class="blog-body">
            <div class="blog-meta"><?php echo get_the_date('M Y', $p); ?> &middot; <?php echo qrenzy_reading_time($p->ID); ?></div>
            <h3 class="blog-title"><a href="<?php echo get_permalink($p); ?>"><?php echo get_the_title($p); ?></a></h3>
            <p class="blog-excerpt"><?php echo wp_trim_words(get_the_excerpt($p), 18); ?></p>
            <div class="blog-footer">
              <a href="<?php echo get_permalink($p); ?>" class="read-link">Read Article →</a>
              <span class="read-time"><?php echo qrenzy_reading_time($p->ID); ?></span>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
</section>

<!-- NEWSLETTER -->
<section class="newsletter-section">
  <div class="wrap">
    <div class="newsletter-inner">
      <div class="section-tag" style="margin:0 auto 14px;display:table">✦ Free Newsletter</div>
      <h2 class="section-title" style="text-align:center">Get Weekly Marketing Tips</h2>
      <p class="section-desc" style="text-align:center;margin:10px auto 0">SEO strategies, tool reviews and growth hacks every week. Join 500+ marketers from India, Oman and UAE.</p>
      <script>(function(w,d,e,u,f,l,n){w[f]=w[f]||function(){(w[f].q=w[f].q||[]).push(arguments);},l=d.createElement(e),l.async=1,l.src=u,n=d.getElementsByTagName(e)[0],n.parentNode.insertBefore(l,n);})(window,document,'script','https://assets.mailerlite.com/js/universal.js','ml');ml('account','2160212');</script>
      <div class="ml-embedded" data-form="TC4uB2"></div>
      <p class="newsletter-note">No spam &middot; Unsubscribe anytime &middot; Powered by MailerLite</p>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="testimonials-section">
  <div class="wrap">
    <div class="section-header">
      <div class="section-tag">✦ Client Reviews</div>
      <h2 class="section-title">What Our Clients Say</h2>
      <p class="section-desc">Real businesses. Real results. From Thrissur to Oman to UAE.</p>
    </div>
    <div class="testimonials-grid">
      <?php
      $testimonials = [
        ['AR','#E31E24','"Qrenzy completely transformed our online presence. Leads increased by 70% in just three months. Their SEO strategy was spot on for the Oman market."','Ahmed Al Rashidi','CEO, Al Fanar Group, Oman'],
        ['RM','#1565C0','"We went from zero visibility to Page 1 for our main keywords in Kerala. The team understands local business needs in Thrissur perfectly."','Rajesh Menon','Business Owner, Thrissur, Kerala'],
        ['PN','#2E7D32','"Their social media strategy grew our Instagram from 800 to 12,000 followers in 4 months. Absolutely incredible ROI."','Priya Nair','Digital Creator, Kochi'],
      ];
      foreach($testimonials as $t): ?>
      <div class="testimonial-card">
        <div class="test-stars">★★★★★</div>
        <p class="test-text"><?php echo $t[2]; ?></p>
        <div class="test-author">
          <div class="test-av" style="background:<?php echo $t[1]; ?>"><?php echo $t[0]; ?></div>
          <div><div class="test-name"><?php echo $t[3]; ?></div><div class="test-role"><?php echo $t[4]; ?></div></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- LOCATIONS -->
<section style="padding:60px 0;background:#f8f8f6;border-top:1px solid #e8e8e4">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:36px">
      <div class="section-tag" style="display:table;margin:0 auto 12px">✦ Where We Work</div>
      <h2 class="section-title">Digital Marketing Agency Serving<br>India, Oman, UAE & the Gulf</h2>
      <p class="section-desc" style="max-width:560px;margin:10px auto 0">From Thrissur to Dubai — we help businesses across India and the Gulf rank on Google, grow on social media and generate consistent leads.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;max-width:900px;margin:0 auto">
      <?php
      $loc_links = [
        ['Thrissur','digital-marketing-agency-thrissur','🇮🇳'],
        ['Kerala','digital-marketing-agency-kerala','🇮🇳'],
        ['Kochi','digital-marketing-agency-kochi','🇮🇳'],
        ['Calicut','digital-marketing-agency-calicut','🇮🇳'],
        ['Malabar','malabar','🇮🇳'],
        ['Trivandrum','digital-marketing-agency-trivandrum','🇮🇳'],
        ['Oman','digital-marketing-agency-oman','🇴🇲'],
        ['UAE','digital-marketing-agency-uae','🇦🇪'],
        ['Dubai','digital-marketing-agency-dubai','🇦🇪'],
        ['Qatar','digital-marketing-agency-qatar','🇶🇦'],
        ['Bahrain','digital-marketing-agency-bahrain','🇧🇭'],
      ];
      foreach($loc_links as $ll): ?>
      <a href="<?php echo home_url('/'.$ll[1].'/'); ?>" style="display:flex;align-items:center;gap:10px;background:#fff;border:1px solid #e8e8e4;border-radius:12px;padding:14px 16px;text-decoration:none;color:#0a0a0a;font-size:14px;font-weight:600;transition:all 0.2s" onmouseover="this.style.borderColor='#E31E24';this.style.color='#E31E24'" onmouseout="this.style.borderColor='#e8e8e4';this.style.color='#0a0a0a'">
        <span style="font-size:18px"><?php echo $ll[2]; ?></span>
        <?php echo $ll[0]; ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- INDIA GULF MARKETS -->
<section style="padding:72px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:48px">
      <div>
        <div class="section-tag">🇮🇳 India Market</div>
        <h2 style="font-size:clamp(22px,3vw,34px);font-weight:900;color:#0a0a0a;margin:12px 0 18px;letter-spacing:-0.02em;line-height:1.2">Digital Marketing Services Across India</h2>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:16px">Qrenzy is headquartered in Thrissur, Kerala — and our India practice covers the full spectrum of Indian digital marketing, from hyperlocal SEO for small businesses in Tier 2 cities to national content marketing campaigns for growing brands.</p>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:20px">Our India team understands the unique characteristics of Indian search behaviour — regional language searches, festival seasonality, the India-Gulf NRI connection and the rapidly growing mobile-first internet audience in Tier 2 and Tier 3 cities. We have deep expertise in the Malabar region — serving businesses across Kozhikode, Malappuram, Kannur, Kasaragod, Wayanad and Palakkad — as well as Thrissur, Kochi, Trivandrum and all major Kerala markets.</p>
        <div style="display:flex;flex-wrap:wrap;gap:8px">
          <?php foreach(['Thrissur','Kerala','Kochi','Calicut','Malabar','Kozhikode','Malappuram','Kannur','Trivandrum','Mumbai','Bangalore','Delhi'] as $city): ?>
          <span style="background:#fff;border:1px solid #e8e8e4;padding:6px 12px;border-radius:100px;font-size:12px;font-weight:600;color:#555">📍 <?php echo $city; ?></span>
          <?php endforeach; ?>
        </div>
      </div>
      <div>
        <div class="section-tag">🌍 Gulf Market</div>
        <h2 style="font-size:clamp(22px,3vw,34px);font-weight:900;color:#0a0a0a;margin:12px 0 18px;letter-spacing:-0.02em;line-height:1.2">Digital Marketing for Oman, UAE & the Gulf</h2>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:16px">Our Gulf practice has been serving businesses in Oman, UAE, Qatar and Bahrain since 2020. We provide bilingual digital marketing in English and Arabic, with deep understanding of Gulf consumer behaviour, Islamic calendar seasonality and the cultural nuances that determine what works in each Gulf market.</p>
        <p style="font-size:15px;color:#444;line-height:1.85;margin-bottom:20px">For Gulf businesses, we build campaigns that reach both the local national audience and the large expatriate communities that make up a significant portion of Gulf consumer spending. Our experience with Al Fanar Group in Oman and other Gulf clients gives us practical, on-the-ground insight into how Gulf digital marketing actually delivers results.</p>
        <div style="display:flex;flex-wrap:wrap;gap:8px">
          <?php foreach(['Oman','UAE','Dubai','Abu Dhabi','Qatar','Bahrain','Doha','Muscat'] as $city): ?>
          <span style="background:#fff;border:1px solid #e8e8e4;padding:6px 12px;border-radius:100px;font-size:12px;font-weight:600;color:#555">📍 <?php echo $city; ?></span>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- FAQ -->
<section style="padding:72px 0;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:320px 1fr;gap:64px;align-items:start">
      <div style="position:sticky;top:100px">
        <div class="section-tag">✦ FAQs</div>
        <h2 style="font-size:clamp(22px,2.8vw,32px);font-weight:900;color:#0a0a0a;margin:12px 0 16px;letter-spacing:-0.02em;line-height:1.2">Frequently Asked Questions</h2>
        <p style="font-size:14px;color:#777;line-height:1.7;margin-bottom:24px">Everything you need to know about working with Qrenzy Digital Solutions.</p>
        <a href="<?php echo home_url('/contact/'); ?>" style="display:inline-flex;align-items:center;gap:8px;background:#E31E24;color:#fff;padding:13px 22px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none">Talk to Us →</a>
      </div>
      <div>
        <?php
        $faqs = [
          ['What is Qrenzy Digital Solutions?','Qrenzy Digital Solutions is a full-service digital marketing agency based in Thrissur, Kerala. Founded in 2020, we provide SEO, web design, social media marketing, performance advertising, AI marketing automation and graphic design services to businesses across India, Oman, UAE, Qatar and Bahrain. We specialize in building measurable, data-driven digital marketing strategies for small and medium businesses in India and the Gulf.'],
          ['How much does digital marketing cost in India?','Digital marketing costs in India vary by service and scope. SEO packages for Indian businesses typically start from ₹8,000–15,000 per month for foundational work, scaling to ₹30,000–80,000 per month for comprehensive campaigns in competitive markets. Google Ads management starts from ₹10,000 per month plus ad spend. Social media management ranges from ₹8,000 to ₹25,000 per month. We offer a free SEO audit and strategy call to provide a custom quote for your specific business.'],
          ['How long does SEO take to show results?','Most businesses see measurable improvements in Google rankings within 8–12 weeks of starting SEO. Significant organic traffic growth typically happens within 3–6 months. Google Maps visibility usually improves faster — within 4–8 weeks of Google Business Profile optimization. The timeline depends on your current website health, how competitive your target keywords are and how consistently SEO is executed. We track and report progress monthly so you always know exactly where you stand.'],
          ['Do you work with businesses outside Kerala?','Yes — we work with businesses across India and the Gulf region. Our India clients span Kerala, Karnataka, Tamil Nadu, Maharashtra and Delhi. Our Gulf clients are based in Oman, UAE (Dubai and Abu Dhabi), Qatar and Bahrain. We work entirely remotely with most clients, communicating via WhatsApp, email and video calls. Geography is not a barrier — effective digital marketing is managed through data and communication, not physical proximity.'],
          ['What makes Qrenzy different from other digital marketing agencies?','Three things set Qrenzy apart. First, deep market knowledge — we have genuine on-the-ground expertise in the India and Gulf markets that most agencies lack. Second, integrated strategy — we build all digital channels to work together as a system rather than selling isolated services. Third, transparency — our monthly reports show exactly what your investment is delivering, with no vague claims or confusing metrics. We treat every client\'s business as if it were our own.'],
          ['Can Qrenzy help my business appear in AI search results?','Yes — optimizing for AI search (also called GEO — Generative Engine Optimization) is part of our SEO strategy for every client. Google AI Overviews, ChatGPT and Perplexity increasingly pull content from well-structured, authoritative websites. We optimize your content for AI citation through structured data markup, FAQ sections, authoritative content depth and comprehensive topic coverage. Several of our clients already appear in AI-generated answers for their target keywords.'],
          ['Do you offer monthly contracts or annual commitments?','We offer both month-to-month and annual contracts. Monthly contracts give you flexibility — you can pause or stop at any time with 30 days notice. Annual contracts come with a 15% discount and priority support. We do not lock clients into long contracts because we believe in earning your business every month through results. Most clients who start on monthly contracts choose to continue long-term because of the results we deliver.'],
          ['How do I get started with Qrenzy?','The easiest way to get started is our free SEO audit — a comprehensive analysis of your website\'s current search performance, technical health and ranking opportunities. It takes us 48 hours to complete and gives you a clear picture of where you stand and what\'s possible. Book your free audit through our website or WhatsApp us directly at +91 99057 00600. There\'s no obligation — the audit is genuinely free with no strings attached.'],
        ];
        foreach($faqs as $fi => $faq): ?>
        <details style="border:1px solid #e8e8e4;border-radius:12px;margin-bottom:10px;overflow:hidden" <?php if($fi===0) echo 'open'; ?>>
          <summary style="padding:18px 20px;font-size:15px;font-weight:700;color:#0a0a0a;cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center;gap:12px">
            <?php echo esc_html($faq[0]); ?>
            <span style="font-size:20px;color:#E31E24;flex-shrink:0;line-height:1">+</span>
          </summary>
          <div style="padding:0 20px 18px;font-size:14px;color:#555;line-height:1.8;border-top:1px solid #f0f0ed"><?php echo esc_html($faq[1]); ?></div>
        </details>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- CTA BAND -->
<section class="cta-band">
  <div class="wrap">
    <div class="cta-inner">
      <h2>Ready to Grow Your<br>Business 10x Faster?</h2>
      <p>Book a free 30-minute strategy call for your market in India, Oman, UAE or anywhere worldwide.</p>
      <div class="cta-btns">
        <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-white">🚀 Free Strategy Call</a>
        <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-outline-white" rel="noopener" target="_blank">💬 WhatsApp</a>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
<style>
@media(max-width:860px){
  /* About, Why DM, India Gulf sections */
  .wrap > div[style*="grid-template-columns:1fr 1fr"],
  .wrap > div[style*="grid-template-columns:1fr 1fr"] {
    grid-template-columns: 1fr !important;
  }
  /* FAQ sticky col */
  .wrap > div[style*="grid-template-columns:320px 1fr"] {
    grid-template-columns: 1fr !important;
  }
  /* Remove sticky on mobile — causes overlap */
  .wrap > div[style*="grid-template-columns:320px 1fr"] > div[style*="position:sticky"] {
    position: static !important;
    top: auto !important;
  }
  /* Case studies */
  .wrap > div[style*="grid-template-columns:repeat(3,1fr)"] {
    grid-template-columns: 1fr !important;
  }
  /* About stats grid */
  div[style*="grid-template-columns:1fr 1fr"][style*="gap:16px"] {
    grid-template-columns: 1fr 1fr !important;
  }
}
</style>

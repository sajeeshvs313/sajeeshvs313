<?php get_header(); ?>
<div style="min-height:60vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:80px 24px">
  <div>
    <div style="font-size:80px;font-weight:900;color:#E31E24;line-height:1">404</div>
    <h1 style="font-size:28px;font-weight:800;color:#0a0a0a;margin:16px 0 10px">Page Not Found</h1>
    <p style="color:#666;font-size:16px;margin-bottom:28px">The page you're looking for doesn't exist or has been moved.</p>
    <a href="<?php echo home_url(); ?>" class="btn-red" style="display:inline-flex;align-items:center;gap:8px;background:#E31E24;color:#fff;border-radius:100px;padding:14px 28px;font-size:15px;font-weight:700">← Back to Home</a>
  </div>
</div>
<?php get_footer(); ?>

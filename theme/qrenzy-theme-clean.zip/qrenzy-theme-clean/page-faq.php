<?php
/**
 * Template Name: FAQ
 */
get_header(); ?>

<!-- BREADCRUMB -->
<div class="breadcrumb">
  <div class="wrap">
    <div class="breadcrumb-inner">
      <ol class="bc-list">
        <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <li class="bc-sep">/</li>
        <li>FAQ</li>
      </ol>
    </div>
  </div>
</div>

<style>
/* ── FAQ PAGE ───────────────────────────────────────── */
.faq-hero { padding: 12px 0 56px; background: #fff; }
.faq-hero-inner { text-align: center; max-width: 680px; margin: 0 auto; }
.faq-tag { display:inline-flex;align-items:center;gap:8px;background:#fff0f0;color:#E31E24;font-size:12px;font-weight:700;padding:6px 16px;border-radius:100px;border:1px solid #ffd5d5;margin-bottom:16px;letter-spacing:.06em;text-transform:uppercase }
.faq-h1 { font-size:clamp(32px,5vw,56px);font-weight:900;color:#0a0a0a;line-height:1.08;letter-spacing:-.03em;margin-bottom:16px }
.faq-h1 em { color:#E31E24;font-style:normal }
.faq-lead { font-size:16px;color:#666;line-height:1.8;margin-bottom:32px }

/* ── CATEGORY NAV ── */
.faq-nav-wrap { background:#f8f8f6;border-bottom:1px solid #e8e8e4;position:sticky;top:63px;z-index:90 }
.faq-nav { display:flex;gap:0;overflow-x:auto;scrollbar-width:none;max-width:1200px;margin:0 auto;padding:0 20px }
.faq-nav::-webkit-scrollbar { display:none }
.faq-nav-btn { flex-shrink:0;background:none;border:none;padding:16px 20px;font-size:13px;font-weight:600;color:#888;cursor:pointer;border-bottom:3px solid transparent;transition:all .2s;white-space:nowrap }
.faq-nav-btn:hover { color:#E31E24 }
.faq-nav-btn.active { color:#E31E24;border-bottom-color:#E31E24 }

/* ── SECTIONS ── */
.faq-section { padding:56px 0;border-bottom:1px solid #f0f0ee }
.faq-section:last-of-type { border-bottom:none }
.faq-section:nth-child(even) { background:#f8f8f6 }
.faq-section:nth-child(odd) { background:#fff }
.faq-section-head { margin-bottom:36px }
.faq-section-tag { display:inline-flex;align-items:center;gap:6px;background:#fff0f0;color:#E31E24;font-size:11px;font-weight:700;padding:5px 14px;border-radius:100px;margin-bottom:12px;letter-spacing:.06em;text-transform:uppercase }
.faq-section-h2 { font-size:clamp(22px,3vw,32px);font-weight:900;color:#0a0a0a;letter-spacing:-.02em }

/* ── ACCORDION ── */
.faq-list { display:flex;flex-direction:column;gap:12px;max-width:820px }
.faq-item { background:#fff;border:1px solid #e8e8e4;border-radius:16px;overflow:hidden;transition:box-shadow .2s }
.faq-item.open { box-shadow:0 8px 32px rgba(227,30,36,.08);border-color:#ffd5d5 }
.faq-section:nth-child(even) .faq-item { background:#fff }
.faq-q { display:flex;align-items:center;justify-content:space-between;gap:16px;padding:20px 24px;cursor:pointer;user-select:none }
.faq-q-text { font-size:15px;font-weight:700;color:#0a0a0a;line-height:1.4 }
.faq-icon { width:28px;height:28px;min-width:28px;background:#f0f0ee;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:700;color:#888;transition:all .25s }
.faq-item.open .faq-icon { background:#E31E24;color:#fff;transform:rotate(45deg) }
.faq-a { max-height:0;overflow:hidden;transition:max-height .3s ease }
.faq-a-inner { padding:0 24px 22px;font-size:14px;color:#555;line-height:1.8;border-top:1px solid #f5f5f3 }
.faq-a-inner a { color:#E31E24;font-weight:600 }
.faq-item.open .faq-a { max-height:400px }

/* ── STILL HAVE Q BAND ── */
.faq-contact-band { padding:64px 0;background:#0a0a0a }
.faq-contact-inner { display:grid;grid-template-columns:1fr 1fr 1fr;gap:24px }
.faq-contact-card { background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:20px;padding:28px;text-align:center;transition:background .2s }
.faq-contact-card:hover { background:rgba(255,255,255,.08) }
.faq-contact-icon { font-size:28px;margin-bottom:12px }
.faq-contact-title { font-size:15px;font-weight:800;color:#fff;margin-bottom:6px }
.faq-contact-desc { font-size:12px;color:rgba(255,255,255,.4);margin-bottom:18px;line-height:1.6 }
.faq-contact-btn { display:inline-block;padding:11px 24px;border-radius:100px;font-size:13px;font-weight:700;text-decoration:none }
.faq-contact-btn-red { background:#E31E24;color:#fff }
.faq-contact-btn-outline { border:1.5px solid rgba(255,255,255,.2);color:#fff }
.faq-contact-btn-green { background:#25D366;color:#fff }

/* ── RESPONSIVE ── */
@media(max-width:768px){
  .faq-contact-inner { grid-template-columns:1fr }
  .faq-q-text { font-size:14px }
}
</style>

<!-- ── HERO ─────────────────────────────────────────────── -->
<section class="faq-hero">
  <div class="wrap">
    <div class="faq-hero-inner">
      <div class="faq-tag">✦ Questions & Answers</div>
      <h1 class="faq-h1">Everything You Want to<br><em>Know About Qrenzy</em></h1>
      <p class="faq-lead">Answers to the most common questions about our services, process, pricing and results. Can't find what you need? <a href="<?php echo home_url('/contact/'); ?>" style="color:#E31E24;font-weight:700">Just ask us directly →</a></p>
    </div>
  </div>
</section>

<!-- ── STICKY CATEGORY NAV ──────────────────────────────── -->
<div class="faq-nav-wrap">
  <nav class="faq-nav">
    <button class="faq-nav-btn active" onclick="scrollToSection('general')">🏢 About Qrenzy</button>
    <button class="faq-nav-btn" onclick="scrollToSection('seo')">🔍 SEO Services</button>
    <button class="faq-nav-btn" onclick="scrollToSection('web')">🌐 Web Design</button>
    <button class="faq-nav-btn" onclick="scrollToSection('social')">📱 Social Media</button>
    <button class="faq-nav-btn" onclick="scrollToSection('pricing')">💰 Pricing</button>
    <button class="faq-nav-btn" onclick="scrollToSection('process')">🚀 Working With Us</button>
  </nav>
</div>

<!-- ── SECTION 1: GENERAL ────────────────────────────────── -->
<section class="faq-section" id="general">
  <div class="wrap">
    <div class="faq-section-head">
      <div class="faq-section-tag">🏢 About Qrenzy</div>
      <h2 class="faq-section-h2">General Questions</h2>
    </div>
    <div class="faq-list">

      <?php
      $general_faqs = [
        [
          "What is Qrenzy Digital Solutions?",
          "Qrenzy Digital Solutions is a full-service digital marketing agency founded in 2020, based in Thrissur, Kerala. We specialise in SEO, social media marketing, web design, performance ads and AI marketing automation — serving 200+ businesses across India, Oman, UAE and Bahrain."
        ],
        [
          "Who is behind Qrenzy?",
          "Qrenzy was founded by Sajeesh V S, a digital marketing professional with 18+ years of hands-on experience across India, Oman and UAE — spanning SEO, IT operations, content strategy and performance advertising. Every client gets direct access to the same expertise."
        ],
        [
          "Which locations does Qrenzy serve?",
          "We primarily serve businesses in Kerala (Thrissur, Kochi, Calicut, Trivandrum), pan-India clients, and Gulf businesses in Oman, UAE, Dubai, Bahrain and Qatar. We also work with international clients worldwide — timezone is no barrier."
        ],
        [
          "Is Qrenzy only for large businesses?",
          "Not at all. Most of our clients are small and medium businesses — local shops, clinics, restaurants, real estate firms, and service businesses. We offer flexible packages that match your budget and growth stage."
        ],
        [
          "How is Qrenzy different from other digital marketing agencies in Kerala?",
          "Three things set us apart: (1) We combine 18+ years of real-world experience with AI-powered tools — not just theory. (2) We work across India and the Gulf, so we understand multi-market strategies. (3) You always deal directly with the founder — no account manager middlemen."
        ],
        [
          "Is Qrenzy recognized anywhere?",
          "Yes. Qrenzy is recognized on Clutch as one of Kerala's top digital marketing agencies. Our clients' websites have also been recognized by AI platforms including ChatGPT, Gemini and Perplexity for their respective industries."
        ],
      ];
      foreach($general_faqs as $i => $faq): ?>
      <div class="faq-item" id="faq-g-<?php echo $i; ?>">
        <div class="faq-q" onclick="toggleFaq(this)">
          <span class="faq-q-text"><?php echo $faq[0]; ?></span>
          <span class="faq-icon">+</span>
        </div>
        <div class="faq-a"><div class="faq-a-inner"><?php echo $faq[1]; ?></div></div>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>

<!-- ── SECTION 2: SEO ─────────────────────────────────────── -->
<section class="faq-section" id="seo">
  <div class="wrap">
    <div class="faq-section-head">
      <div class="faq-section-tag">🔍 SEO Services</div>
      <h2 class="faq-section-h2">Search Engine Optimization</h2>
    </div>
    <div class="faq-list">

      <?php
      $seo_faqs = [
        [
          "How long does SEO take to show results?",
          "Most clients see measurable improvements in rankings and traffic within 60–90 days. Significant organic growth typically happens between months 3–6. SEO is a long-term investment — the results compound and keep delivering unlike paid ads which stop the moment you pause spending."
        ],
        [
          "What does your SEO service include?",
          "Our full SEO service covers: technical SEO audit & fixes, keyword research, on-page optimisation, content strategy & writing, local SEO, Google Business Profile management, link building and monthly performance reporting. Everything under one roof."
        ],
        [
          "Do you do local SEO for Kerala businesses?",
          "Yes — local SEO is one of our core strengths. We optimise your Google Business Profile, build local citations, manage reviews and target location-specific keywords across all major Kerala cities and Gulf markets."
        ],
        [
          "Can you recover a website hit by a Google algorithm update?",
          "Yes. We have experience with Google penalty recovery and algorithm-update impact analysis. We conduct a full audit, identify the root causes — thin content, bad links, technical issues — and build a recovery plan."
        ],
        [
          "Do you guarantee Page 1 rankings?",
          "No ethical SEO agency can guarantee specific rankings — Google's algorithm is beyond anyone's control. What we do guarantee is transparent, white-hat work with proven strategies that consistently move clients up in search results. Our average client sees 340%+ organic traffic growth within 6 months."
        ],
        [
          "Will SEO work for my type of business?",
          "SEO works for virtually every business that has an online presence — service businesses, e-commerce, B2B, healthcare, real estate, hospitality and more. We'll tell you honestly during your free audit if SEO is the right investment for your specific situation."
        ],
      ];
      foreach($seo_faqs as $i => $faq): ?>
      <div class="faq-item" id="faq-s-<?php echo $i; ?>">
        <div class="faq-q" onclick="toggleFaq(this)">
          <span class="faq-q-text"><?php echo $faq[0]; ?></span>
          <span class="faq-icon">+</span>
        </div>
        <div class="faq-a"><div class="faq-a-inner"><?php echo $faq[1]; ?></div></div>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>

<!-- ── SECTION 3: WEB DESIGN ─────────────────────────────── -->
<section class="faq-section" id="web">
  <div class="wrap">
    <div class="faq-section-head">
      <div class="faq-section-tag">🌐 Web Design</div>
      <h2 class="faq-section-h2">Web Design & Development</h2>
    </div>
    <div class="faq-list">

      <?php
      $web_faqs = [
        [
          "What platform do you build websites on?",
          "We primarily build on WordPress — the world's most flexible and SEO-friendly CMS. All our websites are custom-coded (not page-builder drag-and-drop) for maximum speed, SEO performance and control."
        ],
        [
          "How fast will my website load?",
          "Our websites are engineered to load in under 2 seconds. We optimise Core Web Vitals, compress images, minify code and configure caching — so your site scores high on Google PageSpeed and delivers a great user experience."
        ],
        [
          "Will my website be mobile-friendly?",
          "Absolutely — every website we build is mobile-first by design. Over 70% of web traffic in India and the Gulf comes from mobile. We test across multiple devices and screen sizes before delivery."
        ],
        [
          "Do you build e-commerce websites?",
          "Yes. We build WooCommerce-powered stores with payment gateway integration (Razorpay, PayPal, Stripe), product management, inventory tracking and conversion-optimised checkout flows."
        ],
        [
          "Will I be able to update my website myself?",
          "Yes. WordPress gives you a simple dashboard to update content, add blog posts, manage products and more — no technical knowledge needed. We also provide a brief walkthrough after handover."
        ],
      ];
      foreach($web_faqs as $i => $faq): ?>
      <div class="faq-item" id="faq-w-<?php echo $i; ?>">
        <div class="faq-q" onclick="toggleFaq(this)">
          <span class="faq-q-text"><?php echo $faq[0]; ?></span>
          <span class="faq-icon">+</span>
        </div>
        <div class="faq-a"><div class="faq-a-inner"><?php echo $faq[1]; ?></div></div>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>

<!-- ── SECTION 4: SOCIAL MEDIA ───────────────────────────── -->
<section class="faq-section" id="social">
  <div class="wrap">
    <div class="faq-section-head">
      <div class="faq-section-tag">📱 Social Media</div>
      <h2 class="faq-section-h2">Social Media Marketing</h2>
    </div>
    <div class="faq-list">

      <?php
      $social_faqs = [
        [
          "Which social media platforms do you manage?",
          "We manage Instagram, Facebook, LinkedIn, YouTube and WhatsApp Business. We recommend the right platforms based on your target audience — not all platforms work equally well for every business type."
        ],
        [
          "Do you create content or do I need to provide it?",
          "We handle everything — content strategy, copywriting, graphic design, video editing and scheduling. You just approve the monthly content calendar. If you want to be involved in content creation, we'll work with whatever assets you provide."
        ],
        [
          "How many posts per month do you publish?",
          "This depends on your package. Typically we post 3–5 times per week per platform, including a mix of static posts, reels/videos and stories. We also handle community management — replying to comments and DMs."
        ],
        [
          "Can you run paid ads on social media too?",
          "Yes. We run Meta (Facebook & Instagram) ads as part of our Performance Marketing service. We handle targeting, creatives, A/B testing and conversion tracking — with full transparency on ad spend and results."
        ],
      ];
      foreach($social_faqs as $i => $faq): ?>
      <div class="faq-item" id="faq-sm-<?php echo $i; ?>">
        <div class="faq-q" onclick="toggleFaq(this)">
          <span class="faq-q-text"><?php echo $faq[0]; ?></span>
          <span class="faq-icon">+</span>
        </div>
        <div class="faq-a"><div class="faq-a-inner"><?php echo $faq[1]; ?></div></div>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>

<!-- ── SECTION 5: PRICING ─────────────────────────────────── -->
<section class="faq-section" id="pricing">
  <div class="wrap">
    <div class="faq-section-head">
      <div class="faq-section-tag">💰 Pricing</div>
      <h2 class="faq-section-h2">Pricing & Packages</h2>
    </div>
    <div class="faq-list">

      <?php
      $pricing_faqs = [
        [
          "How much does digital marketing cost?",
          "Pricing varies based on the services, scope and market. We offer both project-based pricing and monthly retainer packages. The best first step is a <a href=\"" . home_url('/free-seo-audit/') . "\">free SEO audit</a> — it helps us understand your needs and give you a precise, no-surprise quote."
        ],
        [
          "Do you have fixed packages?",
          "We do have standard service packages, but we always customise them to match your specific goals and budget. We don't believe in one-size-fits-all — a local Kerala restaurant has different needs from a Gulf-based e-commerce brand."
        ],
        [
          "Is there a minimum contract period?",
          "For SEO and ongoing services, we recommend a minimum of 3 months to see meaningful results — that's just the nature of organic growth. However, we don't lock you into long contracts. We earn your trust month by month."
        ],
        [
          "How do I pay? Do you accept international payments?",
          "We accept bank transfers, UPI, Razorpay and international wire transfers. Gulf and international clients can pay via bank transfer or PayPal. We issue proper invoices for all payments."
        ],
        [
          "Do you offer a free trial or audit?",
          "Yes — we offer a free SEO audit for your website. No credit card, no commitment. It includes a full review of your technical SEO, keyword opportunities, competitor gaps and a clear action plan. <a href=\"" . home_url('/free-seo-audit/') . "\">Get yours here →</a>"
        ],
      ];
      foreach($pricing_faqs as $i => $faq): ?>
      <div class="faq-item" id="faq-p-<?php echo $i; ?>">
        <div class="faq-q" onclick="toggleFaq(this)">
          <span class="faq-q-text"><?php echo $faq[0]; ?></span>
          <span class="faq-icon">+</span>
        </div>
        <div class="faq-a"><div class="faq-a-inner"><?php echo $faq[1]; ?></div></div>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>

<!-- ── SECTION 6: WORKING WITH US ────────────────────────── -->
<section class="faq-section" id="process">
  <div class="wrap">
    <div class="faq-section-head">
      <div class="faq-section-tag">🚀 Working With Us</div>
      <h2 class="faq-section-h2">Process & Onboarding</h2>
    </div>
    <div class="faq-list">

      <?php
      $process_faqs = [
        [
          "How do I get started with Qrenzy?",
          "Three simple steps: (1) Get a free SEO audit or WhatsApp us. (2) We hop on a 30-minute discovery call to understand your goals. (3) We send you a tailored proposal. Once approved, we can be live within 48 hours."
        ],
        [
          "How will we communicate once the project starts?",
          "Most clients prefer WhatsApp for day-to-day updates — it's fast and convenient. We also do scheduled Google Meet calls for strategy reviews. You'll have direct access to your account manager at all times."
        ],
        [
          "How do you report results?",
          "You receive a monthly performance report covering keyword rankings, organic traffic, leads generated, social media growth and ad performance (if applicable). We use Google Analytics 4, Google Search Console and platform-native analytics."
        ],
        [
          "Do you work with businesses outside Kerala and India?",
          "Yes — Gulf clients are a significant part of our business. We serve clients in Oman, UAE, Dubai, Bahrain and Qatar. All communication is via WhatsApp and Google Meet. The time difference is minimal and manageable."
        ],
        [
          "Can I manage all services through one point of contact?",
          "Absolutely. Many clients use Qrenzy as their complete digital partner — SEO, web, social and ads all managed together. One contact, full visibility, better results through integrated strategy."
        ],
      ];
      foreach($process_faqs as $i => $faq): ?>
      <div class="faq-item" id="faq-pr-<?php echo $i; ?>">
        <div class="faq-q" onclick="toggleFaq(this)">
          <span class="faq-q-text"><?php echo $faq[0]; ?></span>
          <span class="faq-icon">+</span>
        </div>
        <div class="faq-a"><div class="faq-a-inner"><?php echo $faq[1]; ?></div></div>
      </div>
      <?php endforeach; ?>

    </div>
  </div>
</section>

<!-- ── STILL HAVE A QUESTION ─────────────────────────────── -->
<section class="faq-contact-band">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:40px">
      <div class="faq-tag" style="background:rgba(227,30,36,.15);border-color:rgba(227,30,36,.3);color:#ff6b6b;display:inline-flex;margin-bottom:16px">✦ Still Have Questions?</div>
      <h2 style="font-size:clamp(24px,4vw,40px);font-weight:900;color:#fff;letter-spacing:-.02em;margin-bottom:12px">We're Happy to Answer Anything</h2>
      <p style="font-size:15px;color:rgba(255,255,255,.5);max-width:500px;margin:0 auto">Reach out via WhatsApp, email or book a free strategy call. No sales pressure — just honest answers.</p>
    </div>
    <div class="faq-contact-inner">
      <div class="faq-contact-card">
        <div class="faq-contact-icon">💬</div>
        <div class="faq-contact-title">WhatsApp Us</div>
        <div class="faq-contact-desc">Fastest response. Get answers within minutes during business hours.</div>
        <a href="https://api.whatsapp.com/send?phone=919905700600" class="faq-contact-btn faq-contact-btn-green" target="_blank" rel="noopener">Chat on WhatsApp</a>
      </div>
      <div class="faq-contact-card">
        <div class="faq-contact-icon">🔍</div>
        <div class="faq-contact-title">Free SEO Audit</div>
        <div class="faq-contact-desc">Start with a free audit of your website. No commitment needed.</div>
        <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="faq-contact-btn faq-contact-btn-red">Get Free Audit</a>
      </div>
      <div class="faq-contact-card">
        <div class="faq-contact-icon">📩</div>
        <div class="faq-contact-title">Send a Message</div>
        <div class="faq-contact-desc">Send us your question and we'll reply within 24 business hours.</div>
        <a href="<?php echo home_url('/contact/'); ?>" class="faq-contact-btn faq-contact-btn-outline">Contact Us</a>
      </div>
    </div>
  </div>
</section>

<!-- ── FINAL CTA BAND ──────────────────────────────────────── -->
<section class="cta-band">
  <div class="wrap"><div class="cta-inner">
    <h2>Ready to Grow Your Business Online?</h2>
    <p>Join 200+ businesses across India, Oman & UAE who trust Qrenzy.</p>
    <div class="cta-btns">
      <a href="<?php echo home_url('/free-seo-audit/'); ?>" class="btn-white">🔍 Free SEO Audit</a>
      <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-outline-white" rel="noopener" target="_blank">💬 WhatsApp Now</a>
    </div>
  </div></div>
</section>

<!-- ── ACCORDION JS ──────────────────────────────────────── -->
<script>
function toggleFaq(el) {
  const item = el.closest('.faq-item');
  const isOpen = item.classList.contains('open');
  // close all
  document.querySelectorAll('.faq-item.open').forEach(i => i.classList.remove('open'));
  // open clicked if it wasn't open
  if (!isOpen) item.classList.add('open');
}

function scrollToSection(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const offset = 110;
  const top = el.getBoundingClientRect().top + window.scrollY - offset;
  window.scrollTo({ top, behavior: 'smooth' });
  // update active nav btn
  document.querySelectorAll('.faq-nav-btn').forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
}

// Auto-highlight nav on scroll
window.addEventListener('scroll', () => {
  const sections = ['general','seo','web','social','pricing','process'];
  const offset = 130;
  sections.forEach((id, i) => {
    const el = document.getElementById(id);
    if (!el) return;
    const rect = el.getBoundingClientRect();
    if (rect.top <= offset && rect.bottom > offset) {
      document.querySelectorAll('.faq-nav-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.faq-nav-btn')[i].classList.add('active');
    }
  });
});
</script>

<!-- ── FAQ SCHEMA ────────────────────────────────────────── -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {"@type":"Question","name":"What is Qrenzy Digital Solutions?","acceptedAnswer":{"@type":"Answer","text":"Qrenzy Digital Solutions is a full-service digital marketing agency founded in 2020, based in Thrissur, Kerala. We specialise in SEO, social media marketing, web design, performance ads and AI marketing automation — serving 200+ businesses across India, Oman, UAE and Bahrain."}},
    {"@type":"Question","name":"How long does SEO take to show results?","acceptedAnswer":{"@type":"Answer","text":"Most clients see measurable improvements in rankings and traffic within 60–90 days. Significant organic growth typically happens between months 3–6."}},
    {"@type":"Question","name":"Does Qrenzy serve businesses outside Kerala?","acceptedAnswer":{"@type":"Answer","text":"Yes. We actively serve clients in Oman, UAE, Dubai, Bahrain and Qatar, with market-specific strategies for each location."}},
    {"@type":"Question","name":"How do I get started with Qrenzy?","acceptedAnswer":{"@type":"Answer","text":"Three simple steps: Get a free SEO audit or WhatsApp us. We hop on a 30-minute discovery call to understand your goals. We send you a tailored proposal — and can be live within 48 hours."}},
    {"@type":"Question","name":"Do you guarantee Page 1 rankings?","acceptedAnswer":{"@type":"Answer","text":"No ethical SEO agency can guarantee specific rankings. What we do guarantee is transparent, white-hat work with proven strategies. Our average client sees 340%+ organic traffic growth within 6 months."}},
    {"@type":"Question","name":"What does your SEO service include?","acceptedAnswer":{"@type":"Answer","text":"Our full SEO service covers: technical SEO audit and fixes, keyword research, on-page optimisation, content strategy and writing, local SEO, Google Business Profile management, link building and monthly performance reporting."}},
    {"@type":"Question","name":"How much does digital marketing cost?","acceptedAnswer":{"@type":"Answer","text":"Pricing varies based on the services, scope and market. The best first step is a free SEO audit — it helps us understand your needs and give you a precise, no-surprise quote."}},
    {"@type":"Question","name":"Which social media platforms do you manage?","acceptedAnswer":{"@type":"Answer","text":"We manage Instagram, Facebook, LinkedIn, YouTube and WhatsApp Business. We recommend the right platforms based on your target audience."}},
    {"@type":"Question","name":"What platform do you build websites on?","acceptedAnswer":{"@type":"Answer","text":"We primarily build on WordPress — custom-coded for maximum speed, SEO performance and control. Our websites load in under 2 seconds."}},
    {"@type":"Question","name":"How will we communicate once the project starts?","acceptedAnswer":{"@type":"Answer","text":"Most clients prefer WhatsApp for day-to-day updates. We also do scheduled Google Meet calls for strategy reviews. You have direct access to your account manager at all times."}}
  ]
}
</script>

<?php get_footer(); ?>

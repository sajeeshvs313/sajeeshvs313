<?php
/**
 * Template Name: Free SEO Audit
 */
get_header(); ?>

<!-- BREADCRUMB -->
<div class="breadcrumb">
  <div class="wrap">
    <div class="breadcrumb-inner">
      <ol class="bc-list">
        <li><a href="<?php echo home_url(); ?>">Home</a></li>
        <li class="bc-sep">/</li>
        <li>Free SEO Audit</li>
      </ol>
    </div>
  </div>
</div>

<!-- HERO -->
<section style="padding:60px 0 56px;background:#fff">
  <div class="wrap">
    <div style="display:grid;grid-template-columns:1fr 480px;gap:56px;align-items:center">
      <div>
        <div class="section-tag">✦ 100% Free — No Credit Card</div>
        <h1 style="font-size:clamp(30px,4.5vw,52px);font-weight:900;color:#0a0a0a;letter-spacing:-0.03em;line-height:1.1;margin:16px 0 18px">
          Get Your Free<br><span style="color:#E31E24">SEO Audit Report</span><br>in 24 Hours
        </h1>
        <p style="font-size:16px;color:#555;line-height:1.8;margin-bottom:24px;max-width:500px">
          Our SEO experts will analyse your website and send you a detailed report covering technical SEO, keyword gaps, competitor analysis and a clear action plan — completely free.
        </p>
        <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:28px">
          <?php
          $includes = [
            ['✅','Technical SEO Analysis','Page speed, mobile, crawlability, Core Web Vitals'],
            ['✅','Keyword Gap Report','Keywords your competitors rank for — but you don\'t'],
            ['✅','Competitor Analysis','Top 3 competitors ranked above you and why'],
            ['✅','On-Page SEO Review','Title tags, meta descriptions, headings, content quality'],
            ['✅','Action Plan','Clear prioritised list of what to fix first'],
          ];
          foreach($includes as $i): ?>
          <div style="display:flex;align-items:flex-start;gap:12px">
            <span style="font-size:15px;flex-shrink:0;margin-top:1px"><?php echo $i[0]; ?></span>
            <div>
              <span style="font-size:14px;font-weight:700;color:#0a0a0a"><?php echo $i[1]; ?></span>
              <span style="font-size:13px;color:#888"> — <?php echo $i[2]; ?></span>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <div style="display:flex;align-items:center;gap:12px;padding:14px 18px;background:#f8f8f6;border-radius:12px;border:1px solid #e8e8e4;max-width:420px">
          <div style="display:flex">
            <span style="width:32px;height:32px;border-radius:50%;background:#E31E24;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#fff;border:2px solid #fff;margin-left:0">AK</span>
            <span style="width:32px;height:32px;border-radius:50%;background:#1565C0;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#fff;border:2px solid #fff;margin-left:-8px">RM</span>
            <span style="width:32px;height:32px;border-radius:50%;background:#2E7D32;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#fff;border:2px solid #fff;margin-left:-8px">PS</span>
          </div>
          <div>
            <div style="font-size:13px;font-weight:700;color:#0a0a0a">200+ businesses audited</div>
            <div style="font-size:11px;color:#888">India · Oman · UAE · Worldwide</div>
          </div>
        </div>
      </div>

      <!-- FORM -->
      <div style="background:#f8f8f6;border-radius:24px;padding:36px;border:1px solid #e8e8e4;box-shadow:0 20px 60px rgba(0,0,0,0.07)">
        <div style="text-align:center;margin-bottom:24px">
          <div style="font-size:28px;margin-bottom:8px">🔍</div>
          <h2 style="font-size:20px;font-weight:800;color:#0a0a0a;margin-bottom:6px">Request Your Free Audit</h2>
          <p style="font-size:13px;color:#888">We'll send your report within 24 hours</p>
        </div>
        <?php echo do_shortcode('[wpforms id="21" title="false"]'); ?>
        <p style="font-size:11px;color:#aaa;text-align:center;margin-top:14px;margin-bottom:0">
          🔒 Your data is safe. We never share your information. No spam, ever.
        </p>
      </div>
    </div>
  </div>
</section>

<!-- WHAT WE CHECK -->
<section style="padding:12px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ What We Analyse</div>
      <h2 class="section-title">Your Complete SEO Health Check</h2>
      <p class="section-desc" style="margin:10px auto 0;text-align:center">Every audit covers 50+ SEO factors across 6 key areas.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px">
      <?php
      $checks = [
        ['⚡','Technical SEO','Page speed score, mobile-friendliness, Core Web Vitals, crawl errors, XML sitemap, robots.txt, HTTPS, structured data'],
        ['🔑','Keyword Analysis','Current rankings, keyword gaps, missed opportunities, search volume data for your market (India/Gulf)'],
        ['🏆','Competitor Research','Who ranks above you, what keywords they target, their backlink profile and content strategy'],
        ['📄','On-Page SEO','Title tags, meta descriptions, heading structure, content quality, internal linking, image alt tags'],
        ['🔗','Backlink Profile','Total backlinks, domain authority, toxic links, link building opportunities in your niche'],
        ['📱','Local SEO','Google Business Profile optimisation, local citations, NAP consistency for Thrissur/India/Gulf markets'],
      ];
      foreach($checks as $c): ?>
      <div style="background:#fff;border-radius:20px;padding:26px;border:1px solid #e8e8e4">
        <div style="font-size:32px;margin-bottom:12px"><?php echo $c[0]; ?></div>
        <h3 style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:8px"><?php echo $c[1]; ?></h3>
        <p style="font-size:13px;color:#666;line-height:1.65;margin:0"><?php echo $c[2]; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PROCESS -->
<section style="padding:32px 0;background:#fff">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ How It Works</div>
      <h2 class="section-title">Simple 3-Step Process</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:24px;max-width:800px;margin:0 auto">
      <?php
      $steps = [
        ['01','Submit Your Details','Fill the form above with your website URL and business details. Takes less than 2 minutes.','#E31E24'],
        ['02','We Audit Your Site','Our SEO experts run a full analysis of 50+ factors across your website within 24 hours.','#1565C0'],
        ['03','Receive Your Report','Get a detailed PDF report with clear action items sent directly to your email.','#16A34A'],
      ];
      foreach($steps as $s): ?>
      <div style="text-align:center;padding:28px 20px;background:#f8f8f6;border-radius:20px;border:1px solid #e8e8e4">
        <div style="width:52px;height:52px;border-radius:50%;background:<?php echo $s[3]; ?>;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:900;color:#fff;margin:0 auto 16px"><?php echo $s[0]; ?></div>
        <h3 style="font-size:15px;font-weight:800;color:#0a0a0a;margin-bottom:8px"><?php echo $s[1]; ?></h3>
        <p style="font-size:13px;color:#666;line-height:1.65;margin:0"><?php echo $s[2]; ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FAQ -->
<section style="padding:32px 0;background:#f8f8f6">
  <div class="wrap">
    <div style="text-align:center;margin-bottom:48px">
      <div class="section-tag" style="display:table;margin:0 auto 14px">✦ FAQ</div>
      <h2 class="section-title">Common Questions</h2>
    </div>
    <div style="max-width:700px;margin:0 auto;display:flex;flex-direction:column;gap:12px">
      <?php
      $faqs = [
        ['Is the SEO audit really free?','Yes — 100% free, no credit card required, no hidden charges. We offer this as a way to show you exactly what we can do for your business.'],
        ['How long does the audit take?','We deliver your report within 24 hours on business days. Most audits are completed the same day.'],
        ['Do you audit websites in Oman and UAE?','Absolutely. We specialise in India, Oman and UAE markets. Our audit includes local SEO analysis specific to your target market.'],
        ['What happens after I receive the audit?','You receive a detailed report with clear action items. There is no obligation to hire us — though most clients do after seeing the report!'],
        ['What information do I need to provide?','Just your website URL, business name, target location and email address. That is all we need to get started.'],
      ];
      foreach($faqs as $i => $f): ?>
      <div style="background:#fff;border-radius:14px;border:1px solid #e8e8e4;overflow:hidden">
        <button onclick="toggleFaq(<?php echo $i; ?>)" style="width:100%;padding:18px 22px;text-align:left;background:none;border:none;cursor:pointer;display:flex;justify-content:space-between;align-items:center;font-family:inherit">
          <span style="font-size:14px;font-weight:700;color:#0a0a0a"><?php echo $f[0]; ?></span>
          <span id="faq-icon-<?php echo $i; ?>" style="font-size:18px;color:#E31E24;font-weight:700;flex-shrink:0;margin-left:12px">+</span>
        </button>
        <div id="faq-body-<?php echo $i; ?>" style="display:none;padding:0 22px 18px">
          <p style="font-size:13px;color:#666;line-height:1.7;margin:0"><?php echo $f[1]; ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-band">
  <div class="wrap">
    <div class="cta-inner">
      <h2>Don't Let Competitors<br>Outrank You!</h2>
      <p>Get your free SEO audit today. Find out exactly what's holding your website back — and how to fix it fast.</p>
      <div class="cta-btns">
        <a href="#" onclick="document.querySelector('.wpforms-form input[type=text]').focus();return false;" class="btn-white">🔍 Get Free Audit Now</a>
        <a href="https://api.whatsapp.com/send?phone=919905700600" class="btn-outline-white" rel="noopener" target="_blank">💬 WhatsApp Us</a>
      </div>
    </div>
  </div>
</section>

<script>
function toggleFaq(i) {
  var body = document.getElementById('faq-body-' + i);
  var icon = document.getElementById('faq-icon-' + i);
  if (body.style.display === 'none') {
    body.style.display = 'block';
    icon.textContent = '−';
  } else {
    body.style.display = 'none';
    icon.textContent = '+';
  }
}
</script>

<style>
@media (max-width: 900px) {
  [style*="grid-template-columns:1fr 480px"] { grid-template-columns: 1fr !important; }
  [style*="grid-template-columns:repeat(3,1fr)"] { grid-template-columns: 1fr 1fr !important; }
}
@media (max-width: 600px) {
  [style*="grid-template-columns:repeat(3,1fr)"] { grid-template-columns: 1fr !important; }
}
</style>

<?php get_footer(); ?>
